#ifndef _Motor_hpp_
#define _Motor_hpp_

#include "zf_common_headfile.hpp"

// 电机设备路径
// PWM设备节点
#define MOTOR_L_PWM    ZF_PWM_MOTOR_1    // "/dev/zf_pwm_motor_1" 86
#define MOTOR_R_PWM    ZF_PWM_MOTOR_2    // "/dev/zf_pwm_motor_2" 87
// GPIO电机设备节点
#define MOTOR_L_DIR    ZF_GPIO_MOTOR_1   // "/dev/zf_gpio_motor_1" 73
#define MOTOR_R_DIR    ZF_GPIO_MOTOR_2   // "/dev/zf_gpio_motor_2" 76


// 全局变量声明
extern int16 Left_Speed ;
extern int16 Right_Speed ;

//底层驱动（zf_driver_pwm.h）中已有 struct pwm_info 的定义
//在 Motor.h 中重复定义了同名结构体，即使成员完全一样，编译器也会认为是两个不同的类型
// PWM数据结构体，用于存储PWM相关的参数信息
// 包含频率、占空比、占空比最大值、高电平时间、周期时间、时钟频率等参数
// struct pwm_info
// {
//     uint32 freq;       // PWM频率
//     uint32 duty;       // PWM占空比
//     uint32 duty_max;   // PWM占空比最大值
//     uint32 duty_ns;    // PWM高电平时间（纳秒）
//     uint32 period_ns;  // PWM周期时间（纳秒）
//     uint32 clk_freq;   // 时钟频率
// };


// 声明PWM/GPIO类全局对象
extern zf_driver_pwm  motor_L_pwm_obj;
extern zf_driver_pwm  motor_R_pwm_obj;
extern zf_driver_gpio motor_L_gpio_obj;
extern zf_driver_gpio motor_R_gpio_obj;

// 声明左右电机的全局结构体变量
extern struct pwm_info motor_R_pwm_info;
extern struct pwm_info motor_L_pwm_info;

// 函数声明
void Motor_Init(void);                  // 电机初始化
void Motor_R_SetSpeed(int pwm);         // 右电机速度设置
void Motor_L_SetSpeed(int pwm);         // 左电机速度设置
void Motor_StopAll(void);               // 停止所有电机


// 获取GPIO电平状态 0=低电平 1=高电平
uint8 Motor_GetLeftGpioLevel(void);
uint8 Motor_GetRightGpioLevel(void);

// 获取PWM设备信息（频率/占空比/最大值）
void Motor_GetLeftPwmInfo(struct pwm_info *info);
void Motor_GetRightPwmInfo(struct pwm_info *info);

// 调试打印电机状态
void Motor_DebugStatus(void);


#endif


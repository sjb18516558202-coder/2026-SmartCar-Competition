#ifndef _DiffSteering_hpp_
#define _DiffSteering_hpp_

// 基础平台驱动头文件（包含数据类型、系统函数）
#include "zf_common_headfile.hpp"
// 电机驱动头文件：提供左右电机 PWM 输出控制函数
#include "Motor.hpp"
// 编码器头文件：获取左右轮实时速度（cm/s）
#include "Encoder.hpp"
// 图像循线头文件：获取中线像素偏移量、拟合角度
#include "Image.hpp"
// PID算法头文件：增量式PID速度闭环控制
#include "PID.hpp"
// 按键功能头文件：新增，引入小车运行使能判断宏
#include "key.hpp"
// 数学库：绝对值、浮点运算等
#include <math.h>

// ==================== 【核心调试参数】 ====================
// 直行基准角度：赛道中线垂直于X轴时为90°
#define CENTER_ANGLE        90.0f

// 直道加速最大允许PWM，高于普通直行6000
#define BOOST_PWM_MAX    6000

// // ========== 直道加速 ==========
#define LONG_LINE_CUTOFF_THRESHOLD    31  // 直道长白列
#define STRAIGHT_BOOST_ANGLE          8.0f    // 角度偏差 < 4° 开启直道加速
#define STRAIGHT_BOOST_PWM            3000 // 3500   // 直道加速PWM



// ==================== 红色检测参数（仅检测到红色，尚未开始绕行） ====================
#define RED_DETECT_BASE_PWM      50// 150 // 红色检测阶段固定基础PWM
#define RED_DETECT_PIXEL_GAIN    8.0f // 红色检测阶段固定像素增益

// ==================== 红色绕行参数（正在执行绕行动作） ====================
#define RED_AVOID_BASE_PWM      1650 //1000   // 绕行阶段固定基础PWM
#define RED_AVOID_PIXEL_GAIN    12.0f     //8.0f   // 绕行阶段固定像素增益



// 动态基础速度PWM配置
// 90°直行时使用最大PWM（速度最快）
#define BASE_SPEED_MAX      2650
// 0°/180°大弯道时使用最小PWM（速度最慢，防冲出）
#define BASE_SPEED_MIN      1700//1800
// 动态基础PWM 角度限幅（仅用于动态速度计算，控制减速范围）
#define ANGLE_LIMIT_FOR_SPEED    50.0f
// 基础速度PWM：角度偏差≥5°才开始动态减速
#define SPEED_CALC_START_ANGLE    10.0f    


// 像素环参数：修正中线偏移，保持赛道中心
// 直道最小增益（90°）
#define PIXEL_GAIN_MIN      8.0f
// 弯道最大增益（大角度）
#define PIXEL_GAIN_MAX     11.2f// 11.15f  
// 动态像素增益 独立角度限幅（仅控制灵敏度变化范围）
#define ANGLE_LIMIT_FOR_PIXEL_GAIN    50.0f 
// 像素增益：角度偏差≥5°才开始动态增大
#define PIXEL_GAIN_START_ANGLE    10.0f   


// 转向差速计算 角度限幅（仅用于转向控制，控制转向范围）
// #define ANGLE_LIMIT_FOR_STEER    90.0f
// 像素偏差限制
#define MAX_PIXEL_ERR       100.0f


// ==================== PWM 每帧最大变化限制 ====================
#define PWM_CHANGE_LIMIT    2500     // 最大变化量

// ==================== 红色速度减益系数 ====================
// #define RED_SPEED_DECREASE_RATIO   0.5f  // 速度减益阈值，=1 不减速，调小减速


// ==================== 电机死区 PWM ====================
#define MOTOR_L_BIAS_PWM   550    // 左轮死区 PWM
#define MOTOR_R_BIAS_PWM   550    // 右轮死区 PWM


// 速度与硬件限制
#define MAX_SPEED_CM_S      600.0f  // 车轮最大速度限制
#define WHEEL_TRACK         15.35f  // 左右轮轮距（cm，需实测）


// ==================== PWM ↔ 速度 转换公式（固定不变） ====================
// PWM 转换为 厘米/秒：1000PWM = 100cm/s → 1PWM = 0.1cm/s
#define PWM_TO_CM_S(pwm)    ((float)(pwm) * 0.1f)
// 厘米/秒 转换为 PWM：逆运算
#define CM_S_TO_PWM(speed)  ((float)(speed) * 10.0f)

// 外部声明红色检测、绕行标志位
extern bool red_detected_flag;
extern bool target_avoid_running;

// ==================== 差速转向控制结构体 ====================
/**
 * @brief 差速转向全局参数结构体
 * 存储所有运行参数、PID控制器、输出PWM等
 */
typedef struct
{
    PID* left_speed_pid;    // 左轮速度环PID控制器指针
    PID* right_speed_pid;   // 右轮速度环PID控制器指针

    int16 base_pwm;         // 动态计算的基础PWM（随角度自动变化）
    int16 base_pwm_max;     // 基础PWM最大值（90°直行）
    int16 base_pwm_min;     // 基础PWM最小值（弯道）

    int16_t left_pwm;       // 左轮最终输出PWM
    int16_t right_pwm;      // 右轮最终输出PWM

    int16_t last_left_pwm;      // 上一次左轮PWM
    int16_t last_right_pwm;     // 上一次右轮PWM
    uint16_t max_left_change;   // 左轮历史最大变化量（无符号，防溢出）
    uint16_t max_right_change;  // 右轮历史最大变化量（无符号，防溢出）

    float left_pid_output_cm_s;   // 左轮PID增量累加值（增量式PID必须保存）
    float right_pid_output_cm_s;  // 右轮PID增量累加值

    // ==================== 无效赛道控制变量 ====================
    int16_t last_valid_left_pwm;   // 【有效赛道】最后一次左轮PWM
    int16_t last_valid_right_pwm;  // 【有效赛道】最后一次右轮PWM
    bool invalid_track_mode;       // 无效赛道模式标志
    float invalid_track_start_dist;// 无效赛道开始时的行驶距离(cm)
        // ==================== 无效赛道渐进差速控制变量 ====================
    int16_t invalid_base_pwm;       // 无效模式的基础 PWM（由有效 PWM 均值 × 减速系数计算）
    int16_t invalid_step_count;     // 已执行的差速步数（每帧 +1）
    uint8_t invalid_turn_dir;       // 转向方向标识：0 → 左转（向右回转），1 → 右转（向左回转）
    uint8_t recover_transition_frames;  // 从无效赛道恢复后，剩余需要进行柔性过渡的帧数
                                        // 值 > 0 表示还在过渡期，每一帧都会对转向差速进行缩放
                                        // 每处理一帧自动减 1，直到 0 恢复正常控制

    // 上电就绪延时变量
    uint32_t start_tick;
    bool ready_run;

    // ==================== 按键发车2秒倒计时变量 ====================
    uint32_t countdown_start_tick;  // 发车倒计时起始时间戳
    bool countdown_finished;        // 发车倒计时是否完成标志

} Diff_Steer_Handle;

// 全局结构体声明，外部文件可调用
extern Diff_Steer_Handle diff_steer;

// ==================== 函数声明 ====================
/**
 * @brief  差速转向初始化
 * @param  base_pwm_max 最大基础速度PWM
 * @param  base_pwm_min 最小基础速度PWM
 */
void Diff_Steer_Init(int16 base_pwm_max, int16 base_pwm_min);

/**
 * @brief  差速转向主控制函数
 * @param  line_deviation  中线像素偏移量
 * @param  steer_angle_deg 赛道中线拟合角度
 */
void Diff_Steer_Control(float line_deviation, float steer_angle_deg);


/**
 * @brief 无效赛道处理核心函数
 * @note 无有效最长白列时调用：记录行驶距离、超时停车、交换PWM行驶
 */
void handle_invalid_track(void);

/**
 * @brief 有效赛道恢复函数
 * @note 重新检测到有效赛道时调用：关闭无效模式
 */
void recover_valid_track(void);


/**
 * @brief  停止电机并清空状态（紧急刹车/停车）
 */
void Diff_Steer_Stop(void);


/**
 * @brief 直接输入左右目标PWM，走速度PID闭环输出电机（遥控/手动模式专用）
 * @param target_left_pwm 左轮目标PWM
 * @param target_right_pwm 右轮目标PWM
 */
void Diff_Steer_Control_DirectPWM(int16_t target_left_pwm, int16_t target_right_pwm);


// ==================== 无效赛道配置 ====================
// ==================== 无效赛道出界返回参数 ====================
// 当小车冲出赛道、中线丢失时，启用“出界返回”策略
// 该策略基于最后一次有效行驶状态，以渐进差速的方式让小车回转找回赛道
#define INVALID_TRACK_MAX_DIST   31.0f  // 无效赛道最大行驶距离

#define INVALID_RETURN_DECEL_RATIO  0.8f  // 出界后的速度衰减系数，避免高速冲出
#define INVALID_PWM_STEP            70   // 每一次累加/累减的 PWM 步长
#define INVALID_MAX_DIFF            300  // 累计最大差速值（达到后不再增加）
#define INVALID_PWM_MAX             2400  // 无效模式下 PWM 输出上限（保护电机）
#define INVALID_PWM_MIN             1300   // 无效模式下 PWM 输出下限
// 过渡总帧数
#define TRANSITION_TOTAL_FRAMES  7


#endif
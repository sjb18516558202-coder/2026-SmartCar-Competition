/**
 * @file Image.cpp
 * @brief 智能车视觉循迹核心实现文件
 * @details 包含二值化、巡边、最长白列检测、曲率半径计算等核心功能
 * @author 适配逐飞SDK智能车开发
 * @date 2026-03
 */
#include "Image.hpp"
#include <cstdlib>   // 用于abs函数
#include <float.h>   // 用于FLT_MAX（float类型最大值）
#include <cmath>     // 用于atan2f、sqrt等数学函数
#include <cstring>   // 用于memset函数（重置时间统计）

#include "inflection_detect.hpp"

#include "DiffSteering.hpp"

// ===================== 全局变量实例化（内存分配+初始化） =====================
/**
 * @brief 循线偏差（像素）- 实例化并初始化为0
 * @note 正数表示中线偏右，负数偏左，供转向控制算法使用
 */
float line_deviation = 0.0f;   

/**
 * @brief 拟合斜率 - 实例化并初始化为0
 * @note 最小二乘法拟合中线的斜率，初始值为0表示水平直线
 */
float fit_slope = 0.0f;        

/**
 * @brief 拟合角度（度）- 实例化并初始化为0
 * @note 初始值0°表示水平向右，适配直道初始状态
 */
float fit_angle = 0.0f;        

/**
 * @brief IPS200屏幕对象实例化
 * @note 分配内存，初始化默认值；需在屏幕初始化函数中配置显示参数
 */
zf_device_ips200 ips200_obj;

/**
 * @brief UVC摄像头对象实例化
 * @note 分配内存，初始化默认值；需在摄像头初始化函数中配置分辨率、帧率等
 */
zf_device_uvc uvc_obj;

/**
 * @brief 二值化图像缓存数组实例化并初始化
 * @note 所有像素初始化为0（黑色），尺寸160*120=19200字节；
 *       初始化避免随机值导致二值化错误
 */
uint8 binary_image[GRAY_IMAGE_HEIGHT][GRAY_IMAGE_WIDTH] = {0};

/**
 * @brief 左边界数组实例化
 * @note 编译器默认初始化为0，存储每行赛道左边界的列坐标
 */
uint8 left_line_list[GRAY_IMAGE_HEIGHT] = {0};

/**
 * @brief 右边界数组实例化
 * @note 编译器默认初始化为0，存储每行赛道右边界的列坐标
 */
uint8 right_line_list[GRAY_IMAGE_HEIGHT] = {0};

/**
 * @brief 中线数组实例化
 * @note 编译器默认初始化为0，存储每行赛道中线的列坐标
 */
uint8 mid_line_list[GRAY_IMAGE_HEIGHT] = {0};

/**
 * @brief 最终输出中线实例化并初始化
 * @note 初始值为图像水平中心（80像素），保证上电默认值稳定；
 *       避免小车上电后中线值随机导致失控
 */
uint8 mid_line = GRAY_IMAGE_WIDTH / 2;

/**
 * @brief 最长白色列长度实例化并初始化
 * @note 初始值0，每次循迹都会重新计算
 */
uint8 max_white_col_length = 0;

/**
 * @brief 巡边搜索截止行实例化并初始化
 * @note 初始值0，默认处理全部行；每次循迹根据最长白列更新
 */
uint8 search_cutoff_row = 0;

/**
 * @brief 曲率半径实例化并初始化
 * @note 初始值为FLT_MAX（float最大值），表示上电默认视为直线；
 *       避免上电初期曲率半径异常导致速度/转向控制错误
 */
float curve_radius = FLT_MAX;

/**
 * @brief 二值化阈值常量实例化
 * @note 绑定宏定义值，const修饰保证只读，防止运行时误修改；
 *       嵌入式场景建议使用const替代#define，提升类型安全性
 */
const uint8 BINARY_THRESHOLD = FIXED_BINARY_THRESHOLD;


/**
 * @brief 大津法阈值全局变量实例化
 * @note 初始化为固定阈值，首次调用大津法后更新为自适应值
 */
uint8 otsu_threshold = FIXED_BINARY_THRESHOLD; 

// 最长白列失效标记：true=无有效白色列（强制中心中线）
bool  max_white_col_invalid = false;
// 最长白列列坐标
uint8 max_white_col_pos = GRAY_IMAGE_WIDTH / 2;


// **********************************************************
// 函数名：find_longest_white_column
// 功能：查找二值图像中最长的白色列（从底部向上数连续白色像素）
// 入参：img-输入二值化图像指针（binary_image数组）
// 返回值：无（结果存入max_white_col_length和search_cutoff_row）
// **********************************************************
void find_longest_white_column(const uint8 *img)
{
    // 入参校验：空指针直接返回，避免程序崩溃（嵌入式必做防护）
    if(img == NULL)
    {
        max_white_col_length = 0;          // 无图像时长度置0
        search_cutoff_row = GRAY_IMAGE_HEIGHT - 1;// 兜底：处理全部行
        return;
    }

    uint8 max_length = 0;                 // 临时变量：记录最长白列长度
    const uint8 bottom_row = GRAY_IMAGE_HEIGHT - 1; // 图像底部行索引（119）
    //max_white_col_pos = GRAY_IMAGE_WIDTH / 2;    // 默认中心列
    max_white_col_invalid = false;        // 默认有效

    // 第一步：遍历每一列（水平方向，0~159）
    for(uint16 col = 0; col < GRAY_IMAGE_WIDTH; col++)
    {
        uint8 curr_length = 0; // 临时变量：当前列的白色像素长度

        // 第二步：从底部行向上遍历，统计连续白色像素
        // 遍历范围：底部行 → 顶部行（119→0），仅统计赛道有效区域
        for(int16 row = bottom_row; row >= 0; row--)
        {
            // 判断当前像素是否为白色（赛道）
            if(GET_IMAGE_PIXEL(img, row, col) == 255)
            {
                curr_length++; // 白色则长度+1
            }
            else
            {
                break; // 遇到黑色（背景），停止当前列统计（向上无赛道）
            }
        }

        // 第三步：更新最长长度（保留最大值）
        if(curr_length > max_length)
        {
            // 绕行模式：放开边界限制
            // 正常模式：保持 60~100 限制
            if(target_avoid_running) // 绕行模式：仅放开单侧边界
            { 
                // 绕行：放开边界限制
                 bool col_valid = false;
                switch(target_avoid_class)
                {
                    case 0: 
                        // 物资右侧绕行：放开左侧边界，右边界保持原始限制
                        col_valid = (col >= 5 && col <= MAX_WHITE_COL_RIGHT_LIMIT);
                        break;

                    case 1: 
                        // 载具直行：保持原始中间搜索范围
                        col_valid = (col >= MAX_WHITE_COL_LEFT_LIMIT && col <= MAX_WHITE_COL_RIGHT_LIMIT);
                        break;
                         
                    case 2: 
                        // 武器左侧绕行：放开右侧边界，左边界保持原始限制
                        col_valid = (col >= MAX_WHITE_COL_LEFT_LIMIT && col <= GRAY_IMAGE_WIDTH - 5);
                        break;
                        
                    default:
                        // 异常类别：兜底走原始中间范围，安全优先
                        col_valid = (col >= MAX_WHITE_COL_LEFT_LIMIT && col <= MAX_WHITE_COL_RIGHT_LIMIT);
                        // 调试期可打开，比赛时注释
                        // printf("[警告] 绕行类别异常: %d，最长白列保持默认范围\n", target_avoid_class);
                        break;
                }
                if(col_valid)
                {
                    max_length = curr_length;
                    max_white_col_pos = col;
                }
            }
            else
            {
                // 正常循迹：限制 60~100 列
                if(col >= MAX_WHITE_COL_LEFT_LIMIT && col <= MAX_WHITE_COL_RIGHT_LIMIT)
                {
                    max_length = curr_length;
                    max_white_col_pos = col;
                }
            }
        }
    }

    // 第四步：赋值给全局变量，供其他函数使用
    max_white_col_length = max_length;

    // 无有效最长白列
    if(max_length == 0)
    {
        max_white_col_invalid = true;
        search_cutoff_row = 0;
    }
    else
    {
        max_white_col_invalid = false;
        // 第五步：计算搜索截止行（核心优化点）
        search_cutoff_row = bottom_row - max_length + 1;

        // 当截止行小于设定行时，强制设为设定行
        if(search_cutoff_row < MIN_CUTOFF_ROW)
        {
            search_cutoff_row = MIN_CUTOFF_ROW;
        }

        // 二次防护：避免截止行超出有效范围（嵌入式必做）
        if(search_cutoff_row > bottom_row) search_cutoff_row = bottom_row;
        if(search_cutoff_row < 0) search_cutoff_row = 0;
    }
}

// **********************************************************
// 函数名：gray_image_binaryzation
// 功能：灰度图像转二值图像（区分赛道和背景）
// 入参：src_gray-输入灰度图像指针；dst_binary-输出二值图像指针
//       width-图像宽度；height-图像高度
// 返回值：无
// **********************************************************
void gray_image_binaryzation(const uint8 *src_gray, uint8 *dst_binary, uint16 width, uint16 height)
{
    // 入参校验：空指针/无效尺寸直接返回，避免内存越界
    if(src_gray == NULL || dst_binary == NULL || width == 0 || height == 0)
        return;

    // 调用大津法自适应二值化（偏置+0，可根据赛道调整）
    // adaptive_binaryzation(src_gray, dst_binary, width, height, OTSU_THRESHOLD_BIAS);
    
    // OpenCV大津法
    // 1. OpenCV仅用来算OTSU阈值，不生成二值图（最快用法）
    cv::Mat small_gray(height, width, CV_8UC1, (void *)src_gray);
    double otsu_raw = cv::threshold(small_gray, small_gray, 0, 255, 
                                    cv::THRESH_BINARY | cv::THRESH_OTSU);
    // 2. 阈值加偏置，限幅0~255
    int16 final_th = (int16)otsu_raw + OTSU_THRESHOLD_BIAS;
    if(final_th < 0)    final_th = 0;
    if(final_th > 255)  final_th = 255;
    otsu_threshold = (uint8)final_th;
    // 3. 纯C单层循环二值，仅遍历1次像素，无第二次opencv运算
    uint32 pix_cnt = (uint32)width * height;
    for(uint32 i = 0; i < pix_cnt; i++)
    {
        dst_binary[i] = (src_gray[i] > final_th) ? 255 : 0;
    }

    // 块大小 9x9，微调 C=3（智能车最常用参数）
    // local_mean_binary(src_gray, dst_binary, width, height, 9, 3);

    // 以下为搜索截止行备用代码（注释状态）
    // 遍历所有像素：一维数组遍历（效率高于二维，嵌入式优选）
    // 总像素数：width*height（160*120=19200）
    // printf("固定二值化阈值: %d\r\n", BINARY_THRESHOLD);
    // for(uint32 i = 0; i < (uint32)width * height; i++)
    // {
    //     // 二值化核心逻辑：三元运算符简化代码，提升执行效率
    //     // 灰度值 > 阈值 → 255（白/赛道）；否则 → 0（黑/背景）
    //     dst_binary[i] = (src_gray[i] > BINARY_THRESHOLD) ? 255 : 0;
    // }
}

/**
 * @brief 大津法（Otsu）自适应阈值计算（隔点采样优化版）
 * @param image  输入灰度图像指针（一维数组，大小 = 宽 × 高）
 * @param width  图像宽度（像素）
 * @param height 图像高度（像素）
 * @return 最优二值化阈值（0~255），异常时返回默认固定阈值
 * @note  适用于智能车赛道灰度图像处理，通过隔点采样大幅降低计算量
 */
uint8 OtsuThreshold(const uint8 *image, uint16 width, uint16 height)
{
    // ===================== 1. 入参合法性判断 =====================
    // 如果图像指针为空 或 宽/高为0，直接返回默认阈值，防止程序崩溃
    if(image == NULL || width == 0 || height == 0)
        return FIXED_BINARY_THRESHOLD;

    // ===================== 2. 宏定义配置区（可根据赛道调整） =====================
    #define SAMPLING_STEP    3       // 隔点采样步长：2=隔1采1，4=隔3采1，1=不采样
    #define GRAY_MIN         40      // 赛道有效最小灰度值（过滤过暗的无效区域）
    #define GRAY_MAX         215     // 赛道有效最大灰度值（过滤过亮的反光区域）

    // ===================== 3. 变量定义 =====================
    // 灰度直方图数组：只统计 GRAY_MIN~GRAY_MAX 之间的灰度，节省单片机内存
    uint32 hist[GRAY_MAX - GRAY_MIN + 1] = {0};

    uint8  best_threshold = FIXED_BINARY_THRESHOLD;  // 最终输出的最优阈值（默认值）
    double max_variance   = 0.0;                     // 记录最大类间方差（越大分割效果越好）

    // ===================== 4. 隔点采样 + 统计灰度直方图 =====================
    // 遍历图像所有像素，隔点采样，只统计有效灰度范围内的像素
    // i += SAMPLING_STEP：隔点采样核心，跳过部分像素，减少计算量
    for(uint16 i = MIN_CUTOFF_ROW; i < height; i++)  // 从截止行开始，不统计上方
    {
        // 每行隔点采样
        for(uint16 j = 0; j < width; j += SAMPLING_STEP)
        {
            uint32 index = i * width + j;          // 一维索引
            uint8  gray  = image[index];           // 当前像素灰度

            // 只统计有效灰度范围
            if(gray >= GRAY_MIN && gray <= GRAY_MAX)
            {
                hist[gray - GRAY_MIN]++;
            }
        }
    }
    // ===================== 5. 计算有效像素总灰度和 + 有效像素总数 =====================
    uint64 total_gray_sum = 0;  // 所有有效像素的灰度总和（64位防止溢出）
    uint32 valid_pixels   = 0;  // 有效灰度范围内的像素总个数

    // 遍历所有有效灰度，累加总灰度和与总像素数
    for(uint8 g = GRAY_MIN; g <= GRAY_MAX; g++)
    {
        uint32 cnt = hist[g - GRAY_MIN];  // 当前灰度的像素数量
        total_gray_sum += (uint64)cnt * g; // 总灰度和 = 数量 × 灰度值
        valid_pixels   += cnt;             // 累计有效像素总数
    }

    // 如果没有有效像素（全黑/全白/全不在范围内），直接返回默认阈值
    if(valid_pixels == 0)
        return FIXED_BINARY_THRESHOLD;

    // ===================== 6. 遍历所有可能阈值，计算类间方差找最优值 =====================
    uint32 foreground_pixels   = 0;  // 前景（赛道）累计像素数
    uint64 foreground_gray_sum  = 0;  // 前景累计灰度和
    double valid_pixels_d      = (double)valid_pixels; // 浮点化，避免整数除法错误

    // 遍历 GRAY_MIN 到 GRAY_MAX-1 所有可能的阈值
    for(uint8 t = GRAY_MIN; t < GRAY_MAX; t += SAMPLING_STEP)
    {
        uint32 cnt = hist[t - GRAY_MIN]; // 当前灰度t的像素数量

        // 把当前灰度t的像素归入前景，累计前景像素数
        foreground_pixels += cnt;

        // 如果前景像素为0，跳过本次计算（避免除0）
        if(foreground_pixels == 0)
            continue;

        // 累计前景灰度和
        foreground_gray_sum += (uint64)cnt * t;

        // ===================== 计算背景像素信息 =====================
        // 背景像素 = 总有效像素 - 前景像素
        uint32 background_pixels = valid_pixels - foreground_pixels;

        // 背景像素为0，说明后面全是前景，无需继续计算
        if(background_pixels == 0)
            break;

        // ===================== 大津法核心公式计算 =====================
        // w0：前景像素占总有效像素的比例（权重）
        double w0 = (double)foreground_pixels / valid_pixels_d;
        // w1：背景像素占总有效像素的比例（权重）
        double w1 = (double)background_pixels / valid_pixels_d;

        // u0：前景灰度平均值
        double u0 = (double)foreground_gray_sum / foreground_pixels;
        // u1：背景灰度平均值
        double u1 = (double)(total_gray_sum - foreground_gray_sum) / background_pixels;

        // 类间方差公式：方差越大，前景与背景区分越明显
        double variance = w0 * w1 * (u0 - u1) * (u0 - u1);

        // ===================== 更新最优阈值 =====================
        // 如果当前方差 > 历史最大方差（+1e-6 防止浮点精度误差）
        if(variance > max_variance + 1e-6)
        {
            max_variance   = variance;  // 更新最大方差
            best_threshold = t;         // 记录当前阈值为最优阈值
        }
    }

    // ===================== 7. 释放宏定义 + 返回结果 =====================
    #undef GRAY_MIN
    #undef GRAY_MAX
    #undef SAMPLING_STEP

    return best_threshold;
}

/**
 * @brief 大津法自适应二值化
 * @param src_gray 输入灰度图像指针
 * @param dst_binary 输出二值图像指针
 * @param width 图像宽度
 * @param height 图像高度
 * @param bias 阈值偏置（建议范围：-10 ~ +10，根据赛道调整）
 * @note 核心流程：
 *       1. 计算大津法基础阈值；
 *       2. 应用手动偏置并限制范围；
 *       3. 生成二值图像；
 *       4. 调试打印阈值，便于参数调优
 */
void adaptive_binaryzation(const uint8 *src_gray, uint8 *dst_binary, 
                           uint16 width, uint16 height, int8 bias)
{
    // 入参防护：空指针/无效尺寸直接返回
    if(src_gray == NULL || dst_binary == NULL || width == 0 || height == 0)
        return;

    // 1. 计算大津法阈值
    uint8 base_threshold = OtsuThreshold(src_gray, width, height);
    // 2. 应用偏置（限制偏置范围，避免阈值失控）
    int16 final_threshold = (int16)base_threshold + bias;
    // 3. 严格限制阈值范围（0~255），避免溢出
    final_threshold = final_threshold < 0 ? 0 : (final_threshold > 255 ? 255 : final_threshold);
    otsu_threshold = (uint8)final_threshold;

    // 打印大津法阈值 + 偏置 + 最终阈值
    printf("大津法基础阈值: %d | 偏置: %d | 最终阈值: %d\r\n", 
           base_threshold, bias, otsu_threshold);

    // 4. 快速二值化（一维遍历，嵌入式高效）
    uint32 total_pixels = (uint32)width * height;
    for(uint32 i = 0; i < total_pixels; i++)
    {
        // 灰度值>阈值 → 白色（赛道），否则 → 黑色（背景）
        dst_binary[i] = (src_gray[i] > otsu_threshold) ? 255 : 0;
    }
}


// ===================== 局部均值自适应二值化（你要的核心算法） =====================
// block_size 必须是奇数：3,5,7,9,11...
// C 是微调值：一般 3~5，越大黑色越多，越小白色越多
void local_mean_binary(const uint8 *src_gray, uint8 *dst_binary, 
                      uint16 width, uint16 height, uint8 block_size, int8 C)
{
    if(src_gray == NULL || dst_binary == NULL || width ==0 || height ==0)
        return;
    
    // 块半径
    int8 radius = block_size / 2;
    
    // 遍历每个像素
    for(int y=0; y<height; y++)
    {
        for(int x=0; x<width; x++)
        {
            int sum = 0;
            int count = 0;
            
            // 遍历以 (x,y) 为中心的局部块
            for(int dy = -radius; dy <= radius; dy++)
            {
                for(int dx = -radius; dx <= radius; dx++)
                {
                    int yy = y + dy;
                    int xx = x + dx;
                    
                    // 边界保护（不越界）
                    if(yy >=0 && yy < height && xx >=0 && xx < width)
                    {
                        sum += src_gray[yy * width + xx];
                        count++;
                    }
                }
            }
            
            // 局部均值作为阈值
            uint8 local_mean = sum / count;
            uint8 current_gray = src_gray[y * width + x];
            
            // 二值化：大于阈值=白(赛道)，否则黑
            if(current_gray > local_mean - C)
                dst_binary[y * width + x] = 255;
            else
                dst_binary[y * width + x] = 0;
        }
    }
}



// **********************************************************
// 【巡线方法1：中线继承法】
// 函数名：find_mid_line
// 功能：核心巡边函数（基于最长白列截止行优化）
// 入参：img-输入二值化图像指针（binary_image数组）
// 返回值：无（结果存入left/right/mid_line_list数组）
// **********************************************************
void find_mid_line(const uint8 *img)
{

    // 核心判断：最长白列失效 → 强制所有行设为中心中线，直接返回
    if(max_white_col_invalid)
    {
        // 遍历所有行，强制设为中心中线
        for(int16 i = 0; i < GRAY_IMAGE_HEIGHT; i++)
        {
            left_line_list[i] = 0;  // 左边界强制
            right_line_list[i] = GRAY_IMAGE_WIDTH - 1; // 右边界强制
            mid_line_list[i] = 80;        // 中线强制中心
        }
        mid_line = 80; // 底部行中线也强制中心
        return; // 跳过后续所有找线逻辑，提升效率
    }

    // 第一步：定义底部行相关变量（基础配置）
    const uint8 bottom_row = GRAY_IMAGE_HEIGHT - 1; // 底部行索引（119）
    uint8 left_bottom = 0;                   // 底部行左边界初始值（兜底）
    uint8 right_bottom = GRAY_IMAGE_WIDTH - 1;      // 底部行右边界初始值（兜底）
    uint8 left_found = 0;                    // 左边界找到标记（0=未找到，1=找到）
    uint8 right_found = 0;                   // 右边界找到标记

    // 第二步：底部行三级查找边界（优先级：中心→3/4→1/4）
    // 定义扫描位置数组：适配不同赛道偏移场景，减少无效扫描
    const uint8 scan_pos_list[] = {SCAN_POS_CENTER, SCAN_POS_3_4, SCAN_POS_1_4};
    // 遍历扫描位置：找到第一个有效位置就停止，节省算力
    for(uint8 pos : scan_pos_list)
    {
        // 检查当前扫描位置是否为赛道（白色）
        if(GET_IMAGE_PIXEL(img, bottom_row, pos) == 255)
        {
            // 找左边界：从扫描位置向左扫，找“黑→白”跳变（背景→赛道）
            for(int16 j = pos - 1; j > 0; j--)
            {
                if(GET_IMAGE_PIXEL(img, bottom_row, j) == 0 && GET_IMAGE_PIXEL(img, bottom_row, j+1) == 255)
                {
                    left_bottom = j;     // 记录左边界列号
                    left_found = 1;      // 标记找到
                    break;               // 找到后退出，节省算力
                }
            }

            // 找右边界：从扫描位置向右扫，找“白→黑”跳变（赛道→背景）
            for(int16 j = pos + 1; j < GRAY_IMAGE_WIDTH; j++)
            {
                if(GET_IMAGE_PIXEL(img, bottom_row, j) == 0 && GET_IMAGE_PIXEL(img, bottom_row, j-1) == 255)
                {
                    right_bottom = j;    // 记录右边界列号
                    right_found = 1;     // 标记找到
                    break;               // 找到后退出，节省算力
                }
            }

            // 左右边界都找到，退出扫描位置循环（无需继续扫描）
            if(left_found && right_found) 
                break;
        }
    }

    // 第三步：底部行边界兜底（未找到时强制设为0/159）
    if(!left_found) left_bottom = 0;
    if(!right_found) right_bottom = GRAY_IMAGE_WIDTH - 1;

    // 防护逻辑：防止左边界>右边界（异常情况，如赛道完全丢失）
    if(left_bottom > right_bottom)
    {
        left_bottom = 0;
        right_bottom = GRAY_IMAGE_WIDTH - 1;
    }

    // 第四步：保存底部行边界和中线到数组
    left_line_list[bottom_row] = left_bottom;
    right_line_list[bottom_row] = right_bottom;
    mid_line_list[bottom_row] = (left_bottom + right_bottom) / 2;

    // 第五步：上方行中线继承巡边（核心优化：仅处理到截止行）
    // 遍历范围：底部倒数第二行 → 搜索截止行（118→search_cutoff_row）
    // 优化点：不再遍历到顶部行，减少无效计算（提升约30%巡边效率）
    for(int16 i = bottom_row - 1; i >= (int16)search_cutoff_row; i--)
    {
        // 继承下一行（更靠近底部）的中线：作为当前行扫描中心（稳定巡边）
        uint8 prev_mid = mid_line_list[i + 1];
        // 当前行左/右边界初始值（兜底）
        uint8 curr_left = 0, curr_right = GRAY_IMAGE_WIDTH - 1;
        // 当前行边界找到标记
        uint8 curr_left_found = 0, curr_right_found = 0;

        // 找左边界：基于继承中线向左扫，找“黑→白”跳变
        for(int16 j = prev_mid - 1; j > 0; j--)
        {
            if(GET_IMAGE_PIXEL(img, i, j) == 0 && GET_IMAGE_PIXEL(img, i, j+1) == 255)
            {
                curr_left = j;
                curr_left_found = 1;
                break;
            }
        }

        // 找右边界：基于继承中线向右扫，找“白→黑”跳变
        for(int16 j = prev_mid + 1; j < GRAY_IMAGE_WIDTH; j++)
        {
            if(GET_IMAGE_PIXEL(img, i, j) == 0 && GET_IMAGE_PIXEL(img, i, j-1) == 255)
            {
                curr_right = j;
                curr_right_found = 1;
                break;
            }
        }

        // 上方行边界兜底
        if(!curr_left_found) curr_left = 0;
        if(!curr_right_found) curr_right = GRAY_IMAGE_WIDTH - 1;

        // 防护逻辑：防止左边界>右边界
        if(curr_left > curr_right)
        {
            curr_left = 0;
            curr_right = GRAY_IMAGE_WIDTH - 1;
        }

        // 保存当前行边界和中线
        left_line_list[i] = curr_left;
        right_line_list[i] = curr_right;
        // mid_line_list[i] = (curr_left + curr_right) / 2;
    }

    // // ===================== 从底行向上 中线差值限制 =====================
    // // 规则：下面的行 = 基准
    // //      上面的行 = 只能跟着下面走，绝不允许反过来带偏底行
    // for (int16 i = bottom_row - 1; i >= (int16)search_cutoff_row; i--)
    // {
    //     int16 base_mid = (int16)mid_line_list[i + 1];  // 下行（基准）
    //     int16 curr_mid = (int16)mid_line_list[i];       // 当前行（要被修正）
    //     // int16 old_mid  = curr_mid;  

    //     // 计算偏移差
    //     int16 diff = curr_mid - base_mid;

    //     // 差值超限：强制把当前行“拉回”到基准附近
    //     if (abs(diff) > MID_LINE_DIFF_THRESHOLD)
    //     {
    //         if (diff > 0)
    //         {
    //             // 当前偏右 → 限制为 base + 阈值
    //             curr_mid = base_mid + MID_LINE_DIFF_THRESHOLD;
    //         }
    //         else
    //         {
    //             // 当前偏左 → 限制为 base - 阈值
    //             curr_mid = base_mid - MID_LINE_DIFF_THRESHOLD;
    //         }
    //     }

    //     // 边界保护
    //     if (curr_mid < 0) curr_mid = 0;
    //     if (curr_mid >= GRAY_IMAGE_WIDTH) curr_mid = GRAY_IMAGE_WIDTH - 1;

    //     // 写回限制后的中线
    //     mid_line_list[i] = (uint8)curr_mid;

    //     //     printf("[行%3d] 基准(下一行)=%2d | 原始=%2d | 修正后=%2d | 差值=%2d | 阈值=%d | %s\n",
    //     //    i,
    //     //    base_mid,
    //     //    old_mid,
    //     //    curr_mid,
    //     //    diff,
    //     //    MID_LINE_DIFF_THRESHOLD,
    //     //    (abs(diff) > MID_LINE_DIFF_THRESHOLD) ? "已修正" : "正常");
    // }

    // ========== 清空截止行以上的无效行数据 ==========
    // 遍历范围：0行 → search_cutoff_row-1行（所有无效行）
    for(int16 i = 0; i < (int16)search_cutoff_row; i++)
    {
        // 清空无效行的边界和中线（设为无效值，避免干扰曲率计算）
        left_line_list[i] = 0;          // 左边界置0（无效标记）
        right_line_list[i] = 159;       // 右边界置159（无效标记）
        mid_line_list[i] = GRAY_IMAGE_WIDTH/2; // 中线置中心（避免跳变）
    }

    // 第七步：最终输出中线（底部行中线，最稳定）
    // mid_line = mid_line_list[bottom_row];
}

// **********************************************************
// 【巡线方法2：最长白列核心版】
// 函数名：find_mid_line_
// 功能：核心巡边函数（仅从底行到巡边截止行巡线）
//       核心增强：1. 最长白列失效时强制中心中线 2. 仅处理[截止行, 底行]范围
// 入参：img-输入二值化图像指针（binary_image数组）
// **********************************************************
void find_mid_line_white(const uint8 *img)
{
    const uint8 bottom_row = GRAY_IMAGE_HEIGHT - 1; // 图像底部行索引（119）
    const uint8 center_col = GRAY_IMAGE_WIDTH / 2;  // 图像中心列坐标（80）

    // 核心判断：最长白列失效 → 强制所有行设为中心中线，直接返回
    if(max_white_col_invalid)
    {
        // 遍历所有行，强制设为中心中线
        for(int16 i = 0; i < GRAY_IMAGE_HEIGHT; i++)
        {
            left_line_list[i] = 0;  // 左边界强制
            right_line_list[i] = GRAY_IMAGE_WIDTH - 1; // 右边界强制
            mid_line_list[i] = center_col;        // 中线强制中心
        }
        mid_line = center_col; // 底部行中线也强制中心
        return; // 跳过后续所有找线逻辑，提升效率
    }

    // ========== 仅处理「巡边截止行 ~ 底部行」范围的巡线 ==========
    // 初始化：仅清空截止行以上的数组（避免脏数据），不参与巡边
    for(int16 i = 0; i < (int16)search_cutoff_row; i++)
    {
        left_line_list[i] = 0;
        right_line_list[i] = GRAY_IMAGE_WIDTH - 1;
        mid_line_list[i] = center_col; // 截止行以上强制中心，不参与后续计算
    }

    // ========== 底部行（最后一行）边界查找 ==========
    uint8 left_bottom = 0;                   // 底部行左边界：初始化为0
    uint8 right_bottom = GRAY_IMAGE_WIDTH - 1;      // 底部行右边界：初始化为159
    uint8 left_found = 0;                    // 左边界找到标志：0=未找到，1=找到
    uint8 right_found = 0;                   // 右边界找到标志：0=未找到，1=找到

    // 核心参考点：最长白列列坐标（已限制在60~100范围内）
    uint8 core_scan_pos = max_white_col_pos; 
    if(GET_IMAGE_PIXEL(img, bottom_row, core_scan_pos) == 255)
    {
        // 找左边界：从最长白列向左扫，找“黑→白”跳变（背景→赛道）
        for(int16 j = core_scan_pos - 1; j >= 0; j--)
        {
            if(GET_IMAGE_PIXEL(img, bottom_row, j) == 0 && 
               GET_IMAGE_PIXEL(img, bottom_row, j+1) == 255)
            {
                left_bottom = j;
                left_found = 1;
                break;
            }
        }

        // 找右边界：从最长白列向右扫，找“白→黑”跳变（赛道→背景）
        for(int16 j = core_scan_pos + 1; j < GRAY_IMAGE_WIDTH; j++)
        {
            if(GET_IMAGE_PIXEL(img, bottom_row, j) == 0 && 
               GET_IMAGE_PIXEL(img, bottom_row, j-1) == 255)
            {
                right_bottom = j;
                right_found = 1;
                break;
            }
        }
    }

    // 底部行边界兜底：未找到则使用初始值
    if(!left_found) left_bottom = 0;
    if(!right_found) right_bottom = GRAY_IMAGE_WIDTH - 1;
    // 防护：左边界不能大于右边界
    if(left_bottom > right_bottom)
    {
        left_bottom = 0;
        right_bottom = GRAY_IMAGE_WIDTH - 1;
    }

    // 保存底部行边界和中线（中线=（左+右）/2）
    left_line_list[bottom_row] = left_bottom;
    right_line_list[bottom_row] = right_bottom;
    mid_line_list[bottom_row] = (left_bottom + right_bottom) / 2;

    // ========== 「巡边截止行 ~ 底部行-1」范围的逐行巡线 ==========
    // 仅遍历截止行到底部行的上一行，完全跳过截止行以上的区域
    for(int16 i = bottom_row - 1; i >= (int16)search_cutoff_row; i--)
    {
        uint8 curr_left = 0, curr_right = GRAY_IMAGE_WIDTH - 1; // 当前行边界初始值
        uint8 curr_left_found = 0, curr_right_found = 0; // 当前行边界找到标志

        // 基于最长白列搜索当前行边界（仅在有效范围内）
        if(GET_IMAGE_PIXEL(img, i, core_scan_pos) == 255)
        {
            // 左边界：当前行最长白列位置向左找“黑→白”
            for(int16 j = core_scan_pos - 1; j >= 0; j--)
            {
                if(GET_IMAGE_PIXEL(img, i, j) == 0 && 
                   GET_IMAGE_PIXEL(img, i, j+1) == 255)
                {
                    curr_left = j;
                    curr_left_found = 1;
                    break;
                }
            }

            // 右边界：当前行最长白列位置向右找“白→黑”
            for(int16 j = core_scan_pos + 1; j < GRAY_IMAGE_WIDTH; j++)
            {
                if(GET_IMAGE_PIXEL(img, i, j) == 0 && 
                   GET_IMAGE_PIXEL(img, i, j-1) == 255)
                {
                    curr_right = j;
                    curr_right_found = 1;
                    break;
                }
            }
        }

        // 上方行边界兜底：未找到则使用初始值
        if(!curr_left_found) curr_left = 0;
        if(!curr_right_found) curr_right = GRAY_IMAGE_WIDTH - 1;
        // 防护：左边界不能大于右边界
        if(curr_left > curr_right)
        {
            curr_left = 0;
            curr_right = GRAY_IMAGE_WIDTH - 1;
        }

        // 保存当前行边界和中线
        left_line_list[i] = curr_left;
        right_line_list[i] = curr_right;
        // mid_line_list[i] = (curr_left + curr_right) / 2;

        // // 中线差值限制（防跳变）：相邻行中线差值不能超过阈值
        // int16 curr_mid = (int16)mid_line_list[i];
        // int16 next_mid = (int16)mid_line_list[i+1];
        // int16 mid_diff = abs(curr_mid - next_mid);

        // if(mid_diff > MID_LINE_DIFF_THRESHOLD)
        // {
        //     // 差值超限：将当前行中线调整为相邻行中线±阈值
        //     if(curr_mid > next_mid)
        //     {
        //         curr_mid = next_mid + MID_LINE_DIFF_THRESHOLD;
        //     }
        //     else
        //     {
        //         curr_mid = next_mid - MID_LINE_DIFF_THRESHOLD;
        //     }

        //     // 防溢出：中线不能小于0或大于图像宽度-1
        //     if(curr_mid < 0) curr_mid = 0;
        //     if(curr_mid >= GRAY_IMAGE_WIDTH) curr_mid = GRAY_IMAGE_WIDTH - 1;
        //     mid_line_list[i] = (uint8)curr_mid;
        // }
    }
}
 

// **********************************************************
// 【巡线方法3：阶梯巡线法】
// 函数名：find_mid_line_white
// 功能：核心巡边函数（阶梯式搜索+跳行优化，仅处理[截止行, 底行]范围）
// 核心规则（严格执行）：
//  1. 最长白列失效 → 强制所有行设为中心中线，直接返回
//  2. 仅处理[巡边截止行, 底行]范围，从下向上逐行巡线
//  3. 底部行：从最长白列向左右扫描，找「白→黑」跳变确定边界
//  4. 上方行：阶梯式搜索（基于下行边界偏移）
//      阶梯搜索失败（任意边界未找到）：仅未找到的边界赋初始值，当前行不重新扫描
//      c上一行(i+1)：从最长白列全范围扫描，彻底兜底保证不丢线
//  5. 支持跳行功能：跳过指定行数，直接继承下一行X坐标
// 入参：img-输入二值化图像指针（binary_image数组）
// **********************************************************
void find_mid_line_step(const uint8 *img)
{
    // ===================== 基础常量定义 =====================
    const uint8 bottom_row = GRAY_IMAGE_HEIGHT - 1;  // 图像底部行索引（119）
    const uint8 center_col = GRAY_IMAGE_WIDTH / 2;   // 图像水平中心列（80）
    const uint8 core_col = max_white_col_pos;        // 最长白列核心扫描点（60~100列）

    // ===================== 规则1：最长白列失效处理 =====================
    // 无有效白色列 → 强制所有行设为中心中线，直接返回，跳过所有巡线逻辑
    if(max_white_col_invalid)
    {
        // 遍历图像所有行，强制赋值边界+中线
        for(int16 i = 0; i < GRAY_IMAGE_HEIGHT; i++)
        {
            left_line_list[i] = 0;                          // 左边界强制最左侧
            right_line_list[i] = GRAY_IMAGE_WIDTH - 1;       // 右边界强制最右侧
            mid_line_list[i] = center_col;                   // 中线强制图像中心
        }
        mid_line = center_col;  // 最终输出中线设为中心
        return;                 // 退出函数，提升运行效率
    }

    // ===================== 规则2：初始化无效行数据 =====================
    // 仅清空【截止行以上】的区域，该区域无赛道，不参与巡线计算
    for(int16 i = 0; i < (int16)search_cutoff_row; i++)
    {
        left_line_list[i] = 0;
        right_line_list[i] = GRAY_IMAGE_WIDTH - 1;
        mid_line_list[i] = center_col;
    }

    // ===================== 规则3：底部行（最后一行）边界查找 =====================
    uint8 left_bottom = 0;                   // 底部行左边界初始值（兜底：最左侧）
    uint8 right_bottom = GRAY_IMAGE_WIDTH - 1;// 底部行右边界初始值（兜底：最右侧）
    uint8 left_found = 0;                    // 左边界找到标志：0=未找到，1=找到
    uint8 right_found = 0;                   // 右边界找到标志：0=未找到，1=找到

    // 仅当最长白列位置是白色（赛道）时，才进行边界扫描
    if(GET_IMAGE_PIXEL(img, bottom_row, core_col) == 255)
    {
        // -------------------- 找左边界：从最长白列向左扫，找「白→黑」跳变 --------------------
        // 逻辑：赛道(白)→背景(黑)的跳变点，即为左边界
        for(int16 j = core_col; j >= 1; j--)
        {
            if(GET_IMAGE_PIXEL(img, bottom_row, j) == 255 &&
               GET_IMAGE_PIXEL(img, bottom_row, j-1) == 0)
            {
                left_bottom = j-1;    // 记录左边界坐标
                left_found = 1;       // 标记左边界已找到
                break;                // 找到即退出，节省算力
            }
        }

        // -------------------- 找右边界：从最长白列向右扫，找「白→黑」跳变 --------------------
        // 逻辑：赛道(白)→背景(黑)的跳变点，即为右边界
        for(int16 j = core_col; j < GRAY_IMAGE_WIDTH - 1; j++)
        {
            if(GET_IMAGE_PIXEL(img, bottom_row, j) == 255 &&
               GET_IMAGE_PIXEL(img, bottom_row, j+1) == 0)
            {
                right_bottom = j+1;   // 记录右边界坐标
                right_found = 1;      // 标记右边界已找到
                break;                // 找到即退出，节省算力
            }
        }
    }

    // -------------------- 底部行边界兜底：未找到则使用初始值 --------------------
    if(!left_found)  left_bottom = 0;
    if(!right_found) right_bottom = GRAY_IMAGE_WIDTH - 1;

    // -------------------- 防护逻辑：左边界绝对不能大于右边界 --------------------
    if(left_bottom > right_bottom)
    {
        left_bottom = 0;
        right_bottom = GRAY_IMAGE_WIDTH - 1;
    }

    // -------------------- 保存底部行边界和中线 --------------------
    left_line_list[bottom_row] = left_bottom;
    right_line_list[bottom_row] = right_bottom;
    mid_line_list[bottom_row] = (left_bottom + right_bottom) / 2;

    // ===================== 规则4：「截止行 ~ 底部行-1」阶梯式逐行巡线 =====================
    // 遍历方向：从下向上（底部行-1 → 巡边截止行），仅处理有效赛道区域
    for(int16 i = bottom_row - 1; i >= (int16)search_cutoff_row; i--)
    {
        // 当前行边界初始化（兜底值）
        uint8 curr_left = 0, curr_right = GRAY_IMAGE_WIDTH - 1;
        uint8 curr_left_found = 0, curr_right_found = 0;

        // ===================== 规则5：跳行功能实现 =====================
        // 配置SKIP_ROW>0时，跳过指定行数，直接继承下一行X坐标
        if(SKIP_ROW > 0 && (i % (SKIP_ROW + 1) != 0))
        {
            // 跳行：直接继承【下一行】的左右边界（y坐标偏移，x坐标不变）
            curr_left = left_line_list[i + 1];
            curr_right = right_line_list[i + 1];
            curr_left_found = 1;
            curr_right_found = 1;
        }
        else
        {
            // ===================== 非跳行：阶梯式搜索边界 =====================
            // 继承【下一行】的边界作为阶梯搜索基准点
            uint8 prev_left = left_line_list[i + 1];   // 下行左边界
            uint8 prev_right = right_line_list[i + 1]; // 下行右边界

            // -------------------- 阶梯搜左边界 --------------------
            // 规则：从「下行左边界 + 阶梯步长」位置，向左扫找「白→黑」跳变
            int16 start_left = prev_left + LADDER_STEP;
            // 限制搜索起始点不超出图像右边界
            start_left = start_left >= GRAY_IMAGE_WIDTH ? (GRAY_IMAGE_WIDTH - 1) : start_left;

            // 仅当前行核心点为白色时，才进行扫描
            if(GET_IMAGE_PIXEL(img, i, core_col) == 255)
            {
                for(int16 j = start_left; j >= 1; j--)
                {
                    if(GET_IMAGE_PIXEL(img, i, j) == 255 &&
                       GET_IMAGE_PIXEL(img, i, j-1) == 0)
                    {
                        curr_left = j-1;
                        curr_left_found = 1;
                        break;
                    }
                }
            }

            // -------------------- 阶梯搜右边界 --------------------
            // 规则：从「下行右边界 - 阶梯步长」位置，向右扫找「白→黑」跳变
            int16 start_right = prev_right - LADDER_STEP;
            // 限制搜索起始点不小于0
            start_right = start_right < 0 ? 0 : start_right;

            // 仅当前行核心点为白色时，才进行扫描
            if(GET_IMAGE_PIXEL(img, i, core_col) == 255)
            {
                for(int16 j = start_right; j < GRAY_IMAGE_WIDTH - 1; j++)
                {
                    if(GET_IMAGE_PIXEL(img, i, j) == 255 &&
                       GET_IMAGE_PIXEL(img, i, j+1) == 0)
                    {
                        curr_right = j+1;
                        curr_right_found = 1;
                        break;
                    }
                }
            }


            // 触发条件：左/右任意一个边界未找到 → 阶梯搜索失败
            if(!curr_left_found || !curr_right_found)
            {
                // ---------- 规则1：当前行 → 仅未找到的边界赋初始值，找到的保留原值 ----------
                // 左边界没找到 → 赋初始值0；找到 → 保留阶梯搜索结果
                if(!curr_left_found)
                {
                    curr_left = 0;
                    curr_left_found = 1;
                }
                // 右边界没找到 → 赋初始值159；找到 → 保留阶梯搜索结果
                if(!curr_right_found)
                {
                    curr_right = GRAY_IMAGE_WIDTH - 1;
                    curr_right_found = 1;
                }

                // ---------- 规则2：当前行 → 绝对不重新扫描最长白列 ----------
                // ---------- 规则3：上一行(i+1) → 从最长白列全范围扫描，彻底兜底不丢线 ----------
                uint8 fix_left = 0, fix_right = GRAY_IMAGE_WIDTH - 1;
                uint8 fix_l_found = 0, fix_r_found = 0;

                // 上一行全范围扫描：从最长白列向左右搜索边界
                if(GET_IMAGE_PIXEL(img, i+1, core_col) == 255)
                {
                    // 重新扫描上一行左边界
                    for(int16 j = core_col; j >= 1; j--)
                    {
                        if(GET_IMAGE_PIXEL(img, i+1, j) == 255 && GET_IMAGE_PIXEL(img, i+1, j-1) == 0)
                        {
                            fix_left = j-1;
                            fix_l_found = 1;
                            break;
                        }
                    }
                    // 重新扫描上一行右边界
                    for(int16 j = core_col; j < GRAY_IMAGE_WIDTH - 1; j++)
                    {
                        if(GET_IMAGE_PIXEL(img, i+1, j) == 255 && GET_IMAGE_PIXEL(img, i+1, j+1) == 0)
                        {
                            fix_right = j+1;
                            fix_r_found = 1;
                            break;
                        }
                    }
                }

                // 上一行边界兜底+防护
                if(!fix_l_found) fix_left = 0;
                if(!fix_r_found) fix_right = GRAY_IMAGE_WIDTH - 1;
                if(fix_left > fix_right) { fix_left = 0; fix_right = GRAY_IMAGE_WIDTH - 1; }

                // 写入修复后的上一行边界+中线
                left_line_list[i+1] = fix_left;
                right_line_list[i+1] = fix_right;
                // mid_line_list[i+1] = (fix_left + fix_right) / 2;
            }
        }

        // -------------------- 防护逻辑：左边界绝对不能大于右边界 --------------------
        if(curr_left > curr_right)
        {
            curr_left = 0;
            curr_right = GRAY_IMAGE_WIDTH - 1;
        }

        // -------------------- 保存当前行边界 --------------------
        left_line_list[i] = curr_left;
        right_line_list[i] = curr_right;
        // mid_line_list[i] = (curr_left + curr_right) / 2;

        // // ===================== 中线差值限制：防止中线突变 =====================
        // int16 curr_mid = (int16)mid_line_list[i];
        // int16 next_mid = (int16)mid_line_list[i+1];
        // int16 mid_diff = abs(curr_mid - next_mid);

        // // 相邻行中线差值超过阈值 → 强制修正
        // if(mid_diff > MID_LINE_DIFF_THRESHOLD)
        // {
        //     curr_mid = (curr_mid > next_mid) ? (next_mid + MID_LINE_DIFF_THRESHOLD)
        //                                       : (next_mid - MID_LINE_DIFF_THRESHOLD);
        //     // 边界保护：中线不超出图像范围
        //     curr_mid = (curr_mid < 0) ? 0 : (curr_mid >= GRAY_IMAGE_WIDTH ? (GRAY_IMAGE_WIDTH - 1) : curr_mid);
        //     mid_line_list[i] = (uint8)curr_mid;
        // }
    }

}


/**
 * @fn fit_midline_slope_angle
 * @brief 最小二乘法拟合底行到截止行的中线，计算斜率和角度偏差
 * @param fit_ratio 拟合行比例（0.0~1.0，1=全部有效行，0.5=一半有效行）
 * @param slope 输出：拟合中线的斜率（Δy/Δx，y=行号向下为正，x=列号向右为正）
 * @param angle_deg 输出：相对于垂直直道的角度偏差（度，范围-90°~90°，正=右转/向右偏，负=左转/向左偏）
 * @return 是否拟合成功（true=成功，false=失败/有效行不足）
 * @note 1. 有效行范围：search_cutoff_row → bottom_row；
 *       2. 斜率定义保持不变：k = Δy/Δx；
 *       3. 以垂直向下（直道方向）为0°基准，向右偏转为正，向左偏转为负，严格限制在-90°~90°区间；
 */
bool fit_midline_slope_angle(float fit_ratio, float *slope, float *angle_deg)
{
    // 1. 入参校验：空指针/无效比例直接返回失败
    if(slope == NULL || angle_deg == NULL || fit_ratio < 0.0f || fit_ratio > 1.0f)
    {
        if(slope != NULL) *slope = 0.0f;
        if(angle_deg != NULL) *angle_deg = 0.0f;
        return false;
    }

    // 2. 基础参数定义
    const uint8_t bottom_row = GRAY_IMAGE_HEIGHT - 1; // 图像底行
    float sum_x = 0.0f, sum_y = 0.0f;          // x=中线列坐标，y=行号
    float sum_xy = 0.0f, sum_x2 = 0.0f;        // 最小二乘累加项
    int valid_cnt = 0;                         // 有效中线点计数

    // 3. 截止行越界防护
    if(search_cutoff_row > bottom_row)
    {
        *slope = 0.0f;
        *angle_deg = 0.0f;
        return false;
    }

    // 4. 计算拟合行范围
    uint8_t total_valid_rows = bottom_row - search_cutoff_row + 1;
    uint8_t fit_rows = (uint8_t)((float)total_valid_rows * fit_ratio);
    if(total_valid_rows < MIN_FIT_ROWS || fit_rows < MIN_FIT_ROWS)
    {
        *slope = 0.0f;
        *angle_deg = 0.0f;
        return false;
    }
    uint8_t fit_start_row = bottom_row - fit_rows + 1;
    if(fit_start_row < search_cutoff_row) fit_start_row = search_cutoff_row;

    // 5. 遍历拟合行，累加最小二乘参数
    for(uint8_t row = fit_start_row; row <= bottom_row; row++)
    {
        float x = (float)mid_line_list[row]; // 中线列坐标（X轴）
        float y = (float)row;                // 行号（Y轴，向下为正）

        // 跳过无效中线点（超出图像范围）
        if(x < 0 || x >= GRAY_IMAGE_WIDTH) continue;

        sum_x += x;
        sum_y += y;
        sum_xy += x * y;
        sum_x2 += x * x;
        valid_cnt++;
    }

    // 6. 有效点不足，返回失败
    if(valid_cnt < MIN_FIT_ROWS)
    {
        *slope = 0.0f;
        *angle_deg = 0.0f;
        return false;
    }

    // 7. 最小二乘法计算斜率 k = Δy/Δx
    float denominator = valid_cnt * sum_x2 - sum_x * sum_x;
    float k = 0.0f;
    float raw_angle = 0.0f; // 原始0~180°绝对角度（x轴正方向为0°，向下为正）

    if(fabs(denominator) < 1e-6) // 分母为0（垂直直线，X坐标不变，直道）
    {
        k = FLT_MAX;             // 无穷大表示垂直
        raw_angle = 90.0f;       // 垂直向下为90°
    }
    else
    {
        // 核心公式：k = (nΣxy - ΣxΣy) / (nΣx² - (Σx)²)
        k = (valid_cnt * sum_xy - sum_x * sum_y) / denominator;

        // 计算原始绝对角度（0~180°坐标系）
        if(fabs(k) < 1e-6) // 斜率为0（水平直线）
        {
            raw_angle = 0.0f;
        }
        else if(k > 0) // 斜率>0（左上→右下）：0°~90°
        {
            raw_angle = atanf(k) * 180.0f / M_PI;
        }
        else // 斜率<0（左下→右上）：90°~180°
        {
            raw_angle = 180.0f - (atanf(fabs(k)) * 180.0f / M_PI);
        }
    }

    // ========== 核心修改：转换为-90°~90°角度偏差 ==========
    // 以垂直直道（90°）为0基准，右转为正，左转为负
    float angle_dev = 90.0f - raw_angle;

    // 严格限幅到 -90° ~ +90°
    if(angle_dev < -90.0f) angle_dev = -90.0f;
    if(angle_dev > 90.0f)  angle_dev = 90.0f;

    // 10. 赋值输出
    *slope = k;
    *angle_deg = angle_dev;

    return true;
}

// ===================== 双前瞻行正切平均角度计算 =====================
/**
 * @brief  基于原点(80,119)计算双前瞻行的平均夹角
 * @details 几何定义严格匹配题目公式：
 *          - 基准原点O：图像最底部中心，坐标(origin_x=80, origin_y=119)
 *          - 前瞻点P：某行的赛道中线位置，坐标(x=中线列号, y=行号)
 *          - 对边：水平偏移量 = x - 80（右偏为正，左偏为负）
 *          - 邻边：竖直距离 = 119 - y（恒≥0，点越靠上、离底部越远，数值越大）
 *          - 夹角α：连线OP与竖直向上方向的夹角，右偏为正，左偏为负
 *          - 正切公式：tanα = 对边 / 邻边 = (x-80)/(119-y)
 * @return float 平均角度（单位°），右偏为正，左偏为负
 * @note   严格执行边界约束：前瞻行号 < 搜索截止行 → 强制等于搜索截止行
 */
float calc_two_lookahead_avg_angle(void)
{
    // ========== 1. 基准原点定义（固定参考点） ==========
    // origin_x：图像水平中心列（第80列），对应小车车身中心的图像投影位置
    // origin_y：图像最底部行（第119行），离摄像头最近、最贴近小车当前实际位置
    const uint8 origin_x = 80;    
    const uint8 origin_y = 119;   

        // ========== 2. 根据赛道状态切换【双前瞻平均计算专用截止行】 ==========
    uint8 avg_cutoff_row; // 求平值时使用的前瞻行下限阈值
    // 判断条件：当前不是普通赛道 + 环岛阶段为直道进环
    if(track_state != NORMAL_TRACK && round_stage == ROUND_STAGE_DIRECT)
    {
        // 环岛直道进环规则：角度截止行 = 环岛主边界对应的上拐点行
        if(track_state == RIGHT_ROUND)
        {
            // 右环岛：主边界为右边界，取右边界上拐点行作为下限
            avg_cutoff_row = inflect_final_row[INFLECT_RIGHT_UPPER];
        }
        else // LEFT_ROUND 左环岛
        {
            // 左环岛：主边界为左边界，取左边界上拐点行作为下限
            avg_cutoff_row = inflect_final_row[INFLECT_LEFT_UPPER];
        }
        // 兜底防护：若上拐点未检测到（值为0），切回全局搜索截止行，避免下限为0
        if(avg_cutoff_row == 0)
            avg_cutoff_row = search_cutoff_row;
    }
    else
    {
        // 普通直道/弯道/环岛非直进阶段：平均截止行为全局搜索截止行
        avg_cutoff_row = search_cutoff_row;
    }

    // ========== 3. 约束最近前瞻行不能低于平均截止行 ==========
    uint8 y_near = LOOK_AHEAD_NEAR_ROW; // 原始配置：近前瞻行（贴近小车）
    // 规则：若最近前瞻行小于求角度截止行，则强制赋值为截止行
    if(y_near < avg_cutoff_row)
        y_near = avg_cutoff_row;

    // ========== 4. 约束最远前瞻行不能低于平均截止行 ==========
    uint8 y_far = LOOK_AHEAD_FAR_ROW; // 原始配置：远前瞻行（远处弯道预判）
    // 规则：若最远前瞻行小于求角度截止行，则强制赋值为截止行
    if(y_far < avg_cutoff_row)
        y_far = avg_cutoff_row;

    // ========== 3. 获取两个前瞻点的中线列坐标 ==========
    // x_near：最近前瞻行的中线列号（对应公式中的 x）
    // x_far：最远前瞻行的中线列号（对应公式中的 x）
    // 使用int16类型：后续做减法可能出现负数，uint8无符号类型会溢出
    int16 x_near = mid_line_list[y_near];
    int16 x_far  = mid_line_list[y_far];

    // ========== 4. 计算【最近前瞻点】的夹角 ==========
    float angle_near = 0.0f;  // 近点对应角度，初始值0°（直道默认基准）
    // dy_near：邻边长度 = 原点行号 - 近点行号
    // 物理意义：近点到小车底部的竖直距离，恒大于等于0
    int16 dy_near = origin_y - y_near;   

    if(dy_near > 0)   // 除零防护（嵌入式必做：防止分母为0导致程序异常崩溃）
    {
        // 正切值 = 对边 / 邻边 = (水平偏移量) / (竖直距离)
        float tan_near = (float)(x_near - origin_x) / dy_near;
        // 反正切计算角度，弧度转换为角度
        // atanf 天然输出范围为-90°~+90°，与我们的角度符号定义完全匹配
        angle_near = atanf(tan_near) * 180.0f / M_PI;
    }
    else
    {
        // 极端兜底场景：近点与原点同行（dy=0），连线为纯水平线
        // 中线在原点右侧 → +90°，左侧 → -90°
        angle_near = (x_near > origin_x) ? 90.0f : -90.0f;
    }

    // ========== 5. 计算【最远前瞻点】的夹角 ==========
    float angle_far = 0.0f;   // 远点对应角度，初始值0°
    // dy_far：邻边长度 = 原点行号 - 远点行号
    // 远点更靠上，离底部更远，因此 dy_far 通常大于 dy_near
    int16 dy_far = origin_y - y_far;

    if(dy_far > 0)    // 同样做除零防护，保证极端场景下程序稳定
    {
        float tan_far = (float)(x_far - origin_x) / dy_far;
        angle_far = atanf(tan_far) * 180.0f / M_PI;
    }
    else
    {
        angle_far = (x_far > origin_x) ? 90.0f : -90.0f;
    }

    // ========== 6. 两点角度取算术平均值，返回最终结果 ==========
    // 算术平均的意义：兼顾近处的稳定性与远处的前瞻性，平滑角度输出，避免突变
    // 乘以0.5等价于除以2，浮点运算中乘法效率略高于除法
    return (angle_near + angle_far) * 0.5f;
}

// 目标绕行距离控制
bool target_avoid_running = false;                // 是否正在执行目标绕行

int   target_avoid_class = -1;                   // 绕行目标类别

// ===================== 动态前瞻循线偏差计算（带阈值 10°） =====================
// 角度规则：0°(水平右) → 90°(垂直下) → 180°(水平左)
// 计算公式已内置：仅当偏离90°超过10°时，才开始动态向前看
float calculate_lookahead_deviation(float fit_angle)
{

    // ===================== 核心修改：有目标识别结果 → 强制使用最低行，禁用动态前瞻 =====================
    int track_point;
    int lookahead_x = 0;  // 前瞻点X坐标（列）
    int lookahead_y = 0;  // 前瞻点Y坐标（行）

    uint8 fixed_look_row = LOOK_AHEAD_NEAR_ROW;

    // ========== 近前瞻行不能低于前瞻计算专用截止行 ==========
    uint8 look_cutoff_row; // 前瞻行下限阈值，小于该行的区域无有效赛道，禁止采样
    // 规则区分：普通赛道 / 环岛直道进环
    if(track_state != NORMAL_TRACK && round_stage == ROUND_STAGE_DIRECT)
    {
        // 环岛直道进环规则：前瞻行截止行 = 环岛主边界上拐点行
        if(track_state == RIGHT_ROUND)
        {
            // 右环岛主边界为右边界，下限取右边界上拐点
            look_cutoff_row = inflect_final_row[INFLECT_RIGHT_UPPER];
        }
        else // LEFT_ROUND 左环岛
        {
            // 左环岛主边界为左边界，下限取左边界上拐点
            look_cutoff_row = inflect_final_row[INFLECT_LEFT_UPPER];
        }
        // 兜底防护：上拐点未识别(值0)时，切换为全局搜索截止行，防止下限为0
        if(look_cutoff_row == 0)
            look_cutoff_row = search_cutoff_row;
    }
    else
    {
        // 普通赛道/环岛其他阶段：前瞻行下限使用全局搜索截止行
        look_cutoff_row = search_cutoff_row;
    }
    // 固定近前瞻行低于截止行，则强制赋值截止行
    if(fixed_look_row < look_cutoff_row)
    {
        fixed_look_row = look_cutoff_row;
    }

    if(target_avoid_running)
    {
        // 使用宏定义的目标绕行参考行，并限制在有效范围 [search_cutoff_row, GRAY_IMAGE_HEIGHT-1]
        uint8 avoid_look_row = TARGET_AVOID_LOOK_ROW;
        if(avoid_look_row < search_cutoff_row) avoid_look_row = search_cutoff_row;
        if(avoid_look_row >= GRAY_IMAGE_HEIGHT) avoid_look_row = GRAY_IMAGE_HEIGHT - 1;

        // 目标分类选择参考点（固定最低行）
        switch(target_avoid_class)
        {
            case 0: // 物资：右侧绕行
                track_point = right_line_list[avoid_look_row] - AVOID_FINE_TUNE;
                break;
                
            case 1: // 载具：直行
                track_point = mid_line_list[avoid_look_row];
                break;
                
            case 2: // 武器：左侧绕行
                track_point = left_line_list[avoid_look_row] + AVOID_FINE_TUNE;
                break;
                
            default: // 异常类别：兜底直行 + 打印告警
                track_point = mid_line_list[avoid_look_row];
                printf("[警告] 绕行类别异常: target_avoid_class=%d，默认直行\n", avoid_look_row);
                break;
        }

        // 赋值前瞻点XY
        lookahead_x = track_point;
        lookahead_y = fixed_look_row;
        // 计算最终偏差
        float dev = (float)(track_point - GRAY_IMAGE_WIDTH / 2 + UVC_ERROR);

        // ===================== 绕行偏差过大限制 =====================
        if(fabs(dev) > AVOID_DEV_LIMIT)
        {
            if(dev > 0)
                dev = AVOID_DEV_LIMIT;   // 正偏差封顶
            else
                dev = -AVOID_DEV_LIMIT;  // 负偏差封顶
        }

        // 调试打印：目标绕行，固定最低行 + 偏差限幅
        // printf("[前瞻] 目标有效(class=%d) → 偏差点(X=%d, Y=%d) 原始偏差=%.2f → 限幅后=%.2f\n",
        //        target_final_class,  
        //        lookahead_x, lookahead_y,
        //        (float)(track_point - GRAY_IMAGE_WIDTH / 2 + UVC_ERROR),
        //        dev);

        return dev;

    }

    // ===================== 无目标 → 执行原动态前瞻逻辑 =====================
    // ===================== 1：计算角度偏差 =====================
    // 输入fit_angle本身就是相对于直道的偏差（-90~90°），直接取绝对值
    float angle_dev = fabs(fit_angle);

    // ========== 对角度偏差做限幅：不超过 ANGLE_MAX_VALID ==========
    if (angle_dev > ANGLE_MAX_VALID)
    {
        angle_dev = ANGLE_MAX_VALID;
    }

    // =====================  2：阈值判断 =====================
    // 偏差 ≤ 动态前瞻起始偏差阈值 → 不前瞻，直接用最近行
    uint8 use_near_row = LOOK_AHEAD_NEAR_ROW;
    // 同样约束最近行不能低于截止行
    if(use_near_row < look_cutoff_row)
    {
        use_near_row = look_cutoff_row;
    }
    if(angle_dev <= ANGLE_THRESHOLD)
    {
        uint8 mid = mid_line_list[use_near_row];

        // 赋值前瞻点XY
        lookahead_x = mid;
        lookahead_y = use_near_row;

        float dev = (float)(mid - GRAY_IMAGE_WIDTH / 2 + UVC_ERROR);

        //========== 打印：直道不前瞻 ==========

        // printf("[前瞻] 角度=%.1f° 偏差=%.1f° ≤%d° → 取底行 行号=%d 偏差点(X=%d, Y=%d) 最终偏差=%.2f\n",
        //        fit_angle, angle_dev, ANGLE_THRESHOLD,
        //        use_near_row, lookahead_x, lookahead_y, dev);

        return dev;
    }

    // =====================  3：计算有效偏差与比例 =====================
    // 有效偏差 = 角度偏差 - 动态前瞻起始偏差阈值
    float valid_dev = angle_dev - ANGLE_THRESHOLD;

    // 范围在 动态前瞻起始偏差阈值 ~ 最大有效偏差角度
    // 有效总角度 = 最大有效偏差角度 - 动态前瞻起始偏差阈值
    const float max_valid = ANGLE_MAX_VALID - ANGLE_THRESHOLD;
    
    // 比例计算
    float ratio = valid_dev / max_valid;

    // =====================  4：计算前瞻行 =====================
    // 范围在 最近前瞻行（底部）~ 最远前瞻行
    const int row_range = LOOK_AHEAD_NEAR_ROW - LOOK_AHEAD_FAR_ROW ;

    // row_look = 最近行 - round(ratio * 行区间)
    int look_row = LOOK_AHEAD_NEAR_ROW - (int)(ratio * row_range);

    // ========== 全局硬边界保护：不超出配置的最远/最近前瞻行区间 ==========
    // 不能超过最远前瞻行（不能比预设远点更靠上）
    if(look_row < LOOK_AHEAD_FAR_ROW)  look_row = LOOK_AHEAD_FAR_ROW;
    // 不能低于最近前瞻行（不能比预设近点更靠近底部）
    if(look_row > LOOK_AHEAD_NEAR_ROW) look_row = LOOK_AHEAD_NEAR_ROW;
    
    // ========== 规则强制限幅：若计算出的前瞻行小于前瞻截止行，直接赋值截止行 ==========
    if(look_row < look_cutoff_row)
    {
        look_row = look_cutoff_row;
    }

    // =====================  5：计算循线偏差 =====================
    int look_mid = mid_line_list[look_row];

    // 赋值前瞻点XY
    lookahead_x = look_mid;
    lookahead_y = look_row;

    float dev = (float)(look_mid - GRAY_IMAGE_WIDTH / 2 + UVC_ERROR);


    // 打印：弯道动态前瞻 + 前瞻点XY
    
    // printf("[前瞻] 角度=%.1f° 偏差=%.1f° >%d° → 比例=%.2f 前瞻点(X=%d, Y=%d) 最终偏差=%.2f\n",
    //        fit_angle, angle_dev, ANGLE_THRESHOLD,
    //        ratio, lookahead_x, lookahead_y, dev);
           

    return dev;
}


// ====================== 滤波阈值配置 ======================
// 8邻域总和阈值：单个像素最大 255，8个就是 255*8
// 噪点多 → 把 MORPH_MAX 改小，MORPH_MIN 改大
// 边缘太碎 → 把 MORPH_MAX 改大，MIN 往下调
// 锯齿多 = MAX 往下调，MIN 往上调
// 噪点多 = MAX 往上调，MIN 往下调
#define MORPH_MAX   (255 * 6)   // 膨胀阈值 MORPH_MAX：周围很亮 → 消除赛道内的小黑点
#define MORPH_MIN   (255 * 3)  // 腐蚀阈值 MORPH_MIN：周围很暗 → 消除背景中的小白点

#define PIXEL_BLACK     0
#define PIXEL_WHITE     255

/**
 * @brief  8邻域形态学滤波（膨胀 + 腐蚀），去噪+平滑赛道边缘
 * @param  src: 输入二值图像（一维数组）
 * @param  dst: 输出滤波后图像（一维数组）
 * @param  width: 图像宽度
 * @param  height: 图像高度
 * @return 无
 * @note   只处理内部像素，边缘1圈不处理，防止越界
 */
void image_filter(const uint8 *src, uint8 *dst, uint16 width, uint16 height)
{
    // 安全判断：图像太小直接返回
    if (src == NULL || dst == NULL || width <= 2 || height <= 2)
        return;

    uint32_t total = (uint32_t)width * height;

    // 1. 先完整拷贝原图（防止处理时覆盖数据）
    for (uint32_t i = 0; i < total; i++)
    {
        dst[i] = src[i];
    }

    // 2. 8邻域滤波（跳过最外圈1行1列，避免越界）
    for (uint16_t i = 1; i < height - 1; i++)
    {
        for (uint16_t j = 1; j < width - 1; j++)
        {
            // 8邻域坐标（上3、中2、下3）
            uint8_t p0 = src[(i-1)*width + (j-1)];
            uint8_t p1 = src[(i-1)*width + (j)  ];
            uint8_t p2 = src[(i-1)*width + (j+1)];

            uint8_t p3 = src[(i)*width + (j-1)  ];
            uint8_t p4 = src[(i)*width + (j+1)  ];

            uint8_t p5 = src[(i+1)*width + (j-1)];
            uint8_t p6 = src[(i+1)*width + (j)  ];
            uint8_t p7 = src[(i+1)*width + (j+1)];

            // 8邻域亮度总和
            uint16_t sum = p0 + p1 + p2 + p3 + p4 + p5 + p6 + p7;

            // 当前中心像素
            uint8_t center = src[i*width + j];

            // -------------------- 腐蚀 --------------------
            // 周围很暗，但中心是白点 → 变成黑点（去小白点）
            if (sum <= MORPH_MIN && center == PIXEL_WHITE)
            {
                dst[i*width + j] = PIXEL_BLACK;
            }

            // -------------------- 膨胀 --------------------
            // 周围很亮，但中心是黑点 → 补成白点（去小黑点）
            else  if (sum >= MORPH_MAX && center == PIXEL_BLACK)
            {
                dst[i*width + j] = PIXEL_WHITE;
            }


        }
    }
}

// ===================== 逐飞助手绘制 左/中/右 三线 =====================
void draw_track_lines(void)
{
    // 清空边界数组（逐飞助手要求）
    memset(x1_boundary, 0, sizeof(x1_boundary));
    memset(x2_boundary, 0, sizeof(x2_boundary));
    memset(x3_boundary, 0, sizeof(x3_boundary));

    // 核心：从底行 向上 遍历到 顶行（119 → 0）
    for (int i = GRAY_IMAGE_HEIGHT-1; i >= 0; i--)
    {
        // 1:1 赋值原始数据，不做任何修改、填充、清空
        x1_boundary[i] = left_line_list[i];    // 左边界
        x2_boundary[i] = mid_line_list[i];     // 中线
        x3_boundary[i] = right_line_list[i];   // 右边界
    }

    // 逐飞助手边界配置（X轴三条线）
    seekfree_assistant_camera_boundary_config(
        X_BOUNDARY,
        GRAY_IMAGE_HEIGHT,
        x1_boundary,
        x2_boundary,
        x3_boundary,
        NULL, NULL, NULL
    );
}


// ===================== 目标板绕行专用：中线重拟合 + 单侧边界修复 =====================
/**
 * @brief 识别到目标板后，修复被遮挡畸变的中线与边界
 * @note 严格遵循自定义全套规则：
 * 1.正常规则：相邻行中线像素差值 ≤ 1
 * 2.下拟合点规则：当前行与下行中线差≤1 ，当前行与上行中线差＞1
 * 3.上拟合点规则：当前行与上行中线差≤1 ，当前行与下行中线差＞1
 * 4.两点法拟合标准中线，填充畸变区间所有行
 * 5.边界规则：只有一侧边界受遮挡影响
 *    正常约束：左边界 < 拟合后中线 ，右边界 > 拟合后中线
 * 6.修复逻辑：
 *    左边界 > 中线 → 重新扫描修复左边界
 *    右边界 < 中线 → 重新扫描修复右边界
 *    未受影响的另一侧边界完全保留原始数据不修改
 * 7.硬性边界保护：
 *    左边界≥0、永远在中线左侧
 *    右边界≤画面最大列、永远在中线右侧
 */
void stable_midline_refit(void)
{
    // 定义图像底行索引
    const uint8_t bottom = GRAY_IMAGE_HEIGHT - 1;
    // 畸变区间上下标记行，-1代表未搜索到有效点位
    int lower_pt = -1;  // 下拟合点（靠下、正常段起点）
    int upper_pt = -1;  // 上拟合点（靠上、正常段终点）

    // ===================== 第一步：搜索【下拟合点】 =====================
    // 遍历方向：从底行向上遍历至搜索截止行
    for (int y = bottom - 1; y >= search_cutoff_row; y--)
    {
        int curr_mid = mid_line_list[y];    // 当前行中线
        int down_mid = mid_line_list[y + 1]; // 下一行（更靠近底部）中线
        int up_mid   = mid_line_list[y - 1]; // 上一行（更靠近顶部）中线

        // 规则判断：
        // down_ok：当前行与下行中线连续正常（差值≤1）
        // up_bad： 当前行与上行中线突变异常（差值＞1）
        bool down_ok = (abs(curr_mid - down_mid) <= 1);
        bool up_bad  = (abs(curr_mid - up_mid)   > 1);

        // 满足条件，记录为下拟合点并退出遍历
        if (down_ok && up_bad)
        {
            lower_pt = y;
            break;
        }
    }

    // ===================== 第二步：搜索【上拟合点】 =====================
    // 遍历方向：从搜索截止行向下遍历至底行
    for (int y = search_cutoff_row + 1; y <= bottom; y++)
    {
        int curr_mid = mid_line_list[y];    // 当前行中线
        int up_mid   = mid_line_list[y - 1]; // 上一行中线
        int down_mid = mid_line_list[y + 1]; // 下一行中线

        // 规则判断：
        // up_ok：   当前行与上行中线连续正常（差值≤1）
        // down_bad：当前行与下行中线突变异常（差值＞1）
        bool up_ok   = (abs(curr_mid - up_mid)   <= 1);
        bool down_bad= (abs(curr_mid - down_mid) > 1);

        // 满足条件，记录为上拟合点并退出遍历
        if (up_ok && down_bad)
        {
            upper_pt = y;
            break;
        }
    }

    // 防护判断：未找到上下拟合点 / 区间顺序异常，直接退出不修复
    if (lower_pt == -1 || upper_pt == -1 || lower_pt <= upper_pt)
    {
        return;
    }

    // ===================== 第三步：两点法拟合标准无畸变中线 =====================
    // 取出上下两个正常基准点的坐标
    float x0 = mid_line_list[lower_pt];
    float y0 = lower_pt;
    float x1 = mid_line_list[upper_pt];
    float y1 = upper_pt;

    // 生成拟合直线参数
    FitResult_t fit = two_point_fit(x0, y0, x1, y1);

    // ===================== 第四步：重写畸变区间全部行的标准中线 =====================
    // 遍历范围：从上拟合点 至 下拟合点，全覆盖遮挡畸变区域
    for (int y = upper_pt; y <= lower_pt; y++)
    {
        // 通过直线方程计算当前行理论标准中线
        float standard_mid = fit.k * y + fit.b;

        // 图像越界保护，防止中线跑出画面
        if (standard_mid < 0)
            standard_mid = 0;
        if (standard_mid >= GRAY_IMAGE_WIDTH)
            standard_mid = GRAY_IMAGE_WIDTH - 1;

        // 覆盖写入修复后的标准中线
        mid_line_list[y] = (uint8_t)round(standard_mid);
    }

    // ===================== 第五步：单侧边界智能修复（核心逻辑） =====================
    // 绑定全局二值图，用于边缘重新扫描
    const uint8 *img = (const uint8 *)binary_image;

    // 遍历畸变区间每一行，单独判断、单独修复单侧边界
    for (int y = upper_pt; y <= lower_pt; y++)
    {
        // 获取当前行：修复完成的标准中线、原始左右边界
        uint8 std_mid  = mid_line_list[y];
        int  old_left  = left_line_list[y];
        int  old_right = right_line_list[y];

        // 初始化新边界扫描结果，-1代表未扫描到有效边缘
        int new_left  = -1;
        int new_right = -1;

        // ========== 判定边界是否损坏 ==========
        // 左边界损坏条件：原始左边界 >= 标准中线（跑到中线右侧，逻辑异常）
        bool left_damage  = (old_left >= std_mid);
        // 右边界损坏条件：原始右边界 <= 标准中线（跑到中线左侧，逻辑异常）
        bool right_damage = (old_right <= std_mid);

        // ========== 仅损坏一侧，才重新扫描边缘（未损坏侧保留原值） ==========
        // 左边界异常：单独向左重新扫描真实赛道左边缘
        if (left_damage)
        {
            // 从中线左侧开始向左检索，寻找黑→白跳变（背景→赛道）
            for (int x = std_mid - 1; x >= 0; x--)
            {
                if (GET_IMAGE_PIXEL(img, y, x) == 0 &&
                    GET_IMAGE_PIXEL(img, y, x+1) == 255)
                {
                    new_left = x;   // 记录合法左边界
                    break;
                }
            }
        }

        // 右边界异常：单独向右重新扫描真实赛道右边缘
        if (right_damage)
        {
            // 从中线右侧开始向右检索，寻找白→黑跳变（赛道→背景）
            for (int x = std_mid + 1; x < GRAY_IMAGE_WIDTH; x++)
            {
                if (GET_IMAGE_PIXEL(img, y, x) == 0 &&
                    GET_IMAGE_PIXEL(img, y, x-1) == 255)
                {
                    new_right = x;  // 记录合法右边界
                    break;
                }
            }
        }

        // ========== 边界赋值策略：坏边换新、好边保留旧 ==========
        int final_left, final_right;

        // 场景1：仅左边界损坏，右边界正常
        if (left_damage && !right_damage)
        {
            // 扫描失败兜底：强制紧贴中线左侧
            final_left  = (new_left != -1) ? new_left : (std_mid - 1);
            final_right = old_right;
        }
        // 场景2：仅右边界损坏，左边界正常
        else if (right_damage && !left_damage)
        {
            final_left  = old_left;
            // 扫描失败兜底：强制紧贴中线右侧
            final_right = (new_right != -1) ? new_right : (std_mid + 1);
        }
        // 场景3：两边都正常 / 两边同时损坏：全部保留原始边界不改动
        else
        {
            final_left  = old_left;
            final_right = old_right;
        }

        // ========== 最终强制约束：保证赛道逻辑永远合法 ==========
        // 强制左边界严格小于中线，防止越界、逻辑错乱
        if (final_left >= std_mid)
            final_left = std_mid - 1;
        // 限制左边界不能超出图像最左侧
        if (final_left < 0)
            final_left = 0;

        // 强制右边界严格大于中线
        if (final_right <= std_mid)
            final_right = std_mid + 1;
        // 限制右边界不能超出图像最右侧
        if (final_right >= GRAY_IMAGE_WIDTH)
            final_right = GRAY_IMAGE_WIDTH - 1;

        // 写入最终修复完成的左右边界
        left_line_list[y]  = (uint8_t)final_left;
        right_line_list[y] = (uint8_t)final_right;
    }
}


// 全局变量实例化
bool is_zebra_detected = false;

// **********************************************************
// 函数名：detect_zebra_cross
// 功能：斑马线检测（横向黑白交替）
// 规则：
// 1. 扫描区域 Y:60~80  X:60~100
// 2. X搜索：连续3白=有效白块，连续3黑=有效黑块
// 3. 超过10个连续无效像素 → 切换搜索目标
// 4. 3次黑白交替 → 判定为斑马线
// 5. Y搜索：向下扫描，跳过5行
// **********************************************************
void detect_zebra_cross(const uint8 *img)
{
    // 入参防护
    if(img == NULL || max_white_col_invalid)
    {
        is_zebra_detected = false;
        return;
    }

    is_zebra_detected = false;  // 初始未检测到
    uint8 alternate_count = 0;   // 黑白交替次数计数
    uint8 state = 1;             // 初始搜索状态：1=搜白色  0=搜黑色
    uint8 continue_cnt = 0;      // 连续像素计数器

    // ===================== Y轴遍历：从起始行到终止行，跳过指定行数 =====================
    for(uint16 y = ZEBRA_Y_START; y <= ZEBRA_Y_END; y += (ZEBRA_SKIP_Y_ROW + 1))
    {
        alternate_count = 0;     // 每行重置交替计数
        state = 1;                // 每行初始搜白色
        continue_cnt = 0;         // 每行重置连续计数

        // ===================== X轴遍历：指定区域内搜索 =====================
        for(uint16 x = ZEBRA_X_START; x <= ZEBRA_X_END; x++)
        {
            uint8 pixel = GET_IMAGE_PIXEL(img, y, x);

            // printf("  X=%d, 像素值=%d | 状态=%d | 连续计数=%d | 交替次数=%d\n", 
            //        x, pixel, state, continue_cnt, alternate_count);

            // ===================== 状态1：搜索白色块 =====================
            if(state == 1)
            {
                if(pixel == 255)  // 当前是白色
                {
                    continue_cnt++;
                    // 连续3个白 → 有效白块
                    if(continue_cnt >= ZEBRA_CONTINUE_PIX)
                    {
                        //printf("  → 找到有效白块，切换搜黑\n");

                        state = 0;          // 切换搜索黑色
                        continue_cnt = 0;   // 重置计数器
                    }
                }
                else  // 当前是黑色，连续计数清零
                {
                    continue_cnt++;
                    // 超过10个无效 → 退出当前X搜索
                    if(continue_cnt > ZEBRA_MAX_INVALID)
                    {
                        //printf("  → 无效像素过多，退出该行扫描\n");

                        break;
                    }
                }
            }
            // ===================== 状态0：搜索黑色块 =====================
            else
            {
                if(pixel == 0)  // 当前是黑色
                {
                    continue_cnt++;
                    // 连续3个黑 → 有效黑块
                    if(continue_cnt >= ZEBRA_CONTINUE_PIX)
                    {
                        alternate_count++;  // 完成一次黑白交替

                        //printf("  → 找到有效黑块，完成1次交替 | 当前交替次数=%d\n", alternate_count);

                        state = 1;          // 切换搜索白色
                        continue_cnt = 0;   // 重置计数器

                        // 达到3次交替 → 判定为斑马线
                        if(alternate_count >= ZEBRA_ALTERNATE_NUM)
                        {
                            //printf("  ✅ 交替次数达标！判定为斑马线，检测结束\n");

                            is_zebra_detected = true;
                            return;  // 检测到直接退出，提升效率
                        }
                    }
                }
                else  // 当前是白色，连续计数清零
                {
                    continue_cnt++;
                    // 超过10个无效 → 退出当前X搜索
                    if(continue_cnt > ZEBRA_MAX_INVALID)
                    {
                        //printf("  → 无效像素过多，退出该行扫描\n");

                        break;
                    }
                }
            }
        }
    }
}


// ===================== 斑马线 距离检测 + 安全退出 =====================
bool zebra_exit_enable = false;        // 是否允许检测斑马线
bool zebra_detected_wait = false;      // 是否等待退出
uint32_t zebra_start_tick = 0;         // 检测到斑马线的时间点

void zebra_timer_check(void)
{
    uint32_t total_ms = g_total_elapsed_us / 1000;

    // printf("当前运行时间: %lu ms \n", total_ms);

    // 1. 获取当前小车总行驶距离（单位：米）
    float left_dist_m  = motor_LE.total_distance / 100.0f;   // 左轮米
    float right_dist_m = motor_RE.total_distance / 100.0f;  // 右轮米
    float car_dist_m   = (left_dist_m + right_dist_m) / 2.0f; // 平均米数

    // 2. 跑够  米 → 开启斑马线检测
    if (!zebra_exit_enable)
    {
        if (car_dist_m >= NO_DETECT_DISTANCE_M)
        {
            zebra_exit_enable = true;
            printf("\n✅ 已行驶 %.1f 米，开始检测斑马线！\n", car_dist_m);
        }
        return;
    }


    // 3. 检测到斑马线 → 启动 1 秒倒计时
    if (zebra_exit_enable && is_zebra_detected && !zebra_detected_wait)
    {
        zebra_detected_wait = true;
        zebra_start_tick = total_ms;

        // 蜂鸣器鸣叫
        beep_single_ring(500);

        printf("\n🚦 检测到斑马线！1秒后程序退出...\n");
    }

    // 4. 倒计时结束 → 安全退出
    if (zebra_detected_wait)
    {
        if (total_ms - zebra_start_tick >= WAIT_EXIT_TIME_S * 1000)
        {
            printf("\n🏁 程序安全退出！\n");
            Diff_Steer_Stop(); // 停车
            exit(0);
        }
    }
}


/**
 * @brief 批量计算赛道每行中线（从图像底部向上遍历）
 * @details 仅执行基础中线计算，纯数学运算：中线 = (左边界 + 右边界) / 2
 *          遍历范围：图像底行 bottom_row → 巡线有效截止行 search_cutoff_row
 */
void calc_midline(void)
{
    // 定义图像最底部行索引，宏固定为高度-1，120行图像则bottom_row=119
    const uint8 bottom_row = GRAY_IMAGE_HEIGHT - 1;

    // ========== 1. 最低行（底行）单独计算，不做任何差值限制 ==========
    // 底行是离小车最近的基准行，完全保留边界计算的原始中线值
    mid_line_list[bottom_row] = (left_line_list[bottom_row] + right_line_list[bottom_row]) / 2;

    // 循环规则：从底部行开始，逐行向上递减，直到搜索截止行停止
    // i = bottom_row：遍历起点（离小车最近的底部行）
    // i >= (int16)search_cutoff_row：遍历下限，仅处理有赛道的有效区域，上方无效行不计算
    // i--：行号自减，实现从下往上遍历
    for(int16 i = bottom_row - 1; i >= (int16)search_cutoff_row; i--)
    {
        // 中线计算公式：同一行左边界坐标 + 右边界坐标 除以2
        // left_line_list[i]：第i行赛道左边界列号
        // right_line_list[i]：第i行赛道右边界列号
        mid_line_list[i] = (left_line_list[i] + right_line_list[i]) / 2;

        // // ===================== 中线差值限制：防止中线突变 =====================
        int16 curr_mid = (int16)mid_line_list[i];
        int16 next_mid = (int16)mid_line_list[i+1];
        int16 mid_diff = abs(curr_mid - next_mid);

        // 相邻行中线差值超过阈值 → 强制修正
        if(mid_diff > MID_LINE_DIFF_THRESHOLD)
        {
            curr_mid = (curr_mid > next_mid) ? (next_mid + MID_LINE_DIFF_THRESHOLD)
                                              : (next_mid - MID_LINE_DIFF_THRESHOLD);
            // 边界保护：中线不超出图像范围
            curr_mid = (curr_mid < 0) ? 0 : (curr_mid >= GRAY_IMAGE_WIDTH ? (GRAY_IMAGE_WIDTH - 1) : curr_mid);
            mid_line_list[i] = (uint8)curr_mid;
        }
       
        // // 将图像最底部一行的中线赋值给全局mid_line，供主控制逻辑读取
        // mid_line = mid_line_list[bottom_row];
   
    }
}



// **********************************************************
// 函数名：vision_track_main
// 功能：视觉循迹主函数（对外核心接口）
// 入参：gray_image-输入原始灰度图像指针（摄像头采集数据）
// 返回值：无
// **********************************************************
void vision_track_main(const uint8_t* gray_image)
{
    // 灰度图像转二值图像
    gray_image_binaryzation(gray_image, &binary_image[0][0], GRAY_IMAGE_WIDTH, GRAY_IMAGE_HEIGHT);
    
    // 定义一个临时缓存，用于滤波输入输出
    static uint8_t morph_temp[GRAY_IMAGE_WIDTH * GRAY_IMAGE_HEIGHT];
    image_filter(&binary_image[0][0], morph_temp, GRAY_IMAGE_WIDTH, GRAY_IMAGE_HEIGHT);
    // 把滤波后的数据拷贝回 binary_image（后续流程全部使用滤波后图像）
    memcpy(&binary_image[0][0], morph_temp, GRAY_IMAGE_WIDTH * GRAY_IMAGE_HEIGHT);
    
    // 查找最长白列，计算搜索截止行
    find_longest_white_column(&binary_image[0][0]);

    // 最长白列失效标记
    if(max_white_col_invalid)
    {
        handle_invalid_track();  // 处理无效赛道
        return;                 // 终止后续循迹逻辑
    }
    else
    {
        recover_valid_track();  // 恢复有效赛道
    }
    
    // ===================== 巡线方法切换 =====================
    // 方法1：中线继承法
    // find_mid_line(&binary_image[0][0]);

    // 方法2：最长白列法
    // find_mid_line_white(&binary_image[0][0]);

    // 方法3：阶梯巡线法 
    // find_mid_line_step(&binary_image[0][0]);    

    
    // 环岛模式 → 使用【最长白列法】图片影响较大，但环岛时没有问题
    // 普通模式 → 使用【阶梯巡线法】图片影响较小，但环岛时有问题
    if (track_state == NORMAL_TRACK)
    {
        find_mid_line_step(&binary_image[0][0]);  //阶梯巡线法
    }
    else
    {
        find_mid_line_white(&binary_image[0][0]); //最长白列法
    }

    // ===================== 目标绕行 → 强制重拟合稳定中线 =====================
    // 没什么用，先注释
    // if (target_final_class != -1)  // 识别到目标
    // {
    //     stable_midline_refit();    // 重拟合中线
    // }

    // 拐点检测（注释，按需启用）
    // detect_all_inflections();
    
    // 补线（需自行实现）
    inflection_detect_main(); 

    // 找到边线最后计算中线
    calc_midline();


    // 最小二乘拟合（计算斜率/角度）
    // fit_midline_slope_angle(0.75f, &fit_slope, &fit_angle);

    // 双前瞻行正切平均角度（替代原最小二乘拟合角度计算）
    // 计算逻辑：以底部中心(80,119)为原点，计算近/远双前瞻行的夹角并取平均
     fit_angle = calc_two_lookahead_avg_angle();

    // 计算循线偏差
    // 调用封装函数计算带阈值的动态前瞻偏差
    line_deviation = calculate_lookahead_deviation(fit_angle);

    // ========== 纯跟踪算法计算转向 ==========
    // 输入：全局中线数组 mid_line_list、搜索截止行 search_cutoff_row
    // 输出：fit_angle = 双行平均前轮转角（°），line_deviation = 近点像素偏差
    //fit_angle = pure_pursuit_calc_steer(&line_deviation);

    // printf("[输出] 最终执行前轮偏转角 = %.2f °\r\n", fit_angle);
    // printf("=========================================================\r\n\r\n");

    // 绘制赛道三线 
    draw_track_lines();
    
    // ===================== 斑马线检测 =====================
    if (zebra_exit_enable)
    {
        detect_zebra_cross(&binary_image[0][0]);
    }
    else
    {
        is_zebra_detected = false;
    }

    // 打印检测结果
    // if(is_zebra_detected)
    // {
    //     printf("检测到斑马线！\r\n");
    // }

    //===================== 打印哪一行左右边界 & 中线 =====================
    
    // const uint8 row =  119; // 哪一行
    // uint8 left  = left_line_list[row];       // 左边界X
    // uint8 mid   = mid_line_list[row];        // 中线X
    // uint8 right = right_line_list[row];      // 右边界X

    // printf("行[%3d] 左:%3d | 中:%3d | 右:%3d\n",
    //     row,
    //     left,
    //     mid,
    //     right);
        

}

#ifndef _CustomFunction_hpp_
#define _CustomFunction_hpp_

#include "zf_common_headfile.hpp"

int Abs(int value); // 求绝对值
long Abs_long(long value);
extern float Abs_float(float value);

// 限幅函数
float Limit_float(float min, float val, float max); 
float Limit_int(int min, int value, int max);

#endif
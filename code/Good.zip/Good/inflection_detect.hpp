/******************************************************************************************
 * @file           inflection_detect.hpp
 * @brief          十字赛道视觉拐点检测 核心头文件
 * @author         嵌入式视觉循迹模块
 * @date           2025
 * @copyright      无
 * @version        1.0
 * @details        适用于160x120分辨率摄像头图像，原点在左上角
 *                 X轴：从左向右递增 0~159
 *                 Y轴：从上向下递增 0~119
 *                 核心功能：十字赛道4个拐点检测、丢线判断、边界稳定段检测、突变检测、
 *                 直线拟合、边界补全、中线平滑处理，严格遵循指定的嵌入式视觉算法规则
 ******************************************************************************************/
#ifndef INFLECTION_DETECT_HPP
#define INFLECTION_DETECT_HPP

// 标准固定数据类型头文件，用于uint8_t、bool等基础类型
#include <stdint.h>
#include <stdbool.h>
// 数学运算头文件，用于fabs、round等浮点运算
#include <math.h>

/******************************************************************************************
 * @brief 日志开关配置
 * @note  1=开启日志打印  0=关闭日志打印
 ******************************************************************************************/
#define INFLECT_LOG_ENABLE    0

/******************************************************************************************
 * @brief 核心配置宏定义区
 * @note  所有算法参数、阈值、分辨率、边界限制均在此修改，无业务逻辑代码
 ******************************************************************************************/
// 图像硬件分辨率固定配置：160像素宽，120像素高
#define IMAGE_WIDTH           160     // 图像X轴总宽度，坐标范围0~159
#define IMAGE_HEIGHT          120     // 图像Y轴总高度，坐标范围0~119
#define IMAGE_MID_X           80      // 图像物理中心的X轴坐标，用于基础参考

// 动态有效赛道起始行：外部C文件赋值，指定图像中有效赛道区域的起始Y坐标
extern uint8_t search_cutoff_row;

// 拐点检测的有效Y轴范围：仅在该范围内检测拐点，防止无效区域干扰
#define INFLECT_UPPER_LIMIT   search_cutoff_row  // 有效区域上边界（外部动态配置）
#define INFLECT_LOWER_LIMIT   119                // 有效区域下边界，避开最后一行防止数组越界

/************************* 丢线检测参数配置 *************************/
#define LOST_CHECK_ROWS       15      // 丢线检测时，向上/向下连续检查的行数
#define LEFT_LOST_THRESH      10      // 左边界X坐标 < 10 → 判定左边界丢失
#define RIGHT_LOST_THRESH     150     // 右边界X坐标 > 150 → 判定右边界丢失

/************************* 稳定段检测参数配置 *************************/
#define STABLE_CONTINUOUS_ROWS 3      // 判定为有效稳定段，需要连续平稳的行数
#define STABLE_DIFF_THRESH    2       // 相邻两行边界X坐标差值 < 2 → 判定为平稳无变化
// 稳定段内部的丢线判定阈值：稳定段内出现该值，直接判定稳定段无效
#define STABLE_LEFT_LOST      2       // 稳定段内左边界 < 2 → 边界丢失
#define STABLE_RIGHT_LOST     158     // 稳定段内右边界 > 158 → 边界丢失

/************************* 突变检测参数配置 *************************/
#define MUTATION_DIFF_THRESH  2       // 边界坐标突变差值阈值，大于该值才判定为有效突变

/************************* 拐点行号微调参数 *************************/
#define INFLECT_OFFSET        0       // 下拐点行号 = 检测行 + 偏移；上拐点行号 = 检测行 - 偏移

/************************* 异常拐点过滤参数配置 *************************/
// Y轴坐标合法性过滤：防止拐点出现在无效区域
#define UPPER_INFLECT_OFFSET   5      // 上拐点最小Y = search_cutoff_row + 该偏移
#define INFLECT_ROW_DIFF       10     // 上下拐点之间最小行数差，小于该值判定为无效拐点

// X轴坐标合法性过滤：防止拐点坐标超出赛道合理范围
#define LEFT_INFLECT_MIN_X    10       // 左拐点最小允许X坐标
#define LEFT_INFLECT_MAX_X    85     // 左拐点最大允许X坐标
#define RIGHT_INFLECT_MIN_X   75      // 右拐点最小允许X坐标
#define RIGHT_INFLECT_MAX_X   149     // 右拐点最大允许X坐标

/************************* 直线拟合参数配置 *************************/
#define LEAST_SQUARE_POINTS   7       // 最小二乘法拟合直线时，采集的有效坐标点数量
#define SLOPE_CHECK_THRESH    1e-6    // 斜率有效性判断精度，避免除以0导致程序崩溃

/************************* 边界补线与中线平滑参数 *************************/
#define FILL_BOTTOM_ROW       119     // 边界补线允许的最底端行号
#define MID_LINE_SMOOTH_THRESH 3      // 中线相邻两行最大允许差值，超过则强制平滑
#define LEFT_BOUND_MAX        120     // 左边界坐标最大值保护，防止越界
#define RIGHT_BOUND_MIN       40      // 右边界坐标最小值保护，防止越界
/************************* 边界补线与中线平滑参数 *************************/
#define FILL_BOTTOM_ROW       119     // 边界补线允许的最底端行号
#define MID_LINE_SMOOTH_THRESH 3      // 中线相邻两行最大允许差值，超过则强制平滑
#define LEFT_BOUND_MAX        120     // 左边界坐标最大值保护，防止越界
#define RIGHT_BOUND_MIN       40      // 右边界坐标最小值保护，防止越界
#define SINGLE_UPPER_FILL_MIN_Y 55    // 单上拐点补线最小Y阈值，小于等于该值不补线


/******************************************************************************************
 * @brief 枚举类型定义区：定义算法中所有状态、类型、方向
 ******************************************************************************************/
/**
 * @brief 十字赛道4个拐点类型枚举
 * @note  十字赛道固定存在4个拐点，用于区分检测/补线的目标拐点
 */
typedef enum {
    INFLECT_LEFT_LOWER   = 0,    // 左下拐点：左边界的下拐点
    INFLECT_RIGHT_LOWER  = 1,    // 右下拐点：右边界的下拐点
    INFLECT_LEFT_UPPER   = 2,    // 左上拐点：左边界的上拐点
    INFLECT_RIGHT_UPPER  = 3,    // 右上拐点：右边界的上拐点
    INFLECT_TOTAL        = 4     // 拐点总数量，用于定义数组长度
} InflectType_E;

/**
 * @brief 边界类型枚举
 * @note  区分算法处理的是左边界数据还是右边界数据
 */
typedef enum {
    LINE_LEFT  = 0,             // 左边界
    LINE_RIGHT = 1              // 右边界
} LineType_E;

/**
 * @brief Y轴遍历方向枚举
 * @note  图像Y轴从上向下增大，向上=Y减小，向下=Y增大
 */
typedef enum {
    TRAVEL_UP   = 0,            // 向上遍历：Y坐标数值减小
    TRAVEL_DOWN = 1             // 向下遍历：Y坐标数值增大
} TraverseDir_E;

/******************************************************************************************
 * @brief 结构体定义区：封装拟合结果、补线范围、状态机
 ******************************************************************************************/
/**
 * @brief 直线拟合结果结构体
 * @note  赛道边界拟合公式：x = k * y + b（Y为行号，X为边界坐标）
 */
typedef struct {
    float k;              // 拟合直线的斜率
    float b;              // 拟合直线的截距
    bool valid;           // 拟合结果有效标志：true=有效可用，false=无效
    uint8_t start_row;    // 拟合计算的起始Y行号
} FitResult_t;

/**
 * @brief 边界补线范围结构体
 */
typedef struct {
    uint8_t start;    // 补线操作的起始行号
    uint8_t end;      // 补线操作的结束行号
    bool is_fill;     // 补线完成标志：true=已完成补线，false=未补线
} FillRange_t;

/******************************************************************************************
 * @brief 外部全局变量声明
 * @note  这些变量在外部C文件中定义，本文件仅声明调用
 ******************************************************************************************/
// 图像每行边界/中线数组：索引=Y行号，值=X坐标
extern uint8_t left_line_list[IMAGE_HEIGHT];   // 左边界X坐标数组
extern uint8_t right_line_list[IMAGE_HEIGHT];  // 右边界X坐标数组
extern uint8_t mid_line_list[IMAGE_HEIGHT];    // 赛道中线X坐标数组

// 拐点检测结果数组：存储4个拐点的Y坐标，0=未检测到该拐点
extern uint8_t inflect_final_row[INFLECT_TOTAL];

// 声明两点拟合函数
FitResult_t two_point_fit(float x1, uint8_t y1, float x2, uint8_t y2);
// 声明最小二乘法拟合函数
FitResult_t least_square_fit(uint8_t start_row, LineType_E line_type, TraverseDir_E dir);

// 外部接口函数声明
void inflection_detect_main(void);
void inflection_detect_process(void);
void inflection_fill_boundary(void);
void print_inflection_points(void);

void recalculate_mid_line(void);

#endif // INFLECTION_DETECT_HPP
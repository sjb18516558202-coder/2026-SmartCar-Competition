#include "DiffSteering.hpp"
#include "beep_demo.hpp"  // 蜂鸣器提示
#include "ESC.hpp"        // 电调控制接口

// 全局实例化差速转向控制结构体
Diff_Steer_Handle diff_steer;

/**
 * @brief  根据赛道拟合角度，动态计算基础直行PWM
 * @param  angle_deg 赛道中线拟合角度
 * @return 插值后的基础速度PWM
 * @logic
 * 1. 角度偏差 0~5°：直道区间，固定最大PWM全速直行
 * 2. 角度偏差 5~35°：弯道区间，从MAX_PWM线性降到MIN_PWM
 * 3. 角度偏差 >35°：大弯道，固定最小PWM减速过弯
 */
static int16 calc_dynamic_base_pwm(float angle_deg)
{
    // 1. 输入angle_deg本身就是相对于直道的角度偏差，直接取绝对值
    float angle_err = fabsf(angle_deg);

    // 2. 先对角度偏差做限幅，最大不超过速度控制总角度35°
    if(angle_err > ANGLE_LIMIT_FOR_SPEED)
        angle_err = ANGLE_LIMIT_FOR_SPEED;

   
    // ========== 直道加速 ==========
    //  同时满足角度小 + 长线 + 不是环岛
    if(angle_err < STRAIGHT_BOOST_ANGLE && search_cutoff_row < LONG_LINE_CUTOFF_THRESHOLD && track_state == NORMAL_TRACK)
    {
        //printf("长直道加速开启 row:%d angle_err:%.2f\r\n", search_cutoff_row, angle_err);
        int16 pwm = STRAIGHT_BOOST_PWM ;
        // 限幅
        pwm = Limit_int(diff_steer.base_pwm_min, pwm, BOOST_PWM_MAX);
        return pwm;
    }
    
    // if(angle_err < 5)
    // {
    //     return 3000;
    // }    

    // 3. 角度偏差小于5°，判定为直道，直接使用最大基础速度，不减速
    if(angle_err < SPEED_CALC_START_ANGLE)
    {
        return diff_steer.base_pwm_max;
    }    

    // 4. 扣除死区，得到真正用于线性插值的有效角度偏差
    angle_err = angle_err - SPEED_CALC_START_ANGLE;
    
    // 5. 计算有效插值区间总角度：35° - 5° = 30°
    float valid_range = ANGLE_LIMIT_FOR_SPEED - SPEED_CALC_START_ANGLE;

    // 6. 计算归一化比例 0~1，偏差越大比例越大
    float ratio = angle_err / valid_range;

    // 7. 线性插值：偏差越大，基础PWM越小，实现弯道自动减速
    int16 pwm = diff_steer.base_pwm_min +
                (diff_steer.base_pwm_max - diff_steer.base_pwm_min) * (1.0f - ratio);

    // 最终安全限幅，防止插值溢出超出设定最大最小值
    pwm = Limit_int(diff_steer.base_pwm_min, pwm, diff_steer.base_pwm_max);

    return pwm;
}

/**
 * @brief  动态计算像素环比例增益
 * @param  angle_deg 赛道中线拟合角度
 * @return 动态变化的像素修正增益
 * @logic
 * 1. 角度偏差 0~5°：直道死区，固定小增益，防止直道轻微抖动乱修正
 * 2. 角度偏差 5~35°：弯道区间，增益从6.0线性升到14.0
 * 3. 角度偏差 >35°：大弯道，固定最大增益，强化居中修正
 */
static float calc_dynamic_pixel_gain(float angle_deg)
{
    // ========== 红色检测/绕行模式，强制固定像素增益 ==========
     if (target_avoid_running)
    {
        //printf("正在绕行 → 使用固定像素增益:%.2f\n", RED_AVOID_PIXEL_GAIN);
        return RED_AVOID_PIXEL_GAIN;
    }
    else if(red_detected_flag)
    {
        //printf("检测到红色 → 使用固定像素增益:%.2f\n", RED_DETECT_PIXEL_GAIN);
        return RED_DETECT_PIXEL_GAIN;
    }

    // 1. 输入angle_deg本身就是相对于直道的角度偏差，直接取绝对值
    float angle_err = fabsf(angle_deg);

    // 2. 先限幅，最大不超过像素增益控制角度
    if(angle_err > ANGLE_LIMIT_FOR_PIXEL_GAIN)
        angle_err = ANGLE_LIMIT_FOR_PIXEL_GAIN;

    // 3. 小于死区，直道固定最小增益
    if(angle_err < PIXEL_GAIN_START_ANGLE)
    {
        return PIXEL_GAIN_MIN;
    }

    // 4. 扣除死区，得到有效插值角度
    angle_err = angle_err - PIXEL_GAIN_START_ANGLE;

    // 5. 有效插值总角度范围
    float valid_range = ANGLE_LIMIT_FOR_PIXEL_GAIN - PIXEL_GAIN_START_ANGLE;

    // 6. 归一化比例 0~1
    float ratio = angle_err / valid_range;

    // 7. 线性插值：弯道越大，像素修正增益越大，居中能力越强
    float gain = PIXEL_GAIN_MIN + (PIXEL_GAIN_MAX - PIXEL_GAIN_MIN) * ratio;

    return gain;
}

/**
 * @brief  转向差速核心计算函数（仅像素闭环）
 * @param  angle_deg     赛道拟合角度
 * @param  pixel_err     中线像素偏移量
 * @param  angle_err_out 带出带符号角度偏差
 * @param  angle_out_out 预留角度环输出（当前屏蔽）
 * @param  pixel_out_out 带出像素环计算输出
 * @return delta_v       左右轮速度差
 * @rule
 * delta_v = 左轮速度 - 右轮速度
 * delta_v > 0 → 左轮更快 → 车身右转
 * delta_v < 0 → 右轮更快 → 车身左转
 */
static float calc_steer_delta_v(float angle_deg, float pixel_err,
                                float *angle_err_out, float *angle_out_out, float *pixel_out_out)
{
    // 1. 输入angle_deg本身就是带符号的角度偏差（正=右转，负=左转）
    float angle_err = angle_deg;

    // 2. 像素偏移限幅，过滤图像异常大偏差
    pixel_err = Limit_float(-MAX_PIXEL_ERR, pixel_err, MAX_PIXEL_ERR);

    // 3. 获取随弯道变化的动态像素增益
    float pixel_gain = calc_dynamic_pixel_gain(angle_deg);

    // 4. 像素闭环输出：偏移量 × 动态增益 
    float pixel_output = pixel_err * pixel_gain ;

    // 5. 像素环做转向差速
    float delta_v = pixel_output ;

    // 6. 将中间计算值通过指针带出，用于调试打印
    *angle_err_out = angle_err;
    *pixel_out_out = pixel_output;

    return delta_v;
}

/**
 * @brief  差速转向初始化
 * @param  base_pwm_max 直行最大基础PWM
 * @param  base_pwm_min 弯道最小基础PWM
 * @note 上电清空所有状态，绑定速度PID，防止启动抖动
 */
void Diff_Steer_Init(int16 base_pwm_max, int16 base_pwm_min)
{
    // 强制清空整个结构体，初始值全部置0
    memset(&diff_steer, 0, sizeof(Diff_Steer_Handle));

    // 记录初始化时的系统滴答，作为上电就绪延时起点
    diff_steer.start_tick = get_system_time_ms();
    diff_steer.ready_run = false;

    // ========== 发车倒计时状态初始化 ==========
    diff_steer.countdown_start_tick = 0;
    diff_steer.countdown_finished = false;

    // 配置基础速度上下限
    diff_steer.base_pwm_max = base_pwm_max;
    diff_steer.base_pwm_min = base_pwm_min;

    // 初始默认直道全速
    diff_steer.base_pwm = base_pwm_max;

    // 绑定左右轮速度环PID控制器实体
    diff_steer.left_speed_pid = &motor_L_pid;
    diff_steer.right_speed_pid = &motor_R_pid;

    // 电机PWM输出清零
    diff_steer.left_pwm = 0;
    diff_steer.right_pwm = 0;

    // 历史PWM、变化量统计清零
    diff_steer.last_left_pwm = 0;
    diff_steer.last_right_pwm = 0;
    diff_steer.max_left_change = 0;
    diff_steer.max_right_change = 0;

    // 增量式PID累加输出清零
    diff_steer.left_pid_output_cm_s = 0.0f;
    diff_steer.right_pid_output_cm_s = 0.0f;

    // ==================== 初始化无效赛道变量 ====================
    diff_steer.last_valid_left_pwm = 0;
    diff_steer.last_valid_right_pwm = 0;
    diff_steer.invalid_track_mode = false;
    diff_steer.invalid_track_start_dist = 0.0f;
    // 确保上电时不在过渡状态
    diff_steer.recover_transition_frames = 0;

    // 初始化无效赛道渐进差速相关变量
    diff_steer.invalid_base_pwm = 0;      // 基础 PWM 置零
    diff_steer.invalid_step_count = 0;    // 步数清零
    diff_steer.invalid_turn_dir = 0;      // 方向清零

}

/**
 * @brief  差速转向主控函数，每帧图像调用一次
 * @param  line_deviation  赛道中线像素偏移
 * @param  steer_angle_deg 赛道中线拟合角度
 * @时序
 * 1. 上电1秒系统就绪延时（必走，和按键无关）
 * 2. 就绪后等待按键：未开启小车则停机待命
 * 3. 按键开启小车：启动2秒发车倒计时
 * 4. 倒计时结束：正式进入循迹控制
 */
void Diff_Steer_Control(float line_deviation, float steer_angle_deg)
{
    // ========== 第一层：上电1秒就绪延时（原有逻辑完全保留，上电必执行） ==========
    if (!diff_steer.ready_run)
    {
        uint32_t now = get_system_time_ms();
        // 未等待满1000ms，电机保持静止
        if ((now - diff_steer.start_tick) < 1000)
        {
            Motor_L_SetSpeed(0);
            Motor_R_SetSpeed(0);
            return;
        }
        // 计时达到1秒，标记系统就绪
        diff_steer.ready_run = true;
        beep_single_ring(500);
        printf("系统就绪，等待发车指令...\n");
    }

    // ========== 第二层：系统就绪后，判断小车功能是否开启 ==========
    if (!IS_CAR_RUNNING())
    {
        // 未开启小车：停机清空状态，重置倒计时，等待按键
        diff_steer.countdown_finished = false;
        diff_steer.countdown_start_tick = 0;

        Motor_L_SetSpeed(0);
        Motor_R_SetSpeed(0);

        return;
    }

    // ========== 等待电调就绪 ==========
    if (car_wait_esc)   // 需要等待电调
    {
        ESC_StateTypeDef esc_state = ESC_GetState();
        if (esc_state != ESC_RUNNING)
        {
            // 电调未就绪，保持停机，不进入倒计时
            Motor_L_SetSpeed(0);
            Motor_R_SetSpeed(0);
            // 可选：打印提示或蜂鸣提示
            return;   // 等待下一帧继续检测
        }
        else
        {
            // 电调已就绪，清除等待标志，允许进入倒计时
            car_wait_esc = false;
            printf("电调已就绪，准备发车倒计时...\r\n");
        }
    }

    // ========== 第三层：小车已开启，执行2秒发车倒计时 ==========
    if (!diff_steer.countdown_finished)
    {
        // 第一次进入倒计时：记录起始时间并提示
        if (diff_steer.countdown_start_tick == 0)
        {
            diff_steer.countdown_start_tick = get_system_time_ms();
            printf("收到发车指令，倒计时开始...\r\n");
            
            //beep_single_ring(200); // 短蜂鸣提示倒计时启动
        }

        uint32_t now = get_system_time_ms();
        // 未到2秒，电机保持静止
        if ((now - diff_steer.countdown_start_tick) < 2000)
        {
            Motor_L_SetSpeed(0);
            Motor_R_SetSpeed(0);
            return;
        }

        // 倒计时结束，正式发车
        diff_steer.countdown_finished = true;
        beep_single_ring(1000); // 长蜂鸣提示发车
        printf("倒计时结束，小车正式发车！\r\n");
    }



    // ========== 红色检测/绕行时，强制固定基础PWM，不再角度动态调速==========
    if(target_avoid_running)
    {
        // printf("\r\n正在绕行 → 强制固定基础PWM = %d\r\n", RED_AVOID_BASE_PWM);
        diff_steer.base_pwm = RED_AVOID_BASE_PWM;
    }
    else if(red_detected_flag)
    {
        // printf("\r\n检测到红色 → 强制固定基础PWM = %d\r\n", RED_DETECT_BASE_PWM);
        diff_steer.base_pwm = RED_DETECT_BASE_PWM;
    }
    else 
    {
        // 正常赛道：根据当前赛道角度，计算直道/弯道动态基础PWM
        diff_steer.base_pwm = calc_dynamic_base_pwm(steer_angle_deg);
    }

    // 定义中间调试变量
    float angle_err, angle_output, pixel_output;

    // 计算转向差速，并带回中间变量
    float delta_v = calc_steer_delta_v(steer_angle_deg, line_deviation,
                                       &angle_err, &angle_output, &pixel_output);


    // ==================== 柔性过渡：从无效赛道恢复后逐渐增强转向 ====================
    if (diff_steer.recover_transition_frames > 0)
    {
        // 计算当前帧的缩放比例
        // 第1帧 scale = 0.2，第2帧 = 0.4，... 第5帧 = 1.0
        // 公式：(已过去帧数) / 总帧数，其中已过去帧数 = 总帧数 - 剩余帧数
        float scale = (float)(TRANSITION_TOTAL_FRAMES - diff_steer.recover_transition_frames + 1)
                    / TRANSITION_TOTAL_FRAMES;

        // 应用缩放，削弱转向差速
        delta_v *= scale;

        // 帧数递减
        diff_steer.recover_transition_frames--;

        // 调试打印（可注释掉）
        // printf("[过渡] 剩余帧:%d, 缩放比例:%.2f, 衰减后差速:%.2f\r\n",
        //        diff_steer.recover_transition_frames, scale, delta_v);
    }


    // 基础PWM转为线速度 cm/s
    float base_speed = PWM_TO_CM_S(diff_steer.base_pwm);

    // 差速分配：左右轮对称加减差速，保证中心行进速度不变
    float left_target  = base_speed + (delta_v / 2.0f);   // 左轮目标速度
    float right_target = base_speed - (delta_v / 2.0f);   // 右轮目标速度

    // 增量式PID计算单帧速度增量
    float left_delta = PID_Increase(diff_steer.left_speed_pid,
                                    motor_LE.current_speed, left_target);
    float right_delta = PID_Increase(diff_steer.right_speed_pid,
                                     motor_RE.current_speed, right_target);

    
    // 增量累加，保存PID输出稳态值（增量式PID必须保留历史累加）
    diff_steer.left_pid_output_cm_s  += left_delta;
    diff_steer.right_pid_output_cm_s += right_delta;
    

    // 将PID输出线速度转为电机PWM
    diff_steer.left_pwm  = (int16_t)CM_S_TO_PWM(diff_steer.left_pid_output_cm_s);
    diff_steer.right_pwm = (int16_t)CM_S_TO_PWM(diff_steer.right_pid_output_cm_s);

    // 硬件PWM最大限幅 ±6000
    int16 max_pwm = 6000;
    diff_steer.left_pwm  = Limit_int(-max_pwm, diff_steer.left_pwm, max_pwm);
    diff_steer.right_pwm = Limit_int(-max_pwm, diff_steer.right_pwm, max_pwm);

    // 计算当前帧相对上一帧的PWM变化量
    int16_t left_change  = diff_steer.left_pwm  - diff_steer.last_left_pwm;
    int16_t right_change = diff_steer.right_pwm - diff_steer.last_right_pwm;

    // 上电第一次不统计变化量，避免初始突变干扰
    if(diff_steer.last_left_pwm != 0 && diff_steer.last_right_pwm != 0)
    {
        // 记录运行过程中最大PWM变化量，用于调试观察平顺性
        uint16_t abs_l = (uint16_t)abs(left_change);
        uint16_t abs_r = (uint16_t)abs(right_change);

        if(abs_l > diff_steer.max_left_change) diff_steer.max_left_change = abs_l;
        if(abs_r > diff_steer.max_right_change) diff_steer.max_right_change = abs_r;
    }

    // 单帧PWM变化量限幅，软件平滑，防止急加减速顿挫
    left_change  = Limit_int(-PWM_CHANGE_LIMIT, left_change,  PWM_CHANGE_LIMIT);
    right_change = Limit_int(-PWM_CHANGE_LIMIT, right_change, PWM_CHANGE_LIMIT);

    // 叠加平滑后的变化量，得到最终输出PWM
    diff_steer.left_pwm  = diff_steer.last_left_pwm  + left_change ;
                           // + MOTOR_L_BIAS_PWM - MOTOR_R_BIAS_PWM;
    diff_steer.right_pwm = diff_steer.last_right_pwm + right_change;

    // 更新历史PWM，作为下一帧基准
    diff_steer.last_left_pwm  = diff_steer.left_pwm;
    diff_steer.last_right_pwm = diff_steer.right_pwm;



    //========================== 【全变量调试打印】 ==========================
    // printf("=========================================================\r\n");

    // printf("【图像输入】\r\n");
    // printf("  赛道角度: %.2f°   像素偏移: %.2f\r\n", steer_angle_deg, line_deviation);

    // printf("\r\n【动态速度】\r\n");
    // printf("  基础PWM: %d   基准速度: %.2f cm/s\r\n", diff_steer.base_pwm, base_speed);
    
    // printf("\r\n【转向差速】\r\n");
    // printf("  像素增益: %.2f   像素输出: %.2f   总差速: %.2f\r\n",
    //        calc_dynamic_pixel_gain(steer_angle_deg), pixel_output, delta_v);
    
    // printf("\r\n【目标速度】\r\n");
    // printf("  左轮目标: %.2f   右轮目标: %.2f cm/s\r\n", left_target, right_target);
    
    // printf("\r\n【实际速度】\r\n");
    // printf("  左轮实际: %.2f   右轮实际: %.2f cm/s\r\n",
    //        motor_LE.current_speed, motor_RE.current_speed);
    
    // printf("\r\n【PID输出】\r\n");
    // printf("  左轮PID: %.2f   右轮PID: %.2f cm/s\r\n",
    //        diff_steer.left_pid_output_cm_s, diff_steer.right_pid_output_cm_s);
    
    // printf("\r\n【电机PWM】\r\n");
    // printf("  左轮PWM: %d   右轮PWM: %d\r\n", diff_steer.left_pwm, diff_steer.right_pwm);
    
    // printf("  PWM变化: 左%d  右%d\r\n", left_change, right_change);
    // printf("  最大变化: 左%d  右%d\r\n", diff_steer.max_left_change, diff_steer.max_right_change);
    
    // printf("\r\n【状态标志】\r\n");
    // printf("  红色检测: %s\r\n", red_detected_flag ? "已检测" : "未检测");
    
    // printf("=========================================================\r\n\r\n");
    
    // ================== 14. 检测到红色 或 正在绕行 → 整体比例减速 ==================
    // if(red_detected_flag || target_avoid_running)
    // {
    //     printf("\r\n检测到红色 或 正在绕行 → 减速\r\n");
    // }



    // // ==================== 无效赛道模式 → 自救 ====================
    // if(diff_steer.invalid_track_mode)
    // {
    //     // 获取最后一次有效的左右轮 PWM
    //     int16_t left_pwm_saved  = diff_steer.last_valid_left_pwm;
    //     int16_t right_pwm_saved = diff_steer.last_valid_right_pwm;

    //     // 分出大 PWM 和小 PWM
    //     int16_t pwm_big   = (left_pwm_saved > right_pwm_saved) ? left_pwm_saved : right_pwm_saved;
    //     int16_t pwm_small = (left_pwm_saved > right_pwm_saved) ? right_pwm_saved : left_pwm_saved;

    //     // 根据丢线前最长白列位置决定回转方向
    //     if (max_white_col_pos < 80)   // 右侧出界，向左回转
    //     {
    //         Motor_L_SetSpeed(pwm_small);
    //         Motor_R_SetSpeed(pwm_big);
    //     }
    //     else                         // 左侧出界，向右回转
    //     {
    //         Motor_L_SetSpeed(pwm_big);
    //         Motor_R_SetSpeed(pwm_small);
    //     }
    //     return; // 跳过正常电机输出
    // }
    
    // ==================== 有效赛道：保存最后一次有效PWM ====================
    diff_steer.last_valid_left_pwm = diff_steer.left_pwm;
    diff_steer.last_valid_right_pwm = diff_steer.right_pwm;




    // 最终输出PWM控制左右电机
    Motor_L_SetSpeed(diff_steer.left_pwm);
    Motor_R_SetSpeed(diff_steer.right_pwm);
}


/**
 * @brief 无效赛道渐进差速出界返回函数
 * @note
 *  当图像处理丢失赛道中线时，系统调用此函数实施自救：
 *  1. 根据最后一次有效左右轮 PWM 计算降速后的基础速度。
 *  2. 根据丢线前最长白列的 X 坐标判断出界方向，决定哪一侧加速、哪一侧减速。
 *  3. 每帧逐步增加差速，让小车平稳回转，直至找回赛道或超过最大允许距离后停车。
 */
void handle_invalid_track(void)
{

    // ========== 按键使能保护 ==========
    if (!IS_CAR_RUNNING())
    {
        // 小车未启动，立即停车并清除无效模式状态
        Motor_L_SetSpeed(0);
        Motor_R_SetSpeed(0);
        // 关闭无效赛道标志，避免下次启动时残留状态导致异常
        diff_steer.invalid_track_mode = false;

        // 清空渐进差速步数和基础速度，确保下次进入时重新初始化
        diff_steer.invalid_step_count = 0;
        diff_steer.invalid_base_pwm = 0;

        // 直接返回，不进行任何电机控制
        return;
    }

    static bool invalid_printed = false;  // 防止重复打印同一提示

    // 计算整车当前行驶距离（左右轮里程均值，单位 cm）
    float current_car_dist = (motor_LE.total_distance + motor_RE.total_distance) / 2.0f;

    // --- 首次进入无效赛道：初始化所有控制参数 ---
    if(!diff_steer.invalid_track_mode)
    {
        diff_steer.invalid_track_mode = true;                      // 设置无效赛道标志
        diff_steer.invalid_track_start_dist = current_car_dist;    // 记录起始行驶距离
        invalid_printed = false;                                   // 重置打印标志

        // 1. 获取最后一次有效左右轮 PWM，取平均值后乘以减速系数
        int16_t avg = ((int32_t)diff_steer.last_valid_left_pwm +
                       diff_steer.last_valid_right_pwm) / 2;
        printf("最后 PWM: L=%d R=%d\r\n", diff_steer.left_pwm, diff_steer.right_pwm); 
        printf("平均最后 PWM:%d R=%d\r\n", avg); 

        int16_t base = (int16_t)(avg * INVALID_RETURN_DECEL_RATIO);

        // 2. 将基础速度限制在安全范围内
        if(base < INVALID_PWM_MIN) base = INVALID_PWM_MIN;
        if(base > INVALID_PWM_MAX) base = INVALID_PWM_MAX;
        diff_steer.invalid_base_pwm = base;  // 保存作为后续差速的基准

        // 3. 根据丢线前最长白列的 X 坐标（0~160）判断出界方向
        //    图像坐标系 X：左侧小（0），右侧大（160）
        //    X < 80 → 右侧出界（中线偏左），小车需要向左回转，即右轮加速、左轮减速
        //    X > 80 → 左侧出界（中线偏右），小车需要向右回转，即左轮加速、右轮减速
        if(max_white_col_pos < 80)
        {
            diff_steer.invalid_turn_dir = 0;   // 左转：右轮加，左轮减
        }
        else
        {
            diff_steer.invalid_turn_dir = 1;   // 右转：左轮加，右轮减
        }

        // 4. 差速步数清零，从第1步开始渐进
        diff_steer.invalid_step_count = 0;

        // 输出启动信息，方便调试
        printf("无效赛道启动，基础PWM:%d, 方向:%s\n",
               base, diff_steer.invalid_turn_dir == 0 ? "左转" : "右转");
    }

    // --- 距离保护：如果无效赛道行驶距离超过阈值，强制停车 ---
    float invalid_run_dist = fabs(current_car_dist - diff_steer.invalid_track_start_dist);
    if(invalid_run_dist >= INVALID_TRACK_MAX_DIST)
    {
        if(!invalid_printed)
        {
            printf("🚨 无效赛道持续行驶%.2f米，强制停车！\n", invalid_run_dist/100.0f);
            invalid_printed = true;
        }
        Diff_Steer_Stop();
        diff_steer.invalid_track_mode = false;
        exit(0);                               // 直接返回
    }

    // --- 渐进差速控制：每帧累加差速步数，逐步增大车轮速度差 ---
    int16_t base = diff_steer.invalid_base_pwm;   // 基础速度
    int16_t step = diff_steer.invalid_step_count; // 已执行的步数

    // 最大允许步数 = 总差速上限 / 每步步长，例如 1000 / 200 = 5 步
    if(step < (INVALID_MAX_DIFF / INVALID_PWM_STEP))
    {
        diff_steer.invalid_step_count = step + 1; // 步数 +1
        step = diff_steer.invalid_step_count;     // 使用新步数
    }
    // 超过最大步数后不再增加，保持最终差速

    // 根据当前步数计算本轮差速偏移量
    int16_t offset = step * INVALID_PWM_STEP;  // 200, 400, 600, 800, 1000

    int16_t left_target, right_target;

    // 根据方向分配加减速
    if(diff_steer.invalid_turn_dir == 0)   // 左转：右轮加速，左轮减速
    {
        right_target = base + offset;
        left_target  = base - offset;
    }
    else   // 右转：左轮加速，右轮减速
    {
        left_target  = base + offset;
        right_target = base - offset;
    }

    // 最终安全限幅
    left_target  = Limit_int(INVALID_PWM_MIN, left_target,  INVALID_PWM_MAX);
    right_target = Limit_int(INVALID_PWM_MIN, right_target, INVALID_PWM_MAX);

    // 直接输出 PWM（无效模式不走速度 PID）
    Motor_L_SetSpeed(left_target);
    Motor_R_SetSpeed(right_target);
}


/**
 * @brief 从无效赛道模式恢复正常巡线
 * @note 当图像处理重新获得赛道中线时调用，清空无效模式状态
 */
void recover_valid_track(void)
{
    if(diff_steer.invalid_track_mode)
    {
        // 关闭无效模式标志
        diff_steer.invalid_track_mode = false;

        // 清空差速累计步数和基础 PWM，避免影响正常控制
        diff_steer.invalid_step_count = 0;
        diff_steer.invalid_base_pwm = 0;

        // ==================== 启动柔性过渡 ====================
        // 设定接下来 5 帧为过渡期，让转向动作由弱到强逐渐恢复
        // 数值 5 可根据实际测试调整，一般 3~8 帧效果较好
        diff_steer.recover_transition_frames = TRANSITION_TOTAL_FRAMES  ;

        printf("✅ 恢复有效赛道，启动柔性过渡\n");
    }
}


/**
 * @brief  差速停车函数
 * @note 电机立即停转，清空所有历史状态、PID累加值，避免下次启动窜动
 */
void Diff_Steer_Stop(void)
{
    // 电机PWM置0刹车
    Motor_L_SetSpeed(0);
    Motor_R_SetSpeed(0);

    // 清空PWM及历史缓存
    diff_steer.left_pwm = 0;
    diff_steer.right_pwm = 0;
    diff_steer.last_left_pwm = 0;
    diff_steer.last_right_pwm = 0;

    // 清空增量式PID累加输出，防止残留值导致启动抖动
    diff_steer.left_pid_output_cm_s = 0.0f;
    diff_steer.right_pid_output_cm_s = 0.0f;

    // 停电机同时停电调
    ESC_Stop();
}


/**
 * @brief 直接输入左右目标PWM，经速度PID闭环后输出电机
 * @param target_left_pwm 外部给定左轮目标PWM
 * @param target_right_pwm 外部给定右轮目标PWM
 */
void Diff_Steer_Control_DirectPWM(int16_t target_left_pwm, int16_t target_right_pwm)
{
    // ========== 小车运行使能总开关 ==========
    if (!IS_CAR_RUNNING())
    {
        Diff_Steer_Stop();
        diff_steer.countdown_finished = false;
        diff_steer.countdown_start_tick = 0;
        return;
    }

    // 1. 目标PWM转换为目标线速度 cm/s
    float left_target_speed  = PWM_TO_CM_S(target_left_pwm);
    float right_target_speed = PWM_TO_CM_S(target_right_pwm);

    // 2. 增量PID计算单帧速度调节量
    float delta_left = PID_Increase(diff_steer.left_speed_pid,
                                    motor_LE.current_speed, left_target_speed);
    float delta_right = PID_Increase(diff_steer.right_speed_pid,
                                     motor_RE.current_speed, right_target_speed);

    // 3. 累加PID输出（增量式PID核心：保存历史输出总和）
    diff_steer.left_pid_output_cm_s  += delta_left;
    diff_steer.right_pid_output_cm_s += delta_right;

    // 4. PID输出速度转回PWM
    int16_t raw_left_pwm  = (int16_t)CM_S_TO_PWM(diff_steer.left_pid_output_cm_s);
    int16_t raw_right_pwm = (int16_t)CM_S_TO_PWM(diff_steer.right_pid_output_cm_s);

    // 硬件最大PWM限幅 ±6000
    const int16_t MAX_MOTOR_PWM = 6000;
    raw_left_pwm  = Limit_int(-MAX_MOTOR_PWM, raw_left_pwm, MAX_MOTOR_PWM);
    raw_right_pwm = Limit_int(-MAX_MOTOR_PWM, raw_right_pwm, MAX_MOTOR_PWM);

    // 5. 计算本帧相对上一帧PWM变化量
    int16_t left_step  = raw_left_pwm  - diff_steer.last_left_pwm;
    int16_t right_step = raw_right_pwm - diff_steer.last_right_pwm;

    // 6. 单帧变化量平滑限幅，抑制急加减速抖动
    left_step  = Limit_int(-PWM_CHANGE_LIMIT, left_step, PWM_CHANGE_LIMIT);
    right_step = Limit_int(-PWM_CHANGE_LIMIT, right_step, PWM_CHANGE_LIMIT);

    // 7. 叠加平滑步长 + 电机死区补偿
    diff_steer.left_pwm  = diff_steer.last_left_pwm + left_step + MOTOR_L_BIAS_PWM - MOTOR_R_BIAS_PWM;
    diff_steer.right_pwm = diff_steer.last_right_pwm + right_step;

    // 8. 更新历史PWM缓存，下一帧做平滑基准
    diff_steer.last_left_pwm  = diff_steer.left_pwm;
    diff_steer.last_right_pwm = diff_steer.right_pwm;

    // 同步更新有效赛道缓存（兼容原有无效赛道逻辑）
    diff_steer.last_valid_left_pwm  = diff_steer.left_pwm;
    diff_steer.last_valid_right_pwm = diff_steer.right_pwm;

    // 9. 输出电机
    Motor_L_SetSpeed(diff_steer.left_pwm);
    Motor_R_SetSpeed(diff_steer.right_pwm);
}
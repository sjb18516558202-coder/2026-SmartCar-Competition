/******************************************************************************************
 * @file           inflection_detect.cpp
 * @brief          十字赛道拐点检测 核心实现文件
 * @details        实现丢线检测、稳定段判断、突变检测、拐点筛选、直线拟合、
 *                 边界补全、中线平滑所有核心算法逻辑
 ******************************************************************************************/
// 包含头文件，获取宏定义、枚举、结构体、函数声明
#include "inflection_detect.hpp"
// 字符串操作头文件，用于memset清空数组
#include <string.h>
#include <stdio.h>

#include "inflection_round.hpp" 



/******************************************************************************************
 * @brief 日志打印宏（根据开关自动开启/关闭）
 ******************************************************************************************/
#if INFLECT_LOG_ENABLE
  #define INFLECT_LOG(format, ...)    printf("[INFLECT] " format "\r\n", ##__VA_ARGS__)
  #define INFLECT_DEBUG(format, ...)  printf("[INFLECT-DEBUG] " format "\r\n", ##__VA_ARGS__)
  #define INFLECT_WARN(format, ...)   printf("[INFLECT-WARN] " format "\r\n", ##__VA_ARGS__)
  #define INFLECT_DETAIL(format, ...) printf("[INFLECT-DETAIL] " format "\r\n", ##__VA_ARGS__)
#else
  #define INFLECT_LOG(...)
  #define INFLECT_DEBUG(...)
  #define INFLECT_WARN(...)
  #define INFLECT_DETAIL(...)
#endif

/******************************************************************************************
 * @brief 全局变量定义
 * @note  存储算法运行的核心数据，初始化默认值
 ******************************************************************************************/
// 存储4个拐点的最终Y坐标，初始化为0 → 0代表未检测到对应拐点
uint8_t inflect_final_row[INFLECT_TOTAL] = {0};

extern bool target_avoid_running;
extern bool red_brick_active;

/******************************************************************************************
 * @brief 静态内部工具函数
 * @note  仅在本文件内部调用，外部无法访问，封装基础算法单元
 ******************************************************************************************/
/**
 * @brief  丢线检测核心函数
 * @param  row: 丢线检测的基准行号（以该行为中心检查）
 * @param  type: 拐点类型，决定检查方向+检查哪一侧边界
 * @return bool: true=检测到边界丢失，false=边界正常
 * @note   规则：下拐点向上查15行，上拐点向下查15行；左拐点只查左边界，右拐点只查右边界
 */
static bool check_line_lost(uint8_t row, InflectType_E type)
{
    int8_t step = 0;                // 遍历步长：-1=向上遍历，1=向下遍历
    uint8_t check_end = 0;          // 遍历的结束行号，防止越界

    // 分支1：下拐点（左下/右下）→ 向上检查丢线
    if (type == INFLECT_LEFT_LOWER || type == INFLECT_RIGHT_LOWER)
    {
        step = -1;
        // 计算结束行：如果向上15行越界，则使用有效区域上边界
        check_end = (row - LOST_CHECK_ROWS) < INFLECT_UPPER_LIMIT ? INFLECT_UPPER_LIMIT : (row - LOST_CHECK_ROWS);
    }
    // 分支2：上拐点（左上/右上）→ 向下检查丢线
    else
    {
        step = 1;
        // 计算结束行：如果向下15行越界，则使用有效区域下边界
        check_end = (row + LOST_CHECK_ROWS) > INFLECT_LOWER_LIMIT ? INFLECT_LOWER_LIMIT : (row + LOST_CHECK_ROWS);
    }

    // 循环遍历指定范围，逐行检查丢线
    // 向上遍历：r >= 结束行；向下遍历：r <= 结束行
    for (uint8_t r = row; (step == -1) ? (r >= check_end) : (r <= check_end); r += step)
    {
        // 左拐点 → 仅检查左边界是否丢失
        if (type == INFLECT_LEFT_LOWER || type == INFLECT_LEFT_UPPER)
        {
            // 左边界X < 阈值 → 判定丢线，直接返回true
            if (left_line_list[r] < LEFT_LOST_THRESH) return true;
        }
        // 右拐点 → 仅检查右边界是否丢失
        else
        {
            // 右边界X > 阈值 → 判定丢线，直接返回true
            if (right_line_list[r] > RIGHT_LOST_THRESH) return true;
        }
    }
    // 遍历完成，未发现丢线 → 返回false
    return false;
}

/**
 * @brief  稳定段检测函数：判断连续N行边界是否平稳无丢线
 * @param  row: 稳定段检测的基准行号
 * @param  type: 拐点类型，决定检查方向+边界
 * @return bool: true=有效稳定段，false=不稳定
 * @note   规则：下拐点向下查连续3行，上拐点向上查连续3行
 */
static bool check_stable_segment(uint8_t row, InflectType_E type)
{
    uint8_t *line_list = NULL;  // 指针：指向左边界数组或右边界数组
    int8_t step = 0;           // 遍历步长：1=向下，-1=向上

    // 绑定对应边界数组：左拐点→左边界，右拐点→右边界
    if (type == INFLECT_LEFT_LOWER || type == INFLECT_LEFT_UPPER) 
        line_list = left_line_list;
    else 
        line_list = right_line_list;

    // 设置遍历方向：下拐点向下检查，上拐点向上检查
    if (type == INFLECT_LEFT_LOWER || type == INFLECT_RIGHT_LOWER) 
        step = 1;
    else 
        step = -1;

    // 循环检查连续3行的平稳性（循环次数=连续行数-1）
    for (uint8_t i = 0; i < STABLE_CONTINUOUS_ROWS - 1; i++)
    {
        uint8_t curr_r = row + i * step;    // 当前遍历行
        uint8_t next_r = curr_r + step;     // 下一行（相邻行）

        // 行号超出有效范围 → 直接判定不稳定
        if (next_r < INFLECT_UPPER_LIMIT || next_r > INFLECT_LOWER_LIMIT) 
            return false;

        // 计算相邻两行边界的差值绝对值
        int16_t diff = abs((int16_t)line_list[curr_r] - line_list[next_r]);
        // 差值≥阈值 → 边界突变，不是稳定段
        if (diff >= STABLE_DIFF_THRESH) 
            return false;

        // 稳定段内存在丢线 → 稳定段无效
        if ((line_list == left_line_list && left_line_list[curr_r] < STABLE_LEFT_LOST) ||
            (line_list == right_line_list && right_line_list[curr_r] > STABLE_RIGHT_LOST))
            return false;
    }
    // 所有条件满足 → 判定为有效稳定段
    return true;
}

/**
 * @brief  突变检测函数：判断边界是否发生剧烈跳变
 * @param  row: 突变检测的目标行号
 * @param  type: 拐点类型，决定突变方向
 * @return bool: true=有效突变，false=无突变
 * @note   严格遵循指定方向：左下正突变，右下负突变，左上正突变，右上负突变
 */
static bool detect_mutation(uint8_t row, InflectType_E type)
{
    int16_t diff = 0;    // 存储边界坐标差值
    bool dir_ok = false; // 突变方向是否符合要求标志

    // 根据拐点类型，计算差值并判断方向
    switch (type)
    {
        case INFLECT_LEFT_LOWER:  // 左下拐点：当前行 - 上一行 > 0 → 正向突变
            diff = left_line_list[row] - left_line_list[row-1];
            dir_ok = (diff > 0);
            break;
        case INFLECT_RIGHT_LOWER: // 右下拐点：当前行 - 上一行 < 0 → 负向突变
            diff = right_line_list[row] - right_line_list[row-1];
            dir_ok = (diff < 0);
            break;
        case INFLECT_LEFT_UPPER:  // 左上拐点：当前行 - 下一行 > 0 → 正向突变
            diff = left_line_list[row] - left_line_list[row+1];
            dir_ok = (diff > 0);
            break;
        case INFLECT_RIGHT_UPPER: // 右上拐点：当前行 - 下一行 < 0 → 负向突变
            diff = right_line_list[row] - right_line_list[row+1];
            dir_ok = (diff < 0);
            break;
        default: 
            return false; // 无效类型，直接返回无突变
    }

    // 方向正确 + 差值绝对值超过阈值 → 判定为有效突变
    return (dir_ok && (abs(diff) > MUTATION_DIFF_THRESH));
}

/**
 * @brief  两点法直线拟合：已知两点拟合直线 x = k*y + b
 * @param  x1,y1: 第一个点的X、Y坐标
 * @param  x2,y2: 第二个点的X、Y坐标
 * @return FitResult_t: 拟合结果结构体
 * @note   公式：k=(x1-x2)/(y1-y2)  b=x1 - k*y1
 *         不需要斜率有效性判断
 */
FitResult_t two_point_fit(float x1, uint8_t y1, float x2, uint8_t y2)
{
    INFLECT_DETAIL("【两点拟合】开始 点1(%.0f,%d), 点2(%.0f,%d)", x1, y1, x2, y2);
    FitResult_t res = {0};

    // 分母 y1-y2 不能为0
    float dy = y1 - y2;
    if (fabs(dy) < SLOPE_CHECK_THRESH) {
        INFLECT_WARN("【两点拟合】y1-y2=0，无法计算k");
        return res;
    }

    // 严格按公式计算
    res.k = (x1 - x2) / dy;
    res.b = x1 - res.k * y1;
    res.valid = true;
    res.start_row = y1;

    INFLECT_DETAIL("【两点拟合】完成 k=%.4f, b=%.4f", res.k, res.b);
    return res;
}

/**
 * @brief  最小二乘法拟合直线 x = k*y + b
 * @param  start_row  : 起始行（拐点行）
 * @param  line_type  : 左/右边界
 * @param  dir        : 采集方向
 * @return FitResult_t
 * @note   规则：
 *         1. 采集最多8个点
 *         2. 点不足 → k=0，b=拐点x
 *         3. 算完k、b后做斜率校验
 *         4. 左边界k≤0，右边界k≥0，否则k=0，b=拐点x
 */
FitResult_t least_square_fit(uint8_t start_row, LineType_E line_type, TraverseDir_E dir)
{
    INFLECT_DETAIL("【最小二乘拟合】开始 起始行=%d, 边界=%s, 方向=%s",
                   start_row, line_type==LINE_LEFT?"左":"右", dir==TRAVEL_UP?"向上":"向下");

    FitResult_t res = {0};
    uint8_t *line_list = (line_type == LINE_LEFT) ? left_line_list : right_line_list;
    float inflect_x = line_list[start_row];  // 拐点自身X坐标（备用）

    // 最小二乘求和变量
    float sum_x = 0, sum_y = 0, sum_xy = 0, sum_y2 = 0;
    uint8_t point_cnt = 0;

    // 采集最多8个点
    for (uint8_t i = 0; i < 8; i++) {
        uint8_t r = (dir == TRAVEL_UP) ? (start_row - i) : (start_row + i);
        if (r < INFLECT_UPPER_LIMIT || r > INFLECT_LOWER_LIMIT) break;

        sum_x += line_list[r];
        sum_y += r;
        sum_xy += line_list[r] * r;
        sum_y2 += r * r;
        point_cnt++;
    }

    INFLECT_DETAIL("【最小二乘】采集点数=%d, 拐点x=%.0f", point_cnt, inflect_x);

    // ====================== 规则2：点不足 → k=0，b=拐点x ======================
    if (point_cnt < 4) {
        res.k = 0.0f;
        res.b = inflect_x;
        res.valid = true;
        res.start_row = start_row;
        INFLECT_WARN("【最小二乘】点数不足，强制 k=0, b=%.0f", res.b);
        return res;
    }

    // ====================== 正常最小二乘公式计算 ======================
    float N = (float)point_cnt;
    float den = N * sum_y2 - sum_y * sum_y;

    if (fabs(den) < SLOPE_CHECK_THRESH) den = 1e-6f;

    res.k = (N * sum_xy - sum_x * sum_y) / den;
    res.b = (sum_x - res.k * sum_y) / N;
    res.start_row = start_row;

    INFLECT_DETAIL("【最小二乘】计算完成 k=%.4f, b=%.4f", res.k, res.b);

    // ====================== 规则4：斜率有效性判断 ======================
    bool slope_valid = true;
    if (line_type == LINE_LEFT && res.k > 0) {
        slope_valid = false;
    }
    if (line_type == LINE_RIGHT && res.k < 0) {
        slope_valid = false;
    }

    if (!slope_valid) {
        res.k = 0.0f;
        res.b = inflect_x;
        INFLECT_WARN("【最小二乘】斜率非法，强制 k=0, b=%.0f", res.b);
    }

    res.valid = true;  // 最小二乘最终一定返回有效拟合
    return res;
}

/**
 * @brief  根据拟合直线计算指定行的边界X坐标
 * @param  y: 目标行号（Y坐标）
 * @param  fit: 拟合结果
 * @return float: 计算得到的边界X坐标
 * @note   带边界保护，防止坐标超出图像范围
 */
static float calculate_x(uint8_t y, FitResult_t fit)
{
    // 拟合无效 → 返回0
    if (!fit.valid) 
        return 0;
    // 直线方程 x = k*y + b 计算X坐标
    float x = fit.k * y + fit.b;

    // X坐标边界保护：不能小于0，不能大于图像宽度
    if (x < 0) x = 0;
    if (x >= IMAGE_WIDTH) x = IMAGE_WIDTH - 1;
    return x;
}

/******************************************************************************************
 * @brief 核心函数：单个拐点有效性检测
 * @param  row: 待检测的行号
 * @param  type: 拐点类型
 * @return bool: true=有效拐点，false=无效拐点
 * @note   判定顺序：突变 → 连续稳定 → 丢线，任一不满足直接判定无效
 ******************************************************************************************/
static bool detect_single_inflect(uint8_t row, InflectType_E type)
{
    // 基础判断1：行号超出有效范围 → 无效
    if (row < INFLECT_UPPER_LIMIT || row > INFLECT_LOWER_LIMIT) 
        return false;
    // 基础判断2：图像最顶端/最底端行不能作为拐点 → 无效
    if ((type >= INFLECT_LEFT_UPPER && row == INFLECT_UPPER_LIMIT) ||
        (type <= INFLECT_RIGHT_LOWER && row == INFLECT_LOWER_LIMIT))
        return false;

    // 第一步：检测是否发生突变 → 无突变直接判定无效
    if (!detect_mutation(row, type)) 
        return false;

    // 第二步：检测是否为连续稳定段 → 不稳定直接判定无效
    if (!check_stable_segment(row, type)) 
        return false;

    // 第三步：检测是否存在丢线 → 三条件全部满足 → 有效拐点
    return check_line_lost(row, type);
}

/******************************************************************************************
 * @brief 核心函数：全图检测4个十字拐点
 * @note   检测顺序：从下往上搜下拐点 → 从上往下搜上拐点 → 补搜未找到的上拐点
 ******************************************************************************************/
static void detect_all_inflections(void)
{
    // 清空上一帧的拐点数据，全部置0
    memset(inflect_final_row, 0, sizeof(inflect_final_row));
    bool found = false;          // 拐点找到标志
    uint8_t final_row = 0;      // 最终拐点行号

    // 计算上拐点检测的有效起始行
    uint8_t upper_start;
    // 直道进环阶段 → 起始行 = search_cutoff_row + 15
    if ((track_state == LEFT_ROUND || track_state == RIGHT_ROUND) && round_stage == ROUND_STAGE_DIRECT)
    {
        //upper_start = search_cutoff_row + 15;
        upper_start = 41 ;
        INFLECT_DEBUG("【环岛直道进环】上拐点起始行修正为 %d", upper_start);
    }
    else
    {
        upper_start = search_cutoff_row + UPPER_INFLECT_OFFSET;
    }

    INFLECT_LOG("=== 开始检测4个拐点 ===");

    /********** 步骤1：从下往上遍历，检测左下、右下两个下拐点 **********/
    for (uint8_t row = INFLECT_LOWER_LIMIT; row >= upper_start; row--)
    {
        // 检测左下拐点：未找到才执行
        if (!inflect_final_row[INFLECT_LEFT_LOWER])
        {
            found = detect_single_inflect(row, INFLECT_LEFT_LOWER);
            if (found)
            {
                final_row = row + INFLECT_OFFSET; // 下拐点+偏移量
                inflect_final_row[INFLECT_LEFT_LOWER] = final_row;
                INFLECT_DEBUG("检测到左下拐点，行=%d", final_row);
            }
        }
        // 检测右下拐点：未找到才执行
        if (!inflect_final_row[INFLECT_RIGHT_LOWER])
        {
            found = detect_single_inflect(row, INFLECT_RIGHT_LOWER);
            if (found)
            {
                final_row = row + INFLECT_OFFSET;
                inflect_final_row[INFLECT_RIGHT_LOWER] = final_row;
                INFLECT_DEBUG("检测到右下拐点，行=%d", final_row);
            }
        }
        // 两个下拐点均找到 → 提前退出循环，提升效率
        if (inflect_final_row[INFLECT_LEFT_LOWER] && inflect_final_row[INFLECT_RIGHT_LOWER]) 
            break;
    }

    /********** 步骤2：从上往下遍历，检测左上、右上两个上拐点 **********/
    for (uint8_t row = upper_start; row <= INFLECT_LOWER_LIMIT; row++)
    {
        // 检测左上拐点：未找到才执行
        if (!inflect_final_row[INFLECT_LEFT_UPPER])
        {
            found = detect_single_inflect(row, INFLECT_LEFT_UPPER);
            if (found)
            {
                final_row = row - INFLECT_OFFSET; // 上拐点-偏移量
                inflect_final_row[INFLECT_LEFT_UPPER] = final_row;
                INFLECT_DEBUG("检测到左上拐点，行=%d", final_row);
            }
        }
        // 检测右上拐点：未找到才执行
        if (!inflect_final_row[INFLECT_RIGHT_UPPER])
        {
            found = detect_single_inflect(row, INFLECT_RIGHT_UPPER);
            if (found)
            {
                final_row = row - INFLECT_OFFSET;
                inflect_final_row[INFLECT_RIGHT_UPPER] = final_row;
                INFLECT_DEBUG("检测到右上拐点，行=%d", final_row);
            }
        }
        // 两个上拐点均找到 → 提前退出循环
        if (inflect_final_row[INFLECT_LEFT_UPPER] && inflect_final_row[INFLECT_RIGHT_UPPER]) 
            break;
    }

    /********** 步骤3：未找到的上拐点，从下往上补搜 **********/
    // 补搜左上拐点
    if (!inflect_final_row[INFLECT_LEFT_UPPER])
    {
        for (uint8_t row = INFLECT_LOWER_LIMIT; row >= upper_start; row--)
        {
            if (detect_single_inflect(row, INFLECT_LEFT_UPPER))
            {
                inflect_final_row[INFLECT_LEFT_UPPER] = row - INFLECT_OFFSET;
                INFLECT_DEBUG("补搜到左上拐点，行=%d", row);
                break;
            }
        }
    }
    // 补搜右上拐点
    if (!inflect_final_row[INFLECT_RIGHT_UPPER])
    {
        for (uint8_t row = INFLECT_LOWER_LIMIT; row >= upper_start; row--)
        {
            if (detect_single_inflect(row, INFLECT_RIGHT_UPPER))
            {
                inflect_final_row[INFLECT_RIGHT_UPPER] = row - INFLECT_OFFSET;
                INFLECT_DEBUG("补搜到右上拐点，行=%d", row);
                break;
            }
        }
    }

    INFLECT_LOG("检测结果：左下=%d 右下=%d 左上=%d 右上=%d",
        inflect_final_row[INFLECT_LEFT_LOWER],
        inflect_final_row[INFLECT_RIGHT_LOWER],
        inflect_final_row[INFLECT_LEFT_UPPER],
        inflect_final_row[INFLECT_RIGHT_UPPER]);
}

/******************************************************************************************
 * @brief 核心函数：无效拐点过滤
 * @note   过滤规则：逻辑错误、坐标越界、行数差不足、位置不合理
 ******************************************************************************************/
static void filter_invalid_inflections(void)
{
    // 简化变量名，提升代码可读性
    uint8_t ll = inflect_final_row[INFLECT_LEFT_LOWER];
    uint8_t lu = inflect_final_row[INFLECT_LEFT_UPPER];
    uint8_t rl = inflect_final_row[INFLECT_RIGHT_LOWER];
    uint8_t ru = inflect_final_row[INFLECT_RIGHT_UPPER];

    // ===================== 动态计算有效拐点最小Y坐标 =====================
    uint8_t upper_inflect_min_y = search_cutoff_row + UPPER_INFLECT_OFFSET;  // 上拐点最小Y
    uint8_t lower_inflect_min_y = upper_inflect_min_y + INFLECT_ROW_DIFF;    // 下拐点最小Y

    INFLECT_LOG("=== 开始过滤无效拐点 ===");

    INFLECT_LOG("动态阈值：上拐点最小Y=%d, 下拐点最小Y=%d, 行差阈值=%d",
                upper_inflect_min_y, lower_inflect_min_y, INFLECT_ROW_DIFF);

    /************************* 左拐点无效过滤 *************************/
    if (ll) // 仅当左下拐点存在时执行过滤
    {
        // 规则1：下拐点Y ≤ 上拐点Y → 逻辑错误，剔除
        if (lu && ll <= lu) { 
            inflect_final_row[INFLECT_LEFT_LOWER] = 0; ll = 0; 
            INFLECT_WARN("剔除左下拐点：下Y ≤ 上Y");
        }
        // 规则2：下拐点太靠上（Y<30）→ 剔除
        if (ll < lower_inflect_min_y) { 
            inflect_final_row[INFLECT_LEFT_LOWER] = 0; ll = 0; 
            INFLECT_WARN("剔除左下拐点：位置太靠上");
        }
        // 规则3：X坐标越界 → 剔除
        if (ll && (left_line_list[ll] < LEFT_INFLECT_MIN_X || left_line_list[ll] > LEFT_INFLECT_MAX_X))
            { inflect_final_row[INFLECT_LEFT_LOWER] = 0; ll = 0; INFLECT_WARN("剔除左下拐点：X越界"); }
        // 规则4：上下拐点行数差不足10 → 剔除
        if (ll && lu && (ll - lu) < INFLECT_ROW_DIFF)
            { inflect_final_row[INFLECT_LEFT_LOWER] = 0; ll = 0; INFLECT_WARN("剔除左下拐点：行差不足"); }
    }

    if (lu) // 仅当左上拐点存在时执行过滤
    {
        // 规则1：上拐点太靠上（Y<20）→ 剔除
        if (lu < upper_inflect_min_y) { 
            inflect_final_row[INFLECT_LEFT_UPPER] = 0; lu = 0; 
            INFLECT_WARN("剔除左上拐点：位置太靠上");
        }
        // 规则2：X坐标越界 → 剔除
        if (lu && (left_line_list[lu] < LEFT_INFLECT_MIN_X || left_line_list[lu] > LEFT_INFLECT_MAX_X))
            { inflect_final_row[INFLECT_LEFT_UPPER] = 0; lu = 0; INFLECT_WARN("剔除左上拐点：X越界"); }
    }

    /************************* 右拐点无效过滤 *************************/
    if (rl) // 仅当右下拐点存在时执行过滤
    {
        // 规则1：下拐点Y ≤ 上拐点Y → 逻辑错误，剔除
        if (ru && rl <= ru) { 
            inflect_final_row[INFLECT_RIGHT_LOWER] = 0; rl = 0; 
            INFLECT_WARN("剔除右下拐点：下Y ≤ 上Y");
        }
        // 规则2：下拐点太靠上（Y<30）→ 剔除
        if (rl < lower_inflect_min_y) { 
            inflect_final_row[INFLECT_RIGHT_LOWER] = 0; rl = 0; 
            INFLECT_WARN("剔除右下拐点：位置太靠上");
        }
        // 规则3：X坐标越界 → 剔除
        if (rl && (right_line_list[rl] < RIGHT_INFLECT_MIN_X || right_line_list[rl] > RIGHT_INFLECT_MAX_X))
            { inflect_final_row[INFLECT_RIGHT_LOWER] = 0; rl = 0; INFLECT_WARN("剔除右下拐点：X越界"); }
        // 规则4：上下拐点行数差不足10 → 剔除
        if (rl && ru && (rl - ru) < INFLECT_ROW_DIFF)
            { inflect_final_row[INFLECT_RIGHT_LOWER] = 0; rl = 0; INFLECT_WARN("剔除右下拐点：行差不足"); }
    }

    if (ru) // 仅当右上拐点存在时执行过滤
    {
        // 规则1：上拐点太靠上（Y<20）→ 剔除
        if (ru < upper_inflect_min_y) { 
            inflect_final_row[INFLECT_RIGHT_UPPER] = 0; ru = 0; 
            INFLECT_WARN("剔除右上拐点：位置太靠上");
        }
        // 规则2：X坐标越界 → 剔除
        if (ru && (right_line_list[ru] < RIGHT_INFLECT_MIN_X || right_line_list[ru] > RIGHT_INFLECT_MAX_X))
            { inflect_final_row[INFLECT_RIGHT_UPPER] = 0; ru = 0; INFLECT_WARN("剔除右上拐点：X越界"); }
    }

    INFLECT_LOG("过滤后：左下=%d 右下=%d 左上=%d 右上=%d", ll, rl, lu, ru);
}

/******************************************************************************************
 * @brief 核心函数：获取边界最优拟合结果
 * @param  line_type: 边界类型（左/右）
 * @return FitResult_t: 拟合结果
 * @note   优先两点法，其次最小二乘法，无拐点返回无效
 ******************************************************************************************/
static FitResult_t get_boundary_fit(LineType_E line_type)
{
    // 获取对应边界的上下拐点行号
    uint8_t upper = (line_type == LINE_LEFT) ? inflect_final_row[INFLECT_LEFT_UPPER] : inflect_final_row[INFLECT_RIGHT_UPPER];
    uint8_t lower = (line_type == LINE_LEFT) ? inflect_final_row[INFLECT_LEFT_LOWER] : inflect_final_row[INFLECT_RIGHT_LOWER];
    uint8_t *line = (line_type == LINE_LEFT) ? left_line_list : right_line_list;

    // 场景1：上下拐点都存在 → 两点法拟合
    if (upper && lower) {
        INFLECT_DEBUG("%s边界：两点拟合", line_type==LINE_LEFT ? "左" : "右");
        return two_point_fit(line[lower], lower, line[upper], upper);
    }

    // 场景2：仅上拐点存在 → 向上采集最小二乘拟合
    if (upper && !lower) {
        INFLECT_DEBUG("%s边界：上拐点向上拟合", line_type==LINE_LEFT ? "左" : "右");
        return least_square_fit(upper, line_type, TRAVEL_UP);
    }

    // 场景3：仅下拐点存在 → 向下采集最小二乘拟合
    if (lower && !upper) {
        INFLECT_DEBUG("%s边界：下拐点向下拟合", line_type==LINE_LEFT ? "左" : "右");
        return least_square_fit(lower, line_type, TRAVEL_DOWN);
    }

    // 无任何拐点 → 返回无效拟合结果
    return (FitResult_t){0};
}

/******************************************************************************************
 * @brief 核心函数：边界补线，修复丢失的赛道边界
 * @note   覆盖6大补线场景，带边界保护
 ******************************************************************************************/
static void fill_boundary_line(void)
{
    // 简化变量名
    uint8_t ll = inflect_final_row[INFLECT_LEFT_LOWER];
    uint8_t lu = inflect_final_row[INFLECT_LEFT_UPPER];
    uint8_t rl = inflect_final_row[INFLECT_RIGHT_LOWER];
    uint8_t ru = inflect_final_row[INFLECT_RIGHT_UPPER];

    // 获取左右边界的拟合结果
    FitResult_t left_fit = get_boundary_fit(LINE_LEFT);
    FitResult_t right_fit = get_boundary_fit(LINE_RIGHT);

    INFLECT_LOG("=== 开始边界补线 ===");

    // 场景1：4个拐点全部检测到 → 两点法补线
    if (ll && lu && rl && ru)
    {
        INFLECT_LOG("补线场景：4点完整");
        // 左边界：左下→左上补线
        for (uint8_t i = ll; i >= lu; i--)
        {
            uint8_t x = round(calculate_x(i, left_fit));
            left_line_list[i] = (x > LEFT_BOUND_MAX) ? LEFT_BOUND_MAX : x;
        }
        // 右边界：右下→右上补线
        for (uint8_t i = rl; i >= ru; i--)
        {
            uint8_t x = round(calculate_x(i, right_fit));
            right_line_list[i] = (x < RIGHT_BOUND_MIN) ? RIGHT_BOUND_MIN : x;
        }
    }
    // 场景2：缺失右下拐点
    else if (ll && lu && ru && !rl)
    {
        INFLECT_LOG("补线场景：缺右下");
        // 左边界正常补线
        for (uint8_t i = ll; i >= lu; i--)
        {
            uint8_t x = round(calculate_x(i, left_fit));
            left_line_list[i] = (x > LEFT_BOUND_MAX) ? LEFT_BOUND_MAX : x;
        }
        // 右边界：右上拐点向下补到底端
        for (uint8_t i = ru; i <= FILL_BOTTOM_ROW; i++)
        {
            uint8_t x = round(calculate_x(i, right_fit));
            right_line_list[i] = (x < RIGHT_BOUND_MIN) ? RIGHT_BOUND_MIN : x;
        }
    }
    // 场景3：缺失左下拐点
    else if (rl && ru && lu && !ll)
    {
        INFLECT_LOG("补线场景：缺左下");
        // 右边界正常补线
        for (uint8_t i = rl; i >= ru; i--)
        {
            uint8_t x = round(calculate_x(i, right_fit));
            right_line_list[i] = (x < RIGHT_BOUND_MIN) ? RIGHT_BOUND_MIN : x;
        }
        // 左边界：左上拐点向下补到底端
        for (uint8_t i = lu; i <= FILL_BOTTOM_ROW; i++)
        {
            uint8_t x = round(calculate_x(i, left_fit));
            left_line_list[i] = (x > LEFT_BOUND_MAX) ? LEFT_BOUND_MAX : x;
        }
    }
    // 场景4：仅检测到两个上拐点
    else if (lu && ru && !ll && !rl)
    {
        INFLECT_LOG("补线场景：仅双上");
        // 左边界向下补全
        for (uint8_t i = lu; i <= FILL_BOTTOM_ROW; i++)
        {
            uint8_t x = round(calculate_x(i, left_fit));
            left_line_list[i] = (x > LEFT_BOUND_MAX) ? LEFT_BOUND_MAX : x;
        }
        // 右边界向下补全
        for (uint8_t i = ru; i <= FILL_BOTTOM_ROW; i++)
        {
            uint8_t x = round(calculate_x(i, right_fit));
            right_line_list[i] = (x < RIGHT_BOUND_MIN) ? RIGHT_BOUND_MIN : x;
        }
    }
    // 场景5：单边完整（仅左/仅右拐点）
    else if (ll && lu && !rl && !ru)
    {
        INFLECT_LOG("补线场景：仅左完整");
        // 仅左边界补线
        for (uint8_t i = ll; i >= lu; i--)
        {
            uint8_t x = round(calculate_x(i, left_fit));
            left_line_list[i] = (x > LEFT_BOUND_MAX) ? LEFT_BOUND_MAX : x;
        }
    }
    else if (rl && ru && !ll && !lu)
    {
        INFLECT_LOG("补线场景：仅右完整");
        // 仅右边界补线
        for (uint8_t i = rl; i >= ru; i--)
        {
            uint8_t x = round(calculate_x(i, right_fit));
            right_line_list[i] = (x < RIGHT_BOUND_MIN) ? RIGHT_BOUND_MIN : x;
        }
    }

        // ===================== 直接判断 单上拐点 补线逻辑 =====================
    // 条件1：没有下拐点，只有 单个 上拐点
    // 条件2：该上拐点Y行必须 > 55，过小直接跳过补线
    bool has_lower = (ll != 0 || rl != 0);
    uint8_t upper_count = 0;
    if(lu) upper_count++;
    if(ru) upper_count++;

    if (!has_lower && upper_count == 1)
    {
        FitResult_t fit;
        uint8_t start_y;

        // 单右上拐点：右边从右上向上拟合 → 向下补到底
        if (ru != 0 && lu == 0)
        {
            start_y = ru;
            // 新增限制：上拐点行必须大于55才执行补线
            if(start_y > SINGLE_UPPER_FILL_MIN_Y)
            {
                fit = least_square_fit(start_y, LINE_RIGHT, TRAVEL_UP);
                for (uint8_t i = start_y; i <= FILL_BOTTOM_ROW; i++)
                {
                    uint8_t x = round(calculate_x(i, fit));
                    right_line_list[i] = (x < RIGHT_BOUND_MIN) ? RIGHT_BOUND_MIN : x;
                }
                INFLECT_LOG("【单上补线】单右上拐点 y=%d >55 → 右侧向下补全", start_y);
            }
            else
            {
                INFLECT_WARN("【单上补线】单右上拐点 y=%d ≤55，位置过靠上，跳过补线", start_y);
            }
        }
        // 单左上拐点：左边从左上向上拟合 → 向下补到底
        else if (lu != 0 && ru == 0)
        {
            start_y = lu;
            // 新增限制：上拐点行必须大于55才执行补线
            if(start_y > SINGLE_UPPER_FILL_MIN_Y)
            {
                fit = least_square_fit(start_y, LINE_LEFT, TRAVEL_UP);
                for (uint8_t i = start_y; i <= FILL_BOTTOM_ROW; i++)
                {
                    uint8_t x = round(calculate_x(i, fit));
                    left_line_list[i] = (x > LEFT_BOUND_MAX) ? LEFT_BOUND_MAX : x;
                }
                INFLECT_LOG("【单上补线】单左上拐点 y=%d > %d → 左侧向下补全", start_y , SINGLE_UPPER_FILL_MIN_Y);
            }
            else
            {
                INFLECT_WARN("【单上补线】单左上拐点 y=%d ≤ %d，位置过靠上，跳过补线", start_y , SINGLE_UPPER_FILL_MIN_Y);
            }
        }
    }
}

/******************************************************************************************
 * @brief 核心函数：重新计算中线并做平滑处理
 * @note   从下向最小拐点行平滑，与下一行中线差值不超过阈值，强制限制
 ******************************************************************************************/
void recalculate_mid_line(void)
{
    uint8_t min_inflect_y = INFLECT_UPPER_LIMIT; 
    INFLECT_LOG("=== 重新计算中线 ===");

    //====================  从底部向上 ====================
    for (uint8_t i = FILL_BOTTOM_ROW; i >= min_inflect_y + 2 ; i--)
    {
        // -------------------- 【最终极边界保护】左右边界强制 0~159 --------------------
        int16_t left  = left_line_list[i];
        int16_t right = right_line_list[i];

        // 左边界保护
        if (left < 0) left = 0;
        if (left >= IMAGE_WIDTH) left = IMAGE_WIDTH - 1;

        // 右边界保护
        if (right < 0) right = 0;
        if (right >= IMAGE_WIDTH) right = IMAGE_WIDTH - 1;

        // 安全规则：右边界不能小于左边界
        if (right < left)
        {
            right = left;
        }

        // 写回安全值
        left_line_list[i]  = (uint8_t)left;
        right_line_list[i] = (uint8_t)right;

        // -------------------- 计算中线 --------------------
        uint8_t mid = (left + right) / 2;

        // -------------------- 平滑限制：和下一行差值不能超阈值 --------------------
        if (i < FILL_BOTTOM_ROW)
        {
            int16_t diff = abs((int16_t)mid - mid_line_list[i+1]);
            if (diff > MID_LINE_SMOOTH_THRESH)
            {
                // 强制限制在阈值范围内
                if (mid > mid_line_list[i+1])
                    mid = mid_line_list[i+1] + MID_LINE_SMOOTH_THRESH;
                else
                    mid = mid_line_list[i+1] - MID_LINE_SMOOTH_THRESH;
            }
        }

        // 中线自身边界保护
        if (mid >= IMAGE_WIDTH)
            mid = IMAGE_WIDTH - 1;

        // 写入最终中线
        mid_line_list[i] = mid;
    }
}

// ==========================
// 检测 + 过滤
// ==========================
void inflection_detect_process(void)
{
    INFLECT_LOG("========== 拐点检测流程开始 ==========");
    detect_all_inflections();    // 1. 检测图像中全部4个拐点
    filter_invalid_inflections(); // 2. 过滤所有无效拐点
}


// ==========================
// 补线 + 中线
// ==========================
void inflection_fill_boundary(void)
{
    fill_boundary_line();        // 3. 根据拟合结果补全丢失的边界
    recalculate_mid_line();      // 4. 重新计算并平滑赛道中线
    INFLECT_LOG("========== 拐点处理流程结束 ==========\r\n");
}


// ======================== 打印所有拐点 (x,y) 坐标 ========================
void print_inflection_points(void)
{
    // 取出4个最终拐点行号
    uint8_t ll = inflect_final_row[INFLECT_LEFT_LOWER];
    uint8_t lu = inflect_final_row[INFLECT_LEFT_UPPER];
    uint8_t rl = inflect_final_row[INFLECT_RIGHT_LOWER];
    uint8_t ru = inflect_final_row[INFLECT_RIGHT_UPPER];

    printf("\n===== 拐点坐标 (x, y) =====\n");
    
    // 左下拐点
    if(ll) 
        printf("左下拐点：x=%d, y=%d\n", left_line_list[ll], ll);
    else   
        printf("左下拐点：未找到\n");
    
    // 右下拐点
    if(rl) 
        printf("右下拐点：x=%d, y=%d\n", right_line_list[rl], rl);
    else   
        printf("右下拐点：未找到\n");
    
    // 左上拐点
    if(lu) 
        printf("左上拐点：x=%d, y=%d\n", left_line_list[lu], lu);
    else   
        printf("左上拐点：未找到\n");
    
    // 右上拐点
    if(ru) 
        printf("右上拐点：x=%d, y=%d\n", right_line_list[ru], ru);
    else   
        printf("右上拐点：未找到\n");
}

/******************************************************************************************
 * @brief 主入口函数：十字赛道全流程处理
 * @note   执行流程：拐点检测 → 无效过滤 → 边界补线 → 中线平滑
 ******************************************************************************************/
void inflection_detect_main(void)
{

    // ========== 绕行中 或 红砖避障中 → 跳过拐点，直接用简单中线 ==========
    if (target_avoid_running )
    {
        return;  // 提前返回，不执行后续的拐点检测和补线
    };


    // 拐点检测 + 滤波
    inflection_detect_process();

    //打印所有拐点
    //print_inflection_points();

    // 环岛判断与处理
    inflection_round_main();    

    // 普通赛道才执行补线
    if(track_state == NORMAL_TRACK)
    {
        inflection_fill_boundary();
    }
}

#ifndef _PID_hpp_
#define _PID_hpp_

// // ===================== PID结构体定义 =====================
typedef struct
{
      // 比例、积分、微分系数
    float Kp;          // 比例系数
    float Ki;          // 积分系数
    float Kd;          // 微分系数

    float LowPass;     // 一阶低通滤波系数（反馈值/微分项共用）

    // 误差相关变量
    float Error;       // 当前误差（设定值 - 反馈值）e(k)
    float LastError;   // 上一次误差 e(k-1)
    float PrevError;   // 上上次误差 e(k-2)（增量式PID专用）
    float Integral;    // 积分累加项（位置式PID专用）

    float LastData;    // 上一次滤波后反馈值
    float LastRawData; // 反馈值滤波历史缓存

    // 输出分量缓存
    float Out_P;       // 比例项输出缓存
    float Out_I;       // 积分项输出缓存
    float Out_D;       // 微分项输出缓存 
    float Out_D_Last;  // 微分项滤波历史值（新增：用于微分项低通滤波）
    float Output_PID;  // 最终输出值
} PID;

#include "zf_common_headfile.hpp"

#include "math.h"
#include "CustomFunction.hpp"

//宏定义
#define PID_Create(kp, ki, kd, lowpass)                 \
{                                                     \
    /* 初始化PID核心控制系数 */                        \
    .Kp = kp,                   /* 比例系数 */        \
    .Ki = ki,                   /* 积分系数 */        \
    .Kd = kd,                   /* 微分系数 */        \
                                                     \
    /* 滤波系数 */                                      \
    .LowPass = lowpass,         /* 一阶低通滤波系数 */ \
                                                                     \
    /* 初始化误差缓存（清零） */                                       \
    .Error = 0,                 /* 当前误差（设定值 - 反馈值） */      \
    .LastError = 0,             /* 上一次误差（k-1） */               \
    .PrevError = 0,             /* 上上次误差（k-2）（增量式专用）*/   \
    .LastData = 0,              /* 上一次反馈值 */                    \
    .LastRawData = 0,           /* 反馈值滤波缓存初始化为0 */          \
                                                       \
    /* 初始化输出分量缓存（清零） */                     \
    .Out_P = 0,                 /* 比例项输出缓存 */    \
    .Out_I = 0,                 /* 积分项输出缓存 */    \
    .Out_D = 0,                 /* 微分项输出缓存 */    \
    .Out_D_Last = 0,            /* 微分项滤波历史值初始化为0（新增） */ \
    .Output_PID = 0,            /* PID最终输出值 */     \
}

// ===================== PID核心参数 =====================
#define PID_SAMPLE_PERIOD   0.01f   // PID采样周期（单位：s，根据实际程序循环频率调整）
// 阈值参数
#define  I_Separation     5      // 积分分离阈值
#define  I_Limit          30     // 积分限幅阈值
#define  Output_Limit     100    // 输出限幅阈值


// 函数申明
// 增量式PID控制函数
float PID_Increase (PID *PID, float NowData, float Point);//反馈值(NowData)  设定值(Point)
// 位置式PID控制函数
float PID_Positional (PID *PID, float NowData, float Point);


// 变量定义
//电机PID初始化参数
extern PID motor_L_pid;
extern PID motor_R_pid;
// 转向环PID
extern PID steer_pid;


#endif


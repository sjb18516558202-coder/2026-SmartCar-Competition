#ifndef _Image_hpp_
#define _Image_hpp_

/**
 * @file Image.hpp
 * @brief 智能车视觉循迹核心头文件
 * @details 包含图像配置、全局变量声明、函数声明，集成曲率半径计算配置
 * @author 适配逐飞SDK智能车开发
 * @date 2026-03
 */

// 引入逐飞SDK核心头文件：包含设备驱动、数据类型、基础函数等核心定义
#include "zf_common_headfile.hpp"

#include "tcp_client_uvc_rgb_demo.hpp"

// 引入拐点检测声明（需自行实现）
#include "inflection_detect.hpp" 

#define GRAY_IMAGE_WIDTH          160     // 压缩后灰度图像宽度
#define GRAY_IMAGE_HEIGHT         120     // 压缩后灰度图像高度

// ===================== 图像处理核心参数（赛道调试相关） =====================
/**
 * @def FIXED_BINARY_THRESHOLD
 * @brief 固定二值化阈值
 * @note 灰度值>78判定为白色（赛道），≤78判定为黑色（背景）；
 *       赛道亮度变化时调整，建议范围50~100
 */
#define FIXED_BINARY_THRESHOLD  105

/**
 * @def MID_LINE_DIFF_THRESHOLD
 * @brief 相邻行中线差值阈值
 * @note 限制相邻行中线偏移不超过1像素，防止中线突变导致小车失控；
 *       数值越大越灵活，越小越稳定，建议1~3
 */
#define MID_LINE_DIFF_THRESHOLD 5

/**
 * @def SCAN_POS_CENTER
 * @brief 底部行扫描优先级1：图像中心位置
 * @note 优先扫描中心，适配大部分直道场景
 */
#define SCAN_POS_CENTER         GRAY_IMAGE_WIDTH/2

/**
 * @def SCAN_POS_1_4
 * @brief 底部行扫描优先级2：图像1/4宽度位置
 * @note 中心未找到时扫描，适配赛道偏左场景
 */
#define SCAN_POS_1_4           GRAY_IMAGE_WIDTH/4

/**
 * @def SCAN_POS_3_4
 * @brief 底部行扫描优先级3：图像3/4宽度位置
 * @note 1/4位置未找到时扫描，适配赛道偏右场景
 */
#define SCAN_POS_3_4           GRAY_IMAGE_WIDTH*3/4

// ===================== 最长白列列坐标限制（核心配置） =====================
// 最长白列左边界限制：列坐标不能小于，避免参考点跑到图像最左侧（非赛道区域）
#define MAX_WHITE_COL_LEFT_LIMIT  60   
// 最长白列右边界限制：列坐标不能大于，避免参考点跑到图像最右侧（非赛道区域）
#define MAX_WHITE_COL_RIGHT_LIMIT 100  



// 最小二乘法拟合底行到截止行的中线，计算斜率和角度 最小拟合点数
#define MIN_FIT_ROWS    5   

// 可根据实际需求调整这个设定行的值
// 搜索截止行
#define MIN_CUTOFF_ROW  30  


// ===================== 阶梯巡线法配置（核心调试参数） =====================
#define LADDER_STEP          10       // 阶梯巡线步长：基于下行边界偏移量，建议
                                     // 步长越大：搜索范围越宽，适配大弯道；步长越小：越稳定
#define SKIP_ROW             0       // 跳行行数：0=不跳行，建议0~2
                                     // 跳行可减少计算量，跳行时直接继承上一行边界坐标



// ===================== 图像索引宏（二维转一维，性能优化） =====================
/**
 * @def GET_IMAGE_PIXEL
 * @brief 二维图像坐标转一维数组索引宏
 * @param img 图像一维数组指针
 * @param i 行索引（垂直坐标，0为顶部，GRAY_IMAGE_HEIGHT-1为底部）
 * @param j 列索引（水平坐标，0为左侧，GRAY_IMAGE_WIDTH-1为右侧）
 * @return 对应位置的像素值
 * @note 逐飞SDK图像数据存储为一维数组，该宏是嵌入式图像处理常用优化手段；
 *       公式：行号*宽度 + 列号，避免二维数组的低效访问
 */
#define GET_IMAGE_PIXEL(img, i, j)  (img[(i) * GRAY_IMAGE_WIDTH + (j)])


/**
 * @brief 大津法自适应阈值偏置
 * @note 范围：正数→阈值升高（更少白色），负数→阈值降低（更多白色）    
 */
#define OTSU_THRESHOLD_BIAS       0//    


// ===================== 动态前瞻配置 =====================
#define LOOK_AHEAD_FAR_ROW      63//62    // 最远前瞻行              //80

#define LOOK_AHEAD_NEAR_ROW     93//95   // 最近前瞻行（底部）

#define UVC_ERROR               0     // 安装偏差    

#define ANGLE_THRESHOLD         10    // 动态前瞻起始偏差阈值（°）//10
#define ANGLE_MAX_VALID         50    // 最大有效偏差角度


// ===================== 全局变量声明（跨函数使用，需在cpp中实例化） =====================

// 视觉循迹核心输出（供差速控制使用）
extern float line_deviation;    // 循线偏差（像素）
extern float fit_slope;         // 拟合斜率（新增声明）
extern float fit_angle;         // 中线拟合角度（度，中间变量）

/**
 * @var ips200_obj
 * @brief IPS200屏幕对象
 * @note 用于调试绘制边界/中线，比赛时可注释相关绘制逻辑节省算力
 */
extern zf_device_ips200 ips200_obj;

/**
 * @var uvc_obj
 * @brief UVC摄像头对象
 * @note 用于采集原始灰度图像数据，需在初始化函数中配置摄像头参数（分辨率/帧率）
 */
extern zf_device_uvc uvc_obj;

/**
 * @var binary_image
 * @brief 二值化图像缓存数组
 * @note 尺寸：GRAY_IMAGE_WIDTH * GRAY_IMAGE_HEIGHT（160*120=19200字节）；
 *       存储二值化后的图像数据（0=黑/背景，255=白/赛道）
 */
extern uint8 binary_image[GRAY_IMAGE_HEIGHT][GRAY_IMAGE_WIDTH];

/**
 * @var left_line_list
 * @brief 每行左边界坐标数组
 * @note 索引0-119对应图像0-119行，存储每行赛道左边界的列坐标；
 *       例如：left_line_list[119] 表示图像最后一行的左边界列号
 */
extern uint8 left_line_list[GRAY_IMAGE_HEIGHT];

/**
 * @var right_line_list
 * @brief 每行右边界坐标数组
 * @note 索引0-119对应图像0-119行，存储每行赛道右边界的列坐标
 */
extern uint8 right_line_list[GRAY_IMAGE_HEIGHT];

/**
 * @var mid_line_list
 * @brief 每行中线坐标数组
 * @note 索引0-119对应图像0-119行，存储每行赛道中线的列坐标（(左+右)/2）；
 *       中线是小车转向控制的核心参考
 */
extern uint8 mid_line_list[GRAY_IMAGE_HEIGHT];

/**
 * @var mid_line
 * @brief 最终输出给小车转向控制的中线值
 * @note 直接使用图像底部行的中线（最稳定，离镜头最近）；
 *       范围：0~GRAY_IMAGE_WIDTH-1（0=最左，159=最右）
 */
extern uint8 mid_line;

/**
 * @var max_white_col_length
 * @brief 最长白色列的长度（像素）
 * @note 定义：从图像底部向上数，某列连续白色像素（赛道）的最大长度；
 *       作用：表征赛道在图像中的有效高度，用于减少无效计算
 */
extern uint8 max_white_col_length;

/**
 * @var search_cutoff_row
 * @brief 巡边搜索截止行
 * @note 计算公式：search_cutoff_row = 底部行 - max_white_col_length + 1；
 *       作用：仅处理 [search_cutoff_row, 底部行] 区域，上方行无赛道无需计算；
 *       示例：最长白列长度50 → 截止行=119-50+1=70 → 仅处理70~119行
 */
extern uint8 search_cutoff_row;

// 最长白列失效标记：true=无有效白色列（强制中心中线）
extern bool  max_white_col_invalid;   

// 最长白列列坐标
extern uint8 max_white_col_pos;


// 全局大津法阈值声明
extern uint8 otsu_threshold;

//逐飞助手边界数组声明
extern uint8 x1_boundary[];
extern uint8 x2_boundary[];
extern uint8 x3_boundary[];

// ===================== 目标板绕行参数 =====================
#define TARGET_AVOID_LOOK_ROW    90//100   // 目标绕行时使用的参考行号

#define AVOID_FINE_TUNE    0      // 绕行微调值

#define AVOID_DEV_LIMIT    50    // 绕行偏差最大限制

// ===================== 目标识别全局变量声明 =====================
extern bool target_avoid_running;      // 是否正在执行目标绕行

extern int   target_avoid_class;       // 目标类别：0=物资 1=交通 2=武器 -1=无


// ===================== 函数声明（对外接口，需在cpp中实现） =====================
/**
 * @fn gray_image_binaryzation
 * @brief 灰度图像转二值图像（区分赛道和背景）
 * @param src_gray 输入灰度图像指针（原始摄像头数据，灰度值0~255）
 * @param dst_binary 输出二值图像指针（存储到binary_image数组）
 * @param width 图像宽度（GRAY_IMAGE_WIDTH）
 * @param height 图像高度（GRAY_IMAGE_HEIGHT）
 * @return 无
 * @note 核心逻辑：灰度值>FIXED_BINARY_THRESHOLD为255（白/赛道），否则为0（黑/背景）；
 *       二值化是视觉循迹的基础，减少后续计算量
 */
void gray_image_binaryzation(const uint8 *src_gray, uint8 *dst_binary, uint16 width, uint16 height);

/**
 * @brief 大津法自适应阈值计算
 * @param image 输入灰度图像指针
 * @param width 图像宽度
 * @param height 图像高度
 * @return 最优二值化阈值
 */
uint8 OtsuThreshold(const uint8 *image, uint16 width, uint16 height);

/**
 * @brief 自适应二值化（基于大津法）
 * @param src_gray 输入灰度图像指针
 * @param dst_binary 输出二值图像指针
 * @param width 图像宽度
 * @param height 图像高度
 * @param bias 阈值偏置
 */
void adaptive_binaryzation(const uint8 *src_gray, uint8 *dst_binary, 
                           uint16 width, uint16 height, int8 bias);

// 局部自适应二值化函数声明
void local_mean_binary(const uint8 *src_gray, uint8 *dst_binary, 
                      uint16 width, uint16 height, uint8 block_size, int8 C);                       

/**
 * @fn find_mid_line
 * @brief 【巡线方法1：三级扫描通用版】
 *        核心巡边函数：底部行三级查找边界，上方行中线继承巡边（优化版）
 * @param img 输入二值化图像指针（binary_image数组）
 * @return 无
 * @note 1. 底部行仅扫描中心、1/4、3/4位置，未找到边界则设为0/159；
 *       2. 上方行基于下一行中线小范围扫描，未找到边界则设为0/159；
 *       3. 包含左边界>右边界防护、相邻中线差值限制逻辑；
 *       4. 优化点：仅处理到search_cutoff_row，减少无效计算
 */
void find_mid_line(const uint8 *img);

/**
 * @fn find_mid_line_
 * @brief 【巡线方法2：最长白列核心版】
 *        核心巡边函数（仅从底行到巡边截止行巡线）
 *        核心增强：1. 最长白列失效时强制中心中线 2. 仅处理[截止行, 底行]范围
 * @param img 输入二值化图像指针（binary_image数组）
 * @return 无
 */
void find_mid_line_white(const uint8 *img);

/**
 * @fn find_mid_line_step
 * @brief 【巡线方法3：阶梯巡线法】
 *        核心特性：阶梯式继承边界 + 跳行功能 + 搜索失败全范围重扫，极致防丢线
 * @param img 输入二值化图像指针（binary_image数组）
 * @return 无
 * @note 核心规则：
 * 1. 最长白列失效→强制中心中线
 * 2. 仅处理[截止行, 底行]，从下向上巡线
 * 3. 底部行：最长白列定位，找白→黑跳变边界
 * 4. 上方行：阶梯继承下行边界，搜索失败则全范围重扫
 * 5. 支持跳行功能，跳过指定行数直接继承边界坐标
 */
void find_mid_line_step(const uint8 *img);


/**
 * @fn vision_track_main
 * @brief 视觉循迹主函数（对外核心接口）
 * @param gray_image 输入原始灰度图像指针（摄像头采集数据）
 * @return 无
 * @note 调用流程：灰度转二值 → 检测最长白列 → 核心巡边 → 计算曲率半径；
 *       小车主循环中需周期性调用该函数（建议频率≥30Hz）
 */
void vision_track_main(const uint8_t* gray_image);

/**
 * @fn find_longest_white_column
 * @brief 查找二值图像中最长的白色列（连续白色像素）
 * @param img 输入二值化图像指针（binary_image数组）
 * @return 无（结果存入max_white_col_length和search_cutoff_row）
 * @note 1. 遍历所有列，从底部向上统计每列连续白色像素长度；
 *       2. 结果用于确定巡边有效区域，减少无效计算；
 *       3. 增加边界防护，避免极端情况导致程序异常
 */
void find_longest_white_column(const uint8 *img);

/**
 * @fn fit_midline_slope_angle
 * @brief 最小二乘法拟合底行到截止行的中线，计算斜率和角度
 * @param fit_ratio 拟合行比例（0.0~1.0，1=全部有效行，0.5=一半有效行）
 * @param slope 输出：拟合中线的斜率（Δy/Δx，适配y=行号、x=列号坐标系）
 * @param angle_deg 输出：拟合中线的角度（度，x轴正方向为0°，向下为正）
 * @return 是否拟合成功（true=成功，false=失败/有效行不足）
 * @note 1. 有效行范围：search_cutoff_row → bottom_row；
 *       2. 斜率定义：k = Δy/Δx（y=行号向下为正，x=列号向右为正）；
 *       3. 角度范围：-90°~90°，正数=向右下倾斜，负数=向左下倾斜；
 */
bool fit_midline_slope_angle(float fit_ratio, float *slope, float *angle_deg);

/**
 * @fn calc_two_lookahead_avg_angle
 * @brief 双前瞻行正切平均角度计算（基于原点(80,119)的几何夹角）
 * @details 以图像底部中心(80,119)为基准原点，分别计算最近、最远前瞻行的中线点与原点连线的夹角；
 *          核心正切公式：tanα = 对边/邻边 = (x-80)/(119-y)，最终取两点角度的算术平均值
 * @return float 平均夹角（单位：度），右偏为正，左偏为负，范围-90°~+90°
 * @note 1. 自动约束前瞻行不低于搜索截止行，避免取到无效赛道区域的中线；
 *       2. 内置除零防护，兼容前瞻行与原点重合的极端场景；
 *       3. 输出直接赋值给fit_angle全局变量，完全兼容后续动态前瞻、转向控制逻辑。
 */
float calc_two_lookahead_avg_angle(void);


// 动态前瞻循线偏差计算函数声明
float calculate_lookahead_deviation(float fit_angle);

/**
 * @brief  纯跟踪算法主接口：计算前轮转向角，输出循线偏差
 * @details 替代原最小二乘拟合+动态前瞻方案，直接基于预瞄行中线计算纯跟踪转角；
 *          支持目标绕行模式，兼容搜索截止行边界保护，双行平均输出。
 * @param  out_dev_px  输出指针：近前瞻行的横向像素偏差（右偏为正，兼容原line_deviation）
 * @return float       最终前轮偏转角（角度制，单位°，正=右转，负=左转）
 * @note   边界规则：
 *         - 最近/最远前瞻行 < 搜索截止行 → 强制等于搜索截止行
 *         目标绕行规则：
 *         - 强制使用最近前瞻行，按目标类别选择左/右边界/中线
 *         - 偏差超过限制时自动限幅
 */
float pure_pursuit_calc_steer(float *out_dev_px);

// 8邻域形态学滤波函数声明
void image_filter(const uint8 *src, uint8 *dst, uint16 width, uint16 height);

// 十字道检测+补线函数声明（需自行实现）
void cross_track_main(void);

// 调试绘制函数
void draw_track_lines(void);

/**
 * @brief 批量计算赛道每行中线（从图像底部向上遍历）
 * @details 仅执行基础中线计算，纯数学运算：中线 = (左边界 + 右边界) / 2
 *          遍历范围：图像底行 bottom_row → 巡线有效截止行 search_cutoff_row
 */
void calc_midline(void);

// ===================== 斑马线检测配置（核心参数） =====================
#define ZEBRA_Y_START        60      // Y轴扫描起始行
#define ZEBRA_Y_END          100      // Y轴扫描终止行
#define ZEBRA_X_START        45      // X轴扫描起始列
#define ZEBRA_X_END          115     // X轴扫描终止列

#define ZEBRA_CONTINUE_PIX   3       // 连续像素判定有效块（白/黑）
#define ZEBRA_MAX_INVALID    8      // 最大连续无效像素，超过则退出

#define ZEBRA_ALTERNATE_NUM  4       // 黑白交替次数（达标判定斑马线）
#define ZEBRA_SKIP_Y_ROW     4       // Y轴跳行数（减少计算量）

// ===================== 斑马线检测全局变量 =====================
extern bool is_zebra_detected;       // 斑马线检测标记：true=检测到

// ===================== 斑马线检测函数声明 =====================
/**
 * @fn detect_zebra_cross
 * @brief 斑马线检测（横向黑白交替条纹）
 * @param img 二值化图像指针
 * @return 无
 * @note 严格按照需求：指定区域扫描 + 连续像素判定 + 交替次数验证
 */
void detect_zebra_cross(const uint8 *img);

// ===================== 斑马线定时退出配置 =====================
#define NO_DETECT_DISTANCE_M     40.0f   // 【核心】先跑 米才开始检测斑马线

#define WAIT_EXIT_TIME_S        1       // 检测到斑马线后1秒退出

// ===================== 斑马线定时退出全局变量 =====================
extern bool zebra_exit_enable;
extern bool zebra_detected_wait;
extern uint32_t zebra_start_tick;

void zebra_timer_check(void);          // 斑马线定时检测+退出封装函数




#endif 

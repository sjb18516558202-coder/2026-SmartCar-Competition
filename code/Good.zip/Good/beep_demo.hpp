#ifndef BEEP_DEMO_HPP
#define BEEP_DEMO_HPP

#include "zf_common_headfile.hpp"

// 蜂鸣器设备路径宏定义，与设备树节点匹配
#define BEEP_PATH        ZF_GPIO_BEEP

// 蜂鸣器驱动对象声明
extern zf_driver_gpio beep;

/**
 * @brief 蜂鸣器单次鸣叫函数
 * @param on_ms 鸣叫持续时间(ms)
 */
void beep_single_ring(uint32 on_ms);


#endif
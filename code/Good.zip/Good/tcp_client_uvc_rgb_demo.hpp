#ifndef TCP_CLIENT_UVC_RGB_DEMO_HPP
#define TCP_CLIENT_UVC_RGB_DEMO_HPP

// 逐飞底层通用驱动头文件，包含数据类型、电机、延时、串口等基础驱动
#include "zf_common_headfile.hpp"

// OpenCV图像处理库，用于RGB565转BGR、缩放、灰度转换
#include <opencv2/opencv.hpp>
// NCNN推理库核心头文件，用于本地模型前向推理
#include <net.h>
// 项目自定义图像结构体头文件
#include "Image.hpp"

// OpenCV命名空间，简化Mat、Vec3b等类型书写
using namespace cv;

// ====================== TCP网络通信配置宏 ======================
// 上位机逐飞助手电脑局域网IP，必须和电脑网卡IP一致
#define SERVER_IP "192.168.3.23"
// TCP通信端口号，下位机与逐飞助手端口必须完全匹配
#define PORT 8086

// TCP图像上传间隔：每 N 帧发送一次图像
#define SEND_IMAGE_FRAME_INTERVAL    3

// ====================== 压缩后灰度图像尺寸（巡线算法使用） ======================
// 灰度图宽度，原图320压缩至160，降低巡线算力消耗
#define GRAY_IMAGE_WIDTH          160
// 灰度图高度，原图240压缩至120
#define GRAY_IMAGE_HEIGHT         120

// ====================== 红色目标搜索区域宏（整张画面搜索范围） ======================
// 红色搜索起始Y行，0=画面最顶部
#define SEARCH_RED_TOP_Y           45//(UVC_HEIGHT * 1 / 4)     // 240/4=60
// 红色搜索截止Y行，240=画面最底部，整张图检索红色标记
#define SEARCH_RED_BOTTOM_Y        (UVC_HEIGHT * 70 / 100)  // 168
// 红色搜索左边界X：画面宽度1/5位置
#define SEARCH_RED_START_X         80//(UVC_WIDTH * 1 / 5)
// 红色搜索右边界X：画面宽度4/5位置，仅中间区域识别红色
#define SEARCH_RED_END_X           240//(UVC_WIDTH * 4 / 5)

// ====================== 模型有效推理区域（仅该区间内红色才触发NCNN识别） ======================
// 推理区域上边界Y，画面高度47.5%
#define MODEL_INFER_TOP_Y          155  //165     //130  //43cm
// 推理区域下边界Y，画面高度63%，超出该区间不执行推理节省算力
#define MODEL_INFER_BOTTOM_Y       220         //200  //13cm            

// ====================== 红色目标裁剪框尺寸（与模型输入尺寸严格一致） ======================
#define CROP_IMAGE_WIDTH          64
#define CROP_IMAGE_HEIGHT         64

// ====================== 逐飞助手边界绘图配置 ======================
// 边界类型选择：0=仅图像无边界；1=X轴单排边界；2=Y轴单列边界；3=XY完整坐标；4=仅边界不发图
#define INCLUDE_BOUNDARY_TYPE   0
// 边界坐标数组最大存储长度
#define BOUNDARY_NUM            (UVC_HEIGHT * 4 / 2)

// ====================== NCNN深度学习模型相关配置 ======================
// 模型输入图像宽度，训练数据集固定尺寸
#define NCNN_INPUT_WIDTH          64
// 模型输入图像高度
#define NCNN_INPUT_HEIGHT         64

// 模型输出分类总数：3大类（物资/载具/武器）
#define MODEL_OUTPUT_CLASS_NUM    3

// 置信度阈值，预测分数≥0.90才判定为有效识别，计入投票统计
#define TARGET_CONF_THRESH        0.5f //0.45f

// 识别起始阈值：目标离开识别区时，有效帧≥3帧才判定为有效识别完成；低于则视为误触
#define VOTE_START_THRESHOLD      3
// 识别结束阈值：累计有效帧达到6帧，强制停止推理，直接判定识别完成，节省算力
#define VOTE_END_THRESHOLD        5  


// ====================== 日志打印控制宏 ======================
// 推理日志打印间隔，1=每一帧都打印
#define LOG_PRINT_FREQUENCY       1
// 第一帧预处理调试日志总开关
#define ENABLE_FIRST_FRAME_DEBUG  true

// ====================== 整机工作模式宏 ======================
// 模式1：关闭目标识别，仅巡线
#define MODE_NO_RECOGNIZE  1
// 模式2：开启红色目标检测+NCNN分类识别
#define MODE_ENABLE_RECOG  2


// ====================== 红色HSV识别阈值宏 ======================
// 色相H：红色两段区间 0~10橙红 / 155~180紫红
#define H_LOW1         0
#define H_HIGH1        5
#define H_LOW2         155
#define H_HIGH2        180
// 全局饱和度、明度下限
#define S_LOW          20
#define V_LOW          40

// ====================== 基座轮廓筛选阈值宏 ======================
#define MIN_AREA        70            // 最小有效轮廓面积（噪点过滤）
#define FALLBACK_AREA   120           // 兜底识别最低面积
#define WH_RATIO_THRESH 1.6f          // 长条基座最小宽高比
#define STICK_SCALE     1.3f          // 粘连判定高度倍数
#define BASE_W_SCALE    (1.0f / 3.5f) // 基座标准宽高比3.5:1    高:1  宽:3.5
#define CONTOUR_MIN_AREA 30           // 遍历轮廓最小过滤面积

// ====================== 目标自适应缩放参数 ======================
#define MIN_BASE_W      15.0f     // 基座宽度下限(远距离)
#define MAX_BASE_W      50.0f     // 基座宽度上限(近距离)
#define FAR_PAD         1.1f      // 远距离框放大系数
#define NEAR_PAD        0.9f      // 近距离框缩小系数
#define UP_OFFSET_PX    1.0f      // 基座向上偏移像素


// ====================== 红砖判定阈值 ======================
// 赛道角度阈值：低于此值视为直道，允许进行红砖判定
#define RED_BRICK_ANGLE_THRESH         20.0f

// 远距离截止行：红色中心行 < 80 时判定红砖
#define RED_BRICK_FAR_ROW_END           83
// 远距离红砖面积阈值：红色像素数超过此值才判定为红砖（防止远距离零星红色误触发）
#define RED_BRICK_FAR_AREA_THRESH       200

// 中距离起始行（与远距离衔接）
#define RED_BRICK_MID_ROW_START         83
// 中距离结束行：80~110 之间仅靠面积判定
#define RED_BRICK_MID_ROW_END           115

// 红色像素面积阈值
#define RED_BRICK_AREA_THRESH          300

// 红砖判定行区间（原图 320×240 坐标系）
#define RED_BRICK_JUDGE_ROW_START      115
#define RED_BRICK_JUDGE_ROW_END        140


// 中线距离突变阈值（灰度图坐标系，单位：像素）
#define RED_BRICK_DIST_THRESH          6
// 边界扫描区间放大行数（自红色中心向下延伸）
#define RED_BRICK_SCAN_HALF_H          10
// 突变前稳定段：相邻行边界变化 ≤ 此值
#define RED_BRICK_STABLE_BEFORE_THRESH 2
// 稳定段最少持续行数
#define RED_BRICK_STABLE_MIN_LEN       3
// 突变段：相邻行边界变化 > 此值
#define RED_BRICK_JUMP_THRESH          3
// 突变段最大允许行数（超过则视为非红砖特征）
#define RED_BRICK_JUMP_MAX_LEN         5
// 突变后砖块稳定段：相邻行边界变化 ≤ 此值
#define RED_BRICK_STABLE_AFTER_THRESH  1
// 砖块稳定段最少持续行数
#define RED_BRICK_STABLE_AFTER_MIN_LEN 3

// 另一边界全程稳定阈值（相邻行差必须 ≤ 此值）
#define RED_BRICK_OTHER_STABLE_THRESH  2

// 红砖避障行驶距离阈值（单位：厘米），小车驶过该距离后重新开启识别
#define RED_BRICK_AVOID_DIST_CM   150.0f


// ====================== 图像单帧耗时统计结构体 ======================
typedef struct {
    uint32_t capture_us;    // 摄像头图像采集耗时(微秒)
    uint32_t process_us;    // 红色检测、裁剪、推理处理耗时(微秒)
    uint32_t send_us;       // TCP图像上传耗时(微秒)
    uint32_t total_us;      // 单帧完整循环总耗时(微秒)
} ImageTimeStat;

// ====================== 外部全局变量声明（跨文件可访问） ======================
// 硬件设备对象
extern zf_driver_tcp_client tcp_client_dev; // TCP客户端设备，负责网络收发
extern zf_device_uvc uvc_dev;               // UVC免驱摄像头设备
extern uint16* rgb_image;                   // 摄像头原始RGB565图像指针

// 逐飞助手边界坐标存储数组
extern uint8 xy_x1_boundary[BOUNDARY_NUM], xy_x2_boundary[BOUNDARY_NUM], xy_x3_boundary[BOUNDARY_NUM];
extern uint8 xy_y1_boundary[BOUNDARY_NUM], xy_y2_boundary[BOUNDARY_NUM], xy_y3_boundary[BOUNDARY_NUM];
extern uint8 x1_boundary[UVC_HEIGHT], x2_boundary[UVC_HEIGHT], x3_boundary[UVC_HEIGHT];
extern uint8 y1_boundary[UVC_WIDTH], y2_boundary[UVC_WIDTH], y3_boundary[UVC_WIDTH];

// 图像缓存缓冲区
extern uint16 image_copy[UVC_HEIGHT][UVC_WIDTH];        // 字节交换后的彩色RGB565图像，用于上位机显示
extern uint8  gray_image[GRAY_IMAGE_HEIGHT][GRAY_IMAGE_WIDTH]; // 压缩灰度图，巡线算法输入
extern uint8  binary_image[GRAY_IMAGE_HEIGHT][GRAY_IMAGE_WIDTH]; // 灰度二值图，可选上传上位机
extern uint16 crop_color_image[CROP_IMAGE_HEIGHT][CROP_IMAGE_WIDTH]; // 红色目标裁剪RGB565图，NCNN输入原图

// 图像上传模式：0彩色/1灰度/2二值/3不发送图像
extern uint8 send_image_mode;

// 红色目标检测相关全局变量
extern bool red_detected_flag;  // 全局红色检测标志，true画面存在红色标记
extern int first_red_start_y;   // 分阶段搜索首次检测到红色的行坐标
extern uint8 search_stage;      // 红色搜索阶段：0初始搜索/1扩展搜索
extern bool last_red_detected;  // 上一帧红色检测状态，用于触发新一轮识别



// ====================== 红色基座查找结果全局变量 ======================
extern cv::Point2f g_base_TL;   // 基座顶边左端点（原图坐标系）
extern cv::Point2f g_base_TR;   // 基座顶边右端点（原图坐标系）
extern bool g_base_found;       // 基座查找成功标志

// ====================== 基座查找与矫正裁剪函数声明 ======================
// 红色基座查找：HSV阈值+轮廓筛选+粘连分离，输出基座顶边左右基准点
// 新增 out_red_count：返回红色掩码中非零像素总数，用于更新全局红色像素计数
// src_rgb565: 输入RGB565原图指针
// img_w/img_h: 原图宽高像素
// roi_x_start/roi_x_end: 水平搜索ROI范围
// roi_y_start/roi_y_end: 垂直搜索ROI范围
// out_base_TL/out_base_TR: 输出基座顶边端点（原图坐标）
// out_red_count: 输出红色像素总数（掩码非零像素计数），可为nullptr表示不需要该值
// 返回值: true=找到有效基座
bool find_red_base(const uint16_t* src_rgb565, int img_w, int img_h,
                   int roi_x_start, int roi_x_end,
                   int roi_y_start, int roi_y_end,
                   cv::Point2f& out_base_TL, cv::Point2f& out_base_TR,
                   int* out_red_count = nullptr);


// 目标矫正裁剪：基于基座顶边向量做仿射变换，输出转正的正方形目标图
// src: 输入BGR格式原图
// output_size: 输出正方形边长
// base_TL/base_TR: 基座顶边基准点
// 其余输出参数兼容原接口，可用于上位机绘图
cv::Mat crop_target_from_base(const cv::Mat& src, int output_size,
                              cv::Point2f base_TL, cv::Point2f base_TR,
                              int &out_x1, int &out_y1, int &out_x2, int &out_y2,
                              cv::Point2f out_corners[4]);

// BGR转RGB565工具函数：衔接OpenCV Mat与项目通用RGB565数组
void mat_bgr_to_rgb565(const cv::Mat& src_bgr, uint16_t* dst_rgb565);



// NCNN目标分类投票识别变量
extern int target_infer_cnt;            // 当前目标累计推理总帧数
extern bool target_infer_done;          // 识别完成标志，true停止推理，启动绕行
extern int target_vote[MODEL_OUTPUT_CLASS_NUM]; // 每类目标有效识别票数统计
extern int target_final_class;          // 最终投票胜出类别下标

// 识别过程速度、距离统计变量
extern float infer_frame_speed;         // 单帧瞬时平均车速 cm/s
extern float infer_frame_distance;      // 单帧行驶距离 cm
extern float infer_total_distance;      // 识别阶段累计总行驶距离 cm
extern float infer_total_speed;         // 识别全程平均车速 cm/s

// 目标绕行控制全局变量
extern uint8 avoid_obstacle_mode;       // 绕行模式：0物资右绕/1载具直行/2武器左绕
extern bool is_avoid_finish;            // 绕行完成标志，true允许重新识别新目标
extern bool target_avoid_running;       // 绕行执行开关，识别完成置true
extern float target_avoid_distance;     // 绕行已行驶距离累计
extern int target_avoid_class;          // 需要绕行的目标类别

// 帧调试日志变量
extern int frame_count;                 // 全局帧计数器
extern bool first_frame_logged;         // 第一帧调试日志打印标记

// NCNN推理全局对象
extern ncnn::Net g_ncnn_net;            // NCNN推理网络实例
extern bool g_ncnn_init_done;           // NCNN模型加载完成标记
extern bool ncnn_initialized;           // NCNN可用状态标志
extern uint8_t* g_rgb888_buffer;        // RGB888格式输入缓冲区，NCNN要求输入格式
extern const float mean_vals[3];        // ImageNet数据集均值归一化参数
extern const float norm_vals[3];        // ImageNet标准差归一化参数

// 分类标签字符串数组，与训练数据集顺序严格对应
extern const char* class_labels[];



extern bool red_brick_detected;   // 红砖状态标志，true=当前画面检测到红砖
extern bool red_brick_active;               // 是否处于避障红砖状态（true=避障中，禁止识别）
extern float red_brick_start_distance;      // 进入红砖状态时的累计行驶距离（cm）



// 单帧耗时统计结构体全局实例
extern ImageTimeStat image_time_stat;
// 程序启动后主循环累计总运行微秒数
extern uint64_t g_total_elapsed_us;

// 整机工作模式选择
extern uint8 work_mode;

// ====================== 全局函数声明 ======================
// 图像发送模式切换接口
void switch_to_send_color(void);
void switch_to_send_gray(void);
void switch_to_send_binary(void);
void switch_to_send_none(void);

// TCP数据收发封装函数，适配逐飞助手函数指针接口
uint32 tcp_send_wrap(const uint8 *buf, uint32 len);
uint32 tcp_read_wrap(uint8 *buf, uint32 len);

// RGB565原图缩放+灰度转换函数，默认参数为项目标准尺寸
void resize_and_gray_convert(uint16* src_rgb565, uint8* gray_image,
                              int src_width = UVC_WIDTH, int src_height = UVC_HEIGHT,
                              int dst_width = GRAY_IMAGE_WIDTH, int dst_height = GRAY_IMAGE_HEIGHT);

// 红色目标像素检索，输出红色区域中心坐标cx/cy
void find_red_object_center(uint16* img, int w, int h, int* cx, int* cy);

// 以(cx,cy)为中心裁剪RGB565彩色图像，输出裁剪图
void crop_color_rgb565(uint16* src, uint16* dst, int cx, int cy, int crop_w, int crop_h);

// 在RGB565图像上绘制矩形框，用于上位机可视化标记目标
void draw_rect_rgb565(uint16* img, int w, int h, int x, int y, int bw, int bh, uint16_t color);

// 高精度系统时间戳
uint32_t get_system_time_us(void);
uint32_t get_system_time_ms(void);

// 重置图像耗时统计所有参数清零
void reset_image_time_stat(void);

// NCNN模型初始化入口，加载param与bin权重文件
int chibei_Init(void);

// NCNN纯推理函数，输入RGB888图像，输出各类别置信度数组
int run_ncnn_inference_pure(uint8_t* rgb888_buffer, int w, int h, float* output_probs);
// RGB565裁剪图转NCNN所需RGB888格式
void rgb565_to_rgb888_for_ncnn(uint16_t src[CROP_IMAGE_HEIGHT][CROP_IMAGE_WIDTH], uint8_t* dst);

// 完整推理主逻辑：包含帧统计、投票、置信度过滤
void run_model_inference(void);

// 项目主业务函数：TCP通信+UVC采集+红色识别+NCNN推理+巡线+图像上传
void tcp_client_uvc_rgb_demo(void);

// ===================== 历史识别轮次记录 =====================
#define MAX_ROUND_HISTORY  20   // 最大存储轮数，根据需求调整
extern int round_history[MAX_ROUND_HISTORY];   // 存储每轮最终类别 (0=物资,1=载具,2=武器)
extern int round_history_count;                // 已完成的轮数

/** 推理完成后自动停车的轮数（设为 0 关闭功能） */
#define STOP_AFTER_INFERENCE_ROUNDS  3


#endif
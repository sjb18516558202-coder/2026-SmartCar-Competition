#include "PID.hpp"

// 电机PID初始化参数
// 格式：PID_Create(比例系数Kp, 积分系数Ki, 微分系数Kd, 低通滤波系数LowPass)
// PID motor_L_pid = PID_Create(1.60f,0.000026f,0.0037f,0.8f); 
// PID motor_R_pid = PID_Create(1.61f,0.000029f,0.0038f,0.8f);

PID motor_L_pid = PID_Create(1.63f,0.000026f,0.00375f,0.8f); 
PID motor_R_pid = PID_Create(1.65f,0.000030f,0.00375f,0.8f);

// 转向环
PID steer_pid  = PID_Create(1.0f,0.00f,0.0f,0.8f); 
// 增量式PID控制函数
// 核心公式：Δu(k) = Kp*[e(k)−e(k−1)] + Ki*T*e(k) + Kd/T*[e(k)−2e(k−1)+e(k−2)]
float PID_Increase (PID *pid, float NowData, float Point)
{  
    // 保护：空指针判断，防止程序崩溃
    if (pid == NULL) 
    {
        return 0.0f;
    }

    // 1. 反馈值一阶低通滤波（源头降噪，平滑编码器噪声）
    NowData = NowData * pid->LowPass + pid->LastRawData * (1 - pid->LowPass);
    pid->LastRawData = NowData; // 更新滤波缓存为当前值

    // 2. 计算当前误差（目标值 - 反馈值）
    pid->Error = Point - NowData; 
  
    // 3. 增量式PID各分项计算
    // 3.1 比例项：Kp*[e(k) - e(k-1)]
    pid->Out_P = pid->Kp * (pid->Error - pid->LastError);
    
    // 3.2 积分项：Ki*T*e(k)（积分分离+限幅，防止积分饱和）
    pid->Out_I = pid->Ki * PID_SAMPLE_PERIOD * pid->Error;
    // if (fabs(pid->Error) < I_Separation) 
    // { // 误差小于阈值时启用积分
    //     pid->Out_I = pid->Ki * PID_SAMPLE_PERIOD * pid->Error;
    //     pid->Out_I = Limit_float(-I_Limit, pid->Out_I, I_Limit); // 积分项限幅
    // } 
    // else 
    // { // 误差过大时关闭积分，避免超调
    //     pid->Out_I = 0.0f;
    // }
    
    // 3.3 微分项：Kd/T*[e(k) - 2e(k-1) + e(k-2)]（微分先行+低通滤波）
    pid->Out_D = pid->Kd / PID_SAMPLE_PERIOD * (pid->Error - 2 * pid->LastError + pid->PrevError); 
    // 微分项低通滤波（修正笔误：使用上一次微分项结果）
    pid->Out_D = pid->Out_D * pid->LowPass + pid->Out_D_Last * (1 - pid->LowPass);
    pid->Out_D_Last = pid->Out_D; // 更新微分项滤波历史值

    // 4. 更新历史误差（顺序不可乱！先更新e(k-2)，再更新e(k-1)）
    pid->PrevError = pid->LastError;  // e(k-2) = e(k-1)
    pid->LastError = pid->Error;      // e(k-1) = e(k)
    pid->LastData = NowData;          // 记录滤波后的反馈值
    
    // 5. PID总输出（增量值）+ 输出限幅
    pid->Output_PID = pid->Out_P + pid->Out_I + pid->Out_D;
    //pid->Output_PID = Limit_float(-Output_Limit, pid->Output_PID, Output_Limit);
   
    return pid->Output_PID;
}

// 位置式PID控制函数
// u(k) = Kp*e(k) + Ki*∑(e(i)*T) + Kd*(e(k)−e(k−1))/T
// ∑i=0ke(i) 积分累加项 PID->Integral
float PID_Positional (PID *pid, float NowData, float Point)//反馈值(NowData)  设定值(Point)
{
    // 1. 空指针保护
    if (pid == NULL) return 0.0f;

    // 2. 反馈值低通滤波
    NowData = NowData * pid->LowPass + pid->LastRawData * (1 - pid->LowPass);
    pid->LastRawData = NowData;

    // 3. 计算当前误差
    pid->Error = Point - NowData;  
    
    // 4. 比例项 (P)
    pid->Out_P = pid->Kp * pid->Error;  
    
    // 5. 积分项 (I) - 修复点：增加采样周期 T，增加积分分离，限制累加器
    pid->Integral += pid->Error * PID_SAMPLE_PERIOD; 
    pid->Out_I = pid->Ki * pid->Integral;
    // if (fabs(pid->Error) < I_Separation)
    // {
    //     // 积分累加 = 累加 + 当前误差 * 采样周期
    //     pid->Integral += pid->Error * PID_SAMPLE_PERIOD; 
        
    //     // 【关键修复】限制累加器本身，而不是只限制输出分量
    //     // 这样可以防止积分饱和（Windup）
    //     if (pid->Integral > I_Limit) pid->Integral = I_Limit;
    //     else if (pid->Integral < -I_Limit) pid->Integral = -I_Limit;
    // }
    // else
    // {
    //     // 误差过大，清零积分
    //     pid->Integral = 0; 
    // }
    // pid->Out_I = pid->Ki * pid->Integral;
    
    // 6. 微分项 (D) - 核心修正：除以采样周期+正确滤波
    // 6.1 计算微分原始值（误差变化率）
    float diff_raw = (pid->Error - pid->LastError) / PID_SAMPLE_PERIOD;
    // 6.2 微分项低通滤波（消除编码器噪声）
    pid->Out_D = diff_raw * pid->LowPass + pid->Out_D_Last * (1 - pid->LowPass);
    // 6.3 乘以微分系数Kd
    pid->Out_D = pid->Kd * pid->Out_D;

    // 7. 更新历史数据（顺序很重要）
    pid->LastError = pid->Error; 
    pid->LastData = NowData;
    // 保存本次微分项用于下次滤波
    pid->Out_D_Last = pid->Out_D; 
    
    // 8. 总输出与限幅
    pid->Output_PID = pid->Out_P + pid->Out_I + pid->Out_D;
    //pid->Output_PID = Limit_float(-Output_Limit, pid->Output_PID, Output_Limit);
   
    return (pid->Output_PID);
}



#include "key.hpp"
#include "ESC.hpp"       // 电调控制接口
#include "beep_demo.hpp" // 蜂鸣器驱动，用于按键提示音

// ==================================================
// 按键GPIO实例定义
// 说明：O_RDWR 配置为输入模式，用于读取按键电平
//      硬件默认上拉：未按下时为高电平1，按下时为低电平0
// ==================================================
zf_driver_gpio  key_1(KEY_1_PATH, O_RDWR);
zf_driver_gpio  key_2(KEY_2_PATH, O_RDWR);
zf_driver_gpio  key_3(KEY_3_PATH, O_RDWR);
zf_driver_gpio  key_4(KEY_4_PATH, O_RDWR);

// ==================================================
// 全局功能状态变量初始化
// 说明：上电默认全部为0（关闭状态），符合安全设计原则
// ==================================================
uint8 esc_run_en = 0;   // 电调默认关闭
uint8 recog_en   = 1;     // 视觉识别默认关闭
uint8 car_run_en = 0;   // 小车启动默认关闭


bool car_wait_esc = false;   // 默认不等待电调

// 预留扩展变量：电机PWM偏移量、图像增益偏移量
int16_t pwm_offset = 0;
float pixel_gain_offset = 0.0f;

// ==================================================
// 按键缓存初始化
// 说明：KEY1默认高电平1（未按下），KEY2/3/4默认逻辑0（未选中）
// ==================================================
KeyState_t key_cache = {
    .key1_level = 1,
    .key2_level = 0,
    .key3_level = 0,
    .key4_level = 0
};

// ==================================================
// KEY1长按相关静态变量
// 说明：static 限定仅本文件可见，记录按下时刻与上一次电平
// ==================================================
#define KEY1_LONG_PRESS_THRESHOLD 500    // 长按判定阈值：500ms
static uint32_t key1_press_start_tick = 0; // KEY1按下瞬间的系统时间戳
static uint8 key1_last_raw = 1;            // KEY1上一次硬件电平，用于边沿检测

/**
 * @brief 按键硬件初始化
 * @note  GPIO构造函数已自动配置输入模式，此处为空实现，预留扩展
 */
void key_init(void)
{
    // 如需额外上拉、中断配置可在此添加
}

/**
 * @brief 全按键统一扫描函数，主循环周期调用
 * @desc  执行流程：
 *        1. 读取4路按键实时硬件电平
 *        2. 对KEY2/3/4做下降沿检测 + 20ms软件消抖，触发后翻转逻辑状态
 *        3. 对KEY1做下降沿检测，记录按下起始时间用于长短按判定
 *        4. 调用KEY1确认处理函数，完成长短按逻辑分发
 */
void key_scan_all(void)
{
    // 第一步：读取四路按键当前硬件电平
    uint8 raw1 = key_1.get_level();
    uint8 raw2 = key_2.get_level();
    uint8 raw3 = key_3.get_level();
    uint8 raw4 = key_4.get_level();

    // ==================================================
    // KEY2 边沿检测与逻辑翻转
    // 原理：下降沿触发（高电平变低电平 = 按键按下瞬间）
    //      静态变量last_raw2保存上一次扫描的电平，用于对比判断边沿
    // ==================================================
    static uint8 last_raw2 = 1; // 静态局部变量，仅初始化一次，保留历史值
    // 判定条件：上一次是高电平1，本次是低电平0 → 按键刚被按下
    if(last_raw2 == 1 && raw2 == 0)
    {
        system_delay_ms(20);           // 20ms软件消抖，滤除机械弹跳产生的杂波
        if(key_2.get_level() == 0)     // 消抖后再次读取，确认确实是按下状态
        {
            key_toggle_2();            // 触发逻辑状态翻转
        }
    }
    last_raw2 = raw2; // 更新历史电平缓存，供下一次扫描对比

    // ==================================================
    // KEY3 边沿检测与逻辑翻转（同KEY2原理）
    // ==================================================
    static uint8 last_raw3 = 1;
    if(last_raw3 == 1 && raw3 == 0)
    {
        system_delay_ms(20);
        if(key_3.get_level() == 0)
        {
            key_toggle_3();
        }
    }
    last_raw3 = raw3;

    // ==================================================
    // KEY4 边沿检测与逻辑翻转（同KEY2原理）
    // ==================================================
    static uint8 last_raw4 = 1;
    if(last_raw4 == 1 && raw4 == 0)
    {
        system_delay_ms(20);
        if(key_4.get_level() == 0)
        {
            key_toggle_4();
        }
    }
    last_raw4 = raw4;

    // ==================================================
    // KEY1 长按计时起点记录
    // ==================================================
    key_cache.key1_level = raw1; // 更新KEY1实时电平到全局缓存
    
    // 检测到KEY1按下瞬间（下降沿），记录当前系统时间作为计时起点
    if(key1_last_raw == 1 && raw1 == 0)
    {
        key1_press_start_tick = get_system_time_ms();
    }

    // 调用KEY1核心处理函数，完成长短按逻辑判断
    key_handle_confirm(raw1);
}

/**
 * @brief KEY2逻辑状态翻转
 * @desc  0和1循环切换，点按一次切换一次，同时蜂鸣提示
 */
void key_toggle_2(void)
{
    // 三元运算符实现赋值翻转：当前是0就变1，当前是1就变0
    key_cache.key2_level = (key_cache.key2_level == 0) ? 1 : 0;
    printf("KEY2状态翻转：%d\r\n", key_cache.key2_level);
    beep_single_ring(200); // 200ms短音，提示按键触发成功
}

/**
 * @brief KEY3逻辑状态翻转
 */
void key_toggle_3(void)
{
    key_cache.key3_level = (key_cache.key3_level == 1) ? 0 : 1;
    printf("KEY3状态翻转：%d\r\n", key_cache.key3_level);
    beep_single_ring(200);
}

/**
 * @brief KEY4逻辑状态翻转
 */
void key_toggle_4(void)
{
    key_cache.key4_level = (key_cache.key4_level == 1) ? 0 : 1;
    printf("KEY4状态翻转：%d\r\n", key_cache.key4_level);
    beep_single_ring(200);
}

/**
 * @brief 清空功能按键缓存
 * @note  每次短按KEY1执行完功能后自动调用，确保下一次选择从0开始
 *        避免上一次的选择状态残留导致误触发
 */
void key_clear_func_keys(void)
{
    key_cache.key2_level = 0;
    key_cache.key3_level = 0;
    key_cache.key4_level = 0;
    printf("已重置KEY2/3/4为默认0\r\n");
}

/**
 * @brief KEY1确认按键核心处理逻辑
 * @param curr_key1 当前KEY1硬件电平
 * @rule  判定规则：
 *        1. 必须在按键**抬起瞬间**才判定长短按，避免按下就误触发
 *        2. 按住时长 ≥ 500ms → 长按：清空所有功能、电调强制停机
 *        3. 按住时长 < 500ms → 短按：读取KEY2/3/4组合，切换对应功能
 */
void key_handle_confirm(uint8 curr_key1)
{
    // 检测KEY1抬起上升沿：上一次是低电平0，本次变高电平1 → 按键松开瞬间
    if(key1_last_raw == 0 && curr_key1 == 1)
    {                
        system_delay_ms(20);        // 抬起消抖，滤除松开瞬间的机械抖动
        if(key_1.get_level() != 1)  // 消抖后再次确认电平
        {
            // 消抖失败，电平不稳定，不执行任何操作，更新状态后直接退出
            key1_last_raw = curr_key1;
            return; 
        }

        // 计算本次按下的持续时长 = 当前系统时间 - 按下起始时间
        uint32_t press_dur = get_system_time_ms() - key1_press_start_tick;

        // ===================== 长按分支 =====================
        if(press_dur >= KEY1_LONG_PRESS_THRESHOLD)
        {
            // 所有功能统一赋值为0，全部关闭（纯赋值方式，无位运算）
            esc_run_en = 0;
            recog_en = 0;
            car_run_en = 0;
            car_wait_esc = false;   
            // 复位时同时清除等待标志

            key_clear_func_keys();  // 清空按键选择缓存
            ESC_Stop();             // 强制电调停机，安全复位
            beep_single_ring(1000); // 1000ms长音，提示长按复位
            printf("=== 长按KEY1：清空所有功能，恢复默认模式 ===\r\n");
            key_print_func_status();
        }
        // ===================== 短按分支 =====================
        else
        {
            // 读取当前KEY2/3/4的逻辑选择状态
            uint8 k2 = key_cache.key2_level;
            uint8 k3 = key_cache.key3_level;
            uint8 k4 = key_cache.key4_level;
            printf("短按KEY1，当前组合 KEY2=%d KEY3=%d KEY4=%d\r\n", k2, k3, k4);

            // 组合 001：电调启停切换
            if(k2 == 0 && k3 == 0 && k4 == 1)
            {
                ESC_Toggle();  // 调用电调切换接口
                // 纯赋值方式翻转状态：0变1，1变0
                esc_run_en = (esc_run_en == 0) ? 1 : 0;
                beep_single_ring(500);
                printf("=== 匹配001：电调状态切换，当前：%s ===\r\n", 
                       IS_ESC_RUNNING() ? "开启" : "关闭");
            }
            
            // 组合 010：视觉识别功能切换
            else if(k2 == 0 && k3 == 1 && k4 == 0)
            {
                // 纯赋值方式翻转状态
                recog_en = (recog_en == 0) ? 1 : 0;
                beep_single_ring(500);
                printf("=== 匹配010：识别功能切换，当前：%s ===\r\n",
                       IS_RECOG_ENABLE() ? "开启" : "关闭");
            }            
            
            // 组合 100：小车启动
            else if(k2 == 1 && k3 == 0 && k4 == 0)
            {
                // 纯赋值方式翻转状态
                car_run_en = (car_run_en == 0) ? 1 : 0;
                car_wait_esc = false;   // 强制不等待电调，直接倒计时
                beep_single_ring(500);
                printf("=== 匹配100：小车切换，当前：%s ===\r\n",
                       IS_CAR_RUNNING() ? "启动" : "停止");
            }
            
            // ---------- 组合 101：电调 + 小车联动 ----------
            else if(k2 == 1 && k3 == 0 && k4 == 1)
            {
                /* 1. 切换电调启停（该函数内部会修改状态机） */
                ESC_Toggle();
                
                /* 2. 获取切换后的电调状态，决定小车使能和等待策略 */
                ESC_StateTypeDef state = ESC_GetState();
                
                if(state == ESC_STOP)
                {
                    /* 电调停止 → 小车也停止，清除等待标志 */
                    car_run_en = 0;
                    car_wait_esc = false;
                    esc_run_en = 0;
                }
                else if(state == ESC_WAIT_DELAY || state == ESC_RAMPING)
                {
                    /* 电调正处于启动加速中（延时或步进阶段）
                    → 小车使能，但需等待电调完成加速（进入 RUNNING） */
                    car_run_en = 1;
                    car_wait_esc = true;
                    esc_run_en = 1;
                }
                else if(state == ESC_RUNNING)
                {
                    /* 电调已处于运行状态（理论上从 STOP 不会直接跳转至此，
                    但若出现，则直接使能小车，无需等待） */
                    car_run_en = 1;
                    car_wait_esc = false;
                    esc_run_en = 1;
                }
                
                beep_single_ring(500);
                printf("=== 匹配101：电调+小车联动，电调状态：%s，小车使能：%s ===\r\n",
                    (state != ESC_STOP) ? "启动中/运行" : "停止",
                    car_run_en ? "开启" : "关闭");
            }

            // 组合 000：无功能选择，仅提示确认
            else if(k2 == 0 && k3 == 0 && k4 == 0)
            {
                beep_single_ring(500);
                printf("=== 匹配000：无功能变更，保持当前状态 ===\r\n");
            }

            // 其他未定义组合，不执行任何操作
            else
            {
                beep_single_ring(500);
                printf("未定义按键组合，不执行操作\r\n");
            }
            
            key_clear_func_keys(); // 执行完毕清空选择缓存，复位到初始状态
        }
    }
    
    // 更新KEY1历史电平，供下一次边沿检测使用
    key1_last_raw = curr_key1;
}

/**
 * @brief 调试打印：所有按键实时电平与逻辑缓存
 */
void key_print_state(void)
{
    printf("KEY1 raw = %d | KEY2 cache = %d | KEY3 cache = %d | KEY4 cache = %d\r\n",
           key_cache.key1_level,
           key_cache.key2_level,
           key_cache.key3_level,
           key_cache.key4_level);
    system_delay_ms(100);
}

/**
 * @brief 调试打印：当前所有功能的开启状态
 */
void key_print_func_status(void)
{
    printf("当前功能状态：");
    if(IS_ESC_RUNNING())
        printf("【电调运行】 ");
    if(IS_RECOG_ENABLE())
        printf("【识别推理开启】 ");
    if(IS_CAR_RUNNING())
        printf("【小车循迹运行】 ");
    
    // 全部关闭时显示无功能
    if(!IS_ESC_RUNNING() && !IS_RECOG_ENABLE() && !IS_CAR_RUNNING())
        printf("【无功能开启】");
    
    printf("\r\n");
}
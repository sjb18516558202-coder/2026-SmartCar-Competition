#include "Motor.hpp"

//电机
//1 左 L
//2 右 R

//电机速度
int16 Left_Speed = 1500;
int16 Right_Speed = 1500;

// 实例化PWM类对象
zf_driver_pwm motor_L_pwm_obj(MOTOR_L_PWM); // Object（对象）
zf_driver_pwm motor_R_pwm_obj(MOTOR_R_PWM);

// 实例化GPIO类对象
zf_driver_gpio motor_L_gpio_obj(MOTOR_L_DIR);
zf_driver_gpio motor_R_gpio_obj(MOTOR_R_DIR);

// PWM数据结构体
struct pwm_info motor_R_pwm_info;
struct pwm_info motor_L_pwm_info;

//电机初始化
void Motor_Init(void)
{
    // 调用PWM类方法读取设备信息
    motor_R_pwm_obj.get_dev_info(&motor_R_pwm_info);
    motor_L_pwm_obj.get_dev_info(&motor_L_pwm_info);
}

// 右 R
void Motor_R_SetSpeed(int pwm)   
{
    // 将无符号的duty_max转为有符号int，避免符号不匹配
    const int max_duty = static_cast<int>(motor_R_pwm_info.duty_max);// motor_R_pwm_info.duty_max=10000
    
    // 限制PWM范围
    if (pwm > max_duty) 
    {
        pwm = max_duty;
    }
    else if (pwm < -max_duty) 
    {
        pwm = -max_duty;
    }
    
    if(pwm>=0)
    {
        // 调用GPIO类set_level设置方向（1=正转）
        motor_R_gpio_obj.set_level(1);
        // 调用PWM类设置占空比（转换为uint16，匹配方法参数）
        motor_R_pwm_obj.set_duty(static_cast<uint16>(pwm));
    }
    else
    {
        // 0=反转
        motor_R_gpio_obj.set_level(0);
        // 占空比为无符号数，取绝对值后设置
        motor_R_pwm_obj.set_duty(static_cast<uint16>(-pwm));
    }
}
// 左 L
void Motor_L_SetSpeed(int pwm)  
{
    // 将无符号的duty_max转为有符号int，避免符号不匹配
    const int max_duty = static_cast<int>(motor_L_pwm_info.duty_max);
    
    // 限制PWM范围
    if (pwm > max_duty) 
    {
        pwm = max_duty;
    }
    else if (pwm < -max_duty) 
    {
        pwm = -max_duty;
    }
    
    if(pwm>=0)
    {
        motor_L_gpio_obj.set_level(1);
        motor_L_pwm_obj.set_duty(static_cast<uint16>(pwm));
    }
    else
    {
        motor_L_gpio_obj.set_level(0);
        motor_L_pwm_obj.set_duty(static_cast<uint16>(-pwm));
    }
}

// 停止所有电机
void Motor_StopAll(void) 
{ 
      // PWM占空比设为0，停止输出
    motor_L_pwm_obj.set_duty(0);
    motor_R_pwm_obj.set_duty(0);
    
    // GPIO方向电平复位为低电平
    motor_L_gpio_obj.set_level(0);
    motor_R_gpio_obj.set_level(0);
}


// ===================== 读取GPIO电平 =====================
// 读取左电机方向GPIO当前电平
uint8 Motor_GetLeftGpioLevel(void)
{
    return motor_L_gpio_obj.get_level();
}

// 读取右电机方向GPIO当前电平
uint8 Motor_GetRightGpioLevel(void)
{
    return motor_R_gpio_obj.get_level();
}

// ===================== 读取PWM设备信息 =====================
// 读取左电机PWM信息
void Motor_GetLeftPwmInfo(struct pwm_info *info)
{
    if(info != NULL)
    {
        motor_L_pwm_obj.get_dev_info(info);
    }
}

// 读取右电机PWM信息
void Motor_GetRightPwmInfo(struct pwm_info *info)
{
    if(info != NULL)
    {
        motor_R_pwm_obj.get_dev_info(info);
    }
}

// ===================== 调试打印电机状态 =====================
void Motor_DebugStatus(void)
{
    // 读取GPIO电平
    uint8 left_gpio = Motor_GetLeftGpioLevel();
    uint8 right_gpio = Motor_GetRightGpioLevel();

    // 读取PWM信息
    struct pwm_info left_pwm, right_pwm;
    Motor_GetLeftPwmInfo(&left_pwm);
    Motor_GetRightPwmInfo(&right_pwm);

    // 打印格式化调试信息
    printf("\n==================== 电机状态 ====================\n");
    printf("左电机 GPIO 方向电平 : %d   (%s)\n", left_gpio, left_gpio ? "正转" : "反转");
    printf("右电机 GPIO 方向电平 : %d   (%s)\n", right_gpio, right_gpio ? "正转" : "反转");
    printf("--------------------------------------------------\n");
    printf("左 PWM 频率    : %d Hz\n", left_pwm.freq);
    printf("左 PWM 占空比  : %d\n", left_pwm.duty);
    printf("左 PWM 最大值  : %d\n", left_pwm.duty_max);
    printf("--------------------------------------------------\n");
    printf("右 PWM 频率    : %d Hz\n", right_pwm.freq);
    printf("右 PWM 占空比  : %d\n", right_pwm.duty);
    printf("右 PWM 最大值  : %d\n", right_pwm.duty_max);
    printf("==================================================\n\n");
}


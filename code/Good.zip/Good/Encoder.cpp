#include "Encoder.hpp"

// ===================== 全局对象实例化 =====================
// 编码器驱动对象实例化（绑定设备路径，与上方宏定义对应）
zf_driver_encoder encoder_L_obj(ENCODER_L);  // 左编码器硬件驱动实例
zf_driver_encoder encoder_R_obj(ENCODER_R);  // 右编码器硬件驱动实例

// 电机编码器数据初始化：所有参数默认清零（初始状态无运动）
Motor_Encoder motor_LE = {0, 0, 0, 0.0f, 0, 0.0f, 0.0f, 0.0f};
Motor_Encoder motor_RE = {0, 0, 0, 0.0f, 0, 0.0f, 0.0f, 0.0f};

// 绕行已行驶距离
float target_avoid_distance = 0.0f;

// 预定义采样周期倒数（常量，全局只算一次，全程复用）
const float inv_sample_period = 1.0f / SAMPLE_PERIOD_S;
const float pulse_cm_coeff = PULSE_TO_CM;

// ===================== 函数实现 =====================
/**
 * @brief 编码器初始化函数
 * @note 1. 清零编码器硬件计数寄存器，避免首次采样出现异常增量
 *       2. 重置所有累计数据（里程/时间/平均速度），保证初始状态干净
 * @param 无
 * @retval 无
 */
void Encoder_Init(void)
{
    // 清零硬件计数寄存器（消除上电后可能的残留计数值）
    encoder_L_obj.clear_count();
    encoder_R_obj.clear_count();
    // 重置累计数据（里程、时间、平均速度等归0）
    Encoder_ResetTotalData();
}

/**
 * @brief 编码器数据更新函数（核心）
 * @note 1. 需在采样周期内调用（如10ms调用一次），保证数据实时性
 *       2. 核心流程：读取脉冲增量 → 计算实时速度 → 累加累计数据 → 计算平均速度
 * @param 无
 * @retval 无
 */
void Encoder_Update(void)
{
    // ========== 左编码器数据更新 ==========
    // 1. 读取本次采样周期的脉冲增量（带符号，方向由硬件编码器相位决定）
    motor_LE.encoder_raw = encoder_L_obj.get_count();
    encoder_L_obj.clear_count();  // 清零硬件计数，为下次采样做准备（避免脉冲叠加）

    // 2. 计算原始实时速度（cm/s）= 脉冲增量 × 单脉冲距离 × 采样周期倒数
    // 原公式 raw_speed = motor_LE.encoder_raw * PULSE_TO_CM / SAMPLE_PERIOD_S;
    float raw_speed = motor_LE.encoder_raw * pulse_cm_coeff * inv_sample_period;
    // 一阶低通滤波（平滑速度，减少硬件抖动：20%历史值+80%当前值）
    motor_LE.current_speed = motor_LE.current_speed * 0.2f + raw_speed * 0.8f;

    // 3. 累加累计数据（记录从初始化到当前的总状态）
    motor_LE.total_pulse += motor_LE.encoder_raw;
    motor_LE.total_distance += motor_LE.encoder_raw * pulse_cm_coeff;
    motor_LE.total_run_time += SAMPLE_PERIOD_S;

    // 4. 计算平均速度（避免除以0，先算倒数再乘法）
    if (motor_LE.total_run_time > 0.001f)
    {
        float inv_time = 1.0f / motor_LE.total_run_time;
        motor_LE.avg_speed = motor_LE.total_distance * inv_time;
    }
    else
    {
        motor_LE.avg_speed = 0.0f;
    }

    // ========== 右编码器数据更新（逻辑同左编码器） ==========
    motor_RE.encoder_raw = -encoder_R_obj.get_count();
    encoder_R_obj.clear_count();

    // 2. 计算右轮原始速度并滤波
    raw_speed = motor_RE.encoder_raw * pulse_cm_coeff * inv_sample_period;
    motor_RE.current_speed = motor_RE.current_speed * 0.2f + raw_speed * 0.8f;

    // 3. 累加右轮累计数据
    motor_RE.total_pulse += motor_RE.encoder_raw;
    motor_RE.total_distance += motor_RE.encoder_raw * pulse_cm_coeff;
    motor_RE.total_run_time += SAMPLE_PERIOD_S;

    // 4. 计算右轮平均速度（防除零保护）
    if (motor_RE.total_run_time > 0.001f)
    {
        float inv_time = 1.0f / motor_RE.total_run_time;
        motor_RE.avg_speed = motor_RE.total_distance * inv_time;
    }
    else
    {
        motor_RE.avg_speed = 0.0f;
    }

    // ===================== 目标绕行：累计行驶距离 =====================
    if (target_avoid_running)
    {
        // 取左右轮平均速度 /2.0 → *0.5f
        float speed = (motor_LE.current_speed + motor_RE.current_speed) * 0.5f;
        // 累加距离：速度 * 周期
        target_avoid_distance += fabs(speed) * SAMPLE_PERIOD_S;

        // 达到行驶距离 → 结束绕行
        if (target_avoid_distance >= TARGET_NEED_RUN)
        {
            // 关闭绕行运行状态
            target_avoid_running = false;
            target_avoid_class = -1;
            target_final_class = -1;

            // 全量清空NCNN识别统计变量
            target_infer_cnt = 0;
            target_infer_done = false;
            memset(target_vote, 0, sizeof(target_vote));

            // 清空识别阶段速度与距离统计
            infer_frame_speed = 0.0f;
            infer_frame_distance = 0.0f;
            infer_total_distance = 0.0f;
            infer_total_speed = 0.0f;

            // 重置红色检测全状态
            red_detected_flag = false;
            last_red_detected = false;
            search_stage = 0;
            first_red_start_y = 0;

            // 标记绕行完成，允许下一轮识别触发
            is_avoid_finish = true;

            printf("\n🏁 目标绕行完成！恢复正常巡线\n");
        }
    }
}

/**
 * @brief 编码器数据打印函数（优化版）
 * @note 1. 精准输出指定维度数据：左右轮脉冲、实时速度、平均速度、累计里程；整车累计里程、平均速度、总运行时间
 *       2. 格式化输出，保留2位小数，列对齐，提升调试可读性
 * @param 无
 * @retval 无
 */
void Encoder_PrintData(void)
{
    // 计算整车数据（差速小车取左右轮平均值 /2.0 → *0.5f）
    float car_total_distance = (motor_LE.total_distance + motor_RE.total_distance) * 0.5f;
    float car_avg_speed = (motor_LE.avg_speed + motor_RE.avg_speed) * 0.5f;
    float car_total_run_time = (motor_LE.total_run_time + motor_RE.total_run_time) * 0.5f;

    printf("整车：累计里程=%.2f cm | 平均速度=%.2f cm/s | 总运行时间=%.2f s\n",
           car_total_distance, car_avg_speed, car_total_run_time);
    printf("====================================================\n\n");
}

/**
 * @brief 重置编码器累计数据
 * @note 1. 用于多次测试场景，清零后重新统计里程/时间/平均速度
 *       2. 仅重置累计数据，不影响实时速度、硬件计数等临时数据
 * @param 无
 * @retval 无
 */
void Encoder_ResetTotalData(void)
{
    // 左轮累计数据清零（恢复初始状态）
    motor_LE.total_pulse = 0;
    motor_LE.total_distance = 0.0f;
    motor_LE.total_run_time = 0.0f;
    motor_LE.avg_speed = 0.0f;

    // 右轮累计数据清零（同左轮）
    motor_RE.total_pulse = 0;
    motor_RE.total_distance = 0.0f;
    motor_RE.total_run_time = 0.0f;
    motor_RE.avg_speed = 0.0f;
}

#include "tcp_client_uvc_rgb_demo.hpp"
#include <unistd.h>
#include <cstdio>
#include <cstring>

// ====================== 全局硬件设备对象实例化 ======================
// TCP客户端实例，负责与电脑逐飞助手建立TCP长连接
zf_driver_tcp_client tcp_client_dev;
// UVC摄像头驱动实例，操作免驱USB摄像头采集RGB565图像
zf_device_uvc uvc_dev;
// 摄像头原始图像指针，每次采集后更新指向图像首地址
uint16* rgb_image = nullptr;

// ====================== 逐飞助手边界坐标数组实例化 ======================
// XY完整边界坐标存储数组（边界类型3专用）
uint8 xy_x1_boundary[BOUNDARY_NUM], xy_x2_boundary[BOUNDARY_NUM], xy_x3_boundary[BOUNDARY_NUM];
uint8 xy_y1_boundary[BOUNDARY_NUM], xy_y2_boundary[BOUNDARY_NUM], xy_y3_boundary[BOUNDARY_NUM];
// X轴单排边界数组（边界类型1/4专用）
uint8 x1_boundary[UVC_HEIGHT], x2_boundary[UVC_HEIGHT], x3_boundary[UVC_HEIGHT];
// Y轴单列边界数组（边界类型2专用）
uint8 y1_boundary[UVC_WIDTH], y2_boundary[UVC_WIDTH], y3_boundary[UVC_WIDTH];

// ====================== 图像缓冲区内存实例 ======================
// 字节交换后的彩色图像，上位机彩色显示使用
uint16 image_copy[UVC_HEIGHT][UVC_WIDTH];
// 压缩后灰度图，巡线算法vision_track_main唯一输入
uint8  gray_image[GRAY_IMAGE_HEIGHT][GRAY_IMAGE_WIDTH];
// 灰度二值化图像，可选上传上位机调试（使用二值模式请取消注释）
// uint8  binary_image[GRAY_IMAGE_HEIGHT][GRAY_IMAGE_WIDTH];
// 红色目标裁剪RGB565原图，用于送入NCNN推理
uint16 crop_color_image[CROP_IMAGE_HEIGHT][CROP_IMAGE_WIDTH];

// ====================== 图像上传模式全局变量 ======================
// 发送模式 0=彩色 1=灰度 2=二值 3=不发送
uint8 send_image_mode = 2;

// ====================== 红色目标检测控制变量 ======================
// 全局红色标记存在标志，巡线减速逻辑依赖该变量
bool red_detected_flag = false;
// 分阶段搜索首次发现红色的Y行坐标
int first_red_start_y = 0;
// 红色检索阶段：0初始检索画面上半区，1扩展检索至推理下边界
uint8 search_stage = 0;
// 缓存上一帧红色检测结果，用于判断目标新出现触发识别
bool last_red_detected = false;




// ====================== 红色基座查找结果全局实例 ======================
cv::Point2f g_base_TL, g_base_TR; // 基座顶边左右端点原图坐标
bool g_base_found = false;        // 基座查找成功状态标志



// ====================== NCNN分类投票识别全局变量 ======================
// 当前目标累计推理总帧数
int target_infer_cnt = 0;
// 识别完成标记，true停止推理，执行绕行逻辑
bool target_infer_done = false;
// 3分类投票计数数组，初始全0
int target_vote[MODEL_OUTPUT_CLASS_NUM] = {0};
// 最终识别目标类别，-1代表未识别完成
int target_final_class = -1;

// ====================== 识别过程速度、距离统计变量 ======================
// 单帧瞬时左右轮平均速度 cm/s
float infer_frame_speed = 0.0f;
// 当前帧行驶距离，按帧周期积分距离
float infer_frame_distance = 0.0f;
// 识别阶段累计总行驶距离
float infer_total_distance = 0.0f;
// 识别全程平均车速
float infer_total_speed = 0.0f;

// ====================== 目标绕行控制变量 ======================
// 绕行模式 0物资右绕 / 1载具直行 / 2武器左绕
uint8 avoid_obstacle_mode = 0;
// 绕行完成标志，true允许重新检测新红色目标
bool is_avoid_finish = true;
// 绕行执行中标志，电机控制逻辑读取该标志
// bool target_avoid_running = false; //Image.cpp 中定义
// 绕行累计行驶距离
// float target_avoid_distance = 0.0f; //Encoder.cpp 中定义
// 当前需要绕行的目标类别
// int target_avoid_class = -1; //Image.cpp 中定义

// 红砖状态标志，true=当前画面检测到红砖
bool red_brick_detected = false;
// 红砖避障激活标志
bool red_brick_active = false;             
// 进入红砖状态时的总行驶距离 
float red_brick_start_distance = 0.0f;      

// 当前帧红色像素总数
int g_red_pixel_count = 0;


// 历史记录数组与计数
int round_history[MAX_ROUND_HISTORY] = {0};
int round_history_count = 0;



// ====================== 帧调试日志计数变量 ======================
int frame_count = 0;               // 全局图像帧计数器
bool first_frame_logged = false;   // 第一帧预处理日志仅打印一次

// ====================== NCNN推理网络全局实例 ======================
ncnn::Net g_ncnn_net;              // NCNN网络对象
bool g_ncnn_init_done = false;     // 模型加载完成标记
bool ncnn_initialized = false;     // NCNN是否可用总开关
uint8_t* g_rgb888_buffer = nullptr;// NCNN输入RGB888内存缓冲区

// ImageNet归一化均值与标准差参数，和训练时预处理严格对齐
const float mean_vals[3] = {
    123.675f,   // R: 255 * 0.485
    116.280f,   // G: 255 * 0.456
    103.530f    // B: 255 * 0.406
    };
const float norm_vals[3] = {
    1.0f / (0.229f * 255.0f),
    1.0f / (0.224f * 255.0f),
    1.0f / (0.225f * 255.0f)
};

// 三大类标签字符串数组，下标0=物资 1=载具 2=武器
const char* class_labels[] = {"materials", "traffic", "weapon"};

// 单帧耗时统计结构体全局实例
ImageTimeStat image_time_stat = {0};
// 程序运行全程累计微秒数
uint64_t g_total_elapsed_us = 0;

// ====================== 图像发送模式切换函数实现 ======================
/**
 * @brief 切换TCP上传图像为彩色RGB565原图
 */
void switch_to_send_color(void)
{
    send_image_mode = 0;
    printf("✅ 切换发送：彩色图 image_copy\r\n");
}

/**
 * @brief 切换TCP上传图像为压缩灰度图
 */
void switch_to_send_gray(void)
{
    send_image_mode = 1;
    printf("✅ 切换发送：灰度图 gray_image\r\n");
}

/**
 * @brief 切换TCP上传图像为二值巡线图
 */
void switch_to_send_binary(void)
{
    send_image_mode = 2;
    printf("✅ 切换发送：二值图 binary_image\r\n");
}

/**
 * @brief 关闭图像TCP上传，仅后台运行巡线+识别算法，节省带宽
 */
void switch_to_send_none(void)
{
    send_image_mode = 3;
    printf("✅ 切换发送：不发送图像（仅运行算法）\r\n");
}

// ====================== TCP数据收发包装函数（适配逐飞助手接口） ======================
/**
 * @brief TCP发送数据封装，供seekfree_assistant调用
 * @param buf 待发送数据缓冲区指针
 * @param len 待发送字节长度
 * @return 实际成功发送字节数
 */
uint32 tcp_send_wrap(const uint8 *buf, uint32 len)
{
    return tcp_client_dev.send_data(buf, len);
}

/**
 * @brief TCP接收数据封装，供seekfree_assistant调用
 * @param buf 接收数据缓冲区
 * @param len 最大接收字节长度
 * @return 实际读取字节数
 */
uint32 tcp_read_wrap(uint8 *buf, uint32 len)
{
    return tcp_client_dev.read_data(buf, len);
}

// ====================== RGB565裁剪图转NCNN标准RGB888格式 ======================
/**
 * @brief 将裁剪RGB565图像转为连续RGB888字节流，适配NCNN输入要求
 * @param src 输入裁剪RGB565图像缓存
 * @param dst 输出RGB888连续内存缓冲区
 */
void rgb565_to_rgb888_for_ncnn(uint16_t src[CROP_IMAGE_HEIGHT][CROP_IMAGE_WIDTH], uint8_t* dst)
{
    // 逐行逐像素遍历裁剪图
    for(int y = 0; y < CROP_IMAGE_HEIGHT; y++)
    {
        for(int x = 0; x < CROP_IMAGE_WIDTH; x++)
        {
            uint16_t pixel = src[y][x];
            // 拆分RGB565 5/6/5分量并映射至0~255
            uint8_t R = ((pixel >> 11) & 0x1F) * 255 / 31;
            uint8_t G = ((pixel >> 5) & 0x3F) * 255 / 63;
            uint8_t B = (pixel & 0x1F) * 255 / 31;
            // RGB888内存排布：R G B连续三字节
            int idx = (y * CROP_IMAGE_WIDTH + x) * 3;
            dst[idx + 0] = R;
            dst[idx + 1] = G;
            dst[idx + 2] = B;
        }
    }
}

// ====================== NCNN模型初始化函数 ======================
/**
 * @brief 加载ncnn.param参数文件与ncnn.bin权重文件，分配推理输入缓存
 * @return 0成功 / -1失败
 */
int chibei_Init(void)
{
    // 已初始化直接返回，避免重复加载模型占用CPU
    if(g_ncnn_init_done)
    {
        printf("✅ NCNN已经初始化过了\n");
        ncnn_initialized = true;
        return 0;
    }
    printf("===== NCNN模型初始化 =====\n");
    // 打印当前程序运行目录，方便排查模型文件路径错误
    char cwd[1024];
    if (getcwd(cwd, sizeof(cwd)) != NULL)
        printf("📁 当前工作目录: %s\n", cwd);

    // 校验参数文件是否存在
    FILE* fp = fopen("tiny_classifier_fp32.ncnn.param", "r");
    if (!fp)
    {
        printf("❌ 模型参数文件不存在\n");
        ncnn_initialized = false;
        return -1;
    }
    fclose(fp);

    // 校验权重文件是否存在
    fp = fopen("tiny_classifier_fp32.ncnn.bin", "r");
    if (!fp)
    {
        printf("❌ 模型权重文件不存在\n");
        ncnn_initialized = false;
        return -1;
    }
    fclose(fp);

    // 动态分配RGB888输入缓冲区：宽*高*3通道字节
    g_rgb888_buffer = new uint8_t[CROP_IMAGE_WIDTH * CROP_IMAGE_HEIGHT * 3];
    if(!g_rgb888_buffer)
    {
        printf("❌ RGB888缓冲区分配失败！\n");
        ncnn_initialized = false;
        return -1;
    }

    // NCNN推理硬件/线程配置
    g_ncnn_net.opt.num_threads = 2;        // 双线程推理，适配龙芯LS2K0300双核
    g_ncnn_net.opt.use_vulkan_compute = false; // 关闭GPU加速，仅CPU推理
    g_ncnn_net.opt.use_fp16_storage = true;    // 半精度存储降低内存占用

    // 加载网络结构参数
    int ret = g_ncnn_net.load_param("tiny_classifier_fp32.ncnn.param");
    if(ret != 0)
    {
        printf("❌ 加载参数失败！错误码: %d\n", ret);
        delete[] g_rgb888_buffer;
        g_rgb888_buffer = nullptr;
        ncnn_initialized = false;
        return -1;
    }
    // 加载模型权重
    ret = g_ncnn_net.load_model("tiny_classifier_fp32.ncnn.bin");
    if(ret != 0)
    {
        printf("❌ 加载权重失败！错误码: %d\n", ret);
        delete[] g_rgb888_buffer;
        g_rgb888_buffer = nullptr;
        ncnn_initialized = false;
        return -1;
    }

    // 初始化状态置1，推理可用
    g_ncnn_init_done = true;
    ncnn_initialized = true;
    printf("✅ NCNN模型初始化成功！\n");
    return 0;
}

// ====================== NCNN底层纯推理函数 ======================
/**
 * @brief 执行单张RGB888图像推理，输出3分类置信度数组
 * @param rgb888_buffer 输入RGB888图像内存
 * @param w 原图宽度
 * @param h 原图高度
 * @param output_probs 输出置信度数组
 * @return 0推理正常 / -1模型未初始化
 */
int run_ncnn_inference_pure(uint8_t* rgb888_buffer, int w, int h, float* output_probs)
{
    if(!g_ncnn_init_done) return -1;
    // 将RGB888原始图像缩放至模型固定输入尺寸
    ncnn::Mat in = ncnn::Mat::from_pixels_resize(rgb888_buffer, ncnn::Mat::PIXEL_RGB,
        w, h, NCNN_INPUT_WIDTH, NCNN_INPUT_HEIGHT);
    if(in.empty()) return -1;
    // 执行ImageNet标准化预处理
    in.substract_mean_normalize(mean_vals, norm_vals);
    // 创建推理提取器，输入张量in0
    ncnn::Extractor ex = g_ncnn_net.create_extractor();
    ex.input("in0", in);
    // 读取输出张量out0
    ncnn::Mat out;
    ex.extract("out0", out);
    // 将推理结果拷贝至外部数组
    for(int i = 0; i < MODEL_OUTPUT_CLASS_NUM; i++)
        output_probs[i] = out.row(0)[i];
    return 0;
}

// ====================== 完整推理业务逻辑（含投票、速度距离统计） ======================
/**
 * @brief 每帧触发推理主函数，仅红色在推理区间内才会调用
 *        功能：车速距离计算、置信度过滤、单帧投票计数、推理帧总数累加
 * @note 规则：置信度≥0.90才计入有效投票帧
 */
void run_model_inference(void)
{
    // 识别流程已完成，直接退出，不再重复推理，节省CPU算力
    if(target_infer_done) return;
    // NCNN模型未初始化，无法执行推理，直接返回
    if(!ncnn_initialized)
    {
        printf("❌ NCNN未初始化！\n");
        return;
    }

    // ========== 1. 计算当前帧瞬时车速、单帧行驶距离、累计行驶数据 ==========
    // 左右轮瞬时速度取平均值作为本帧车辆平均速度(cm/s)
    infer_frame_speed = (motor_LE.current_speed + motor_RE.current_speed) * 0.5f;
    // 单帧循环周期按10ms估算，距离=速度*时间，单位cm
    infer_frame_distance = fabs(infer_frame_speed) * 0.01f;
    // 累加识别阶段总行驶里程
    infer_total_distance += infer_frame_distance;
    // 计算识别全程平均车速，+0.001防止分母为0触发除零崩溃
    infer_total_speed = infer_total_distance / (target_infer_cnt * 0.01f + 0.001f);

    // ========== 2. RGB565裁剪图像转为NCNN标准RGB888连续内存格式 ==========
    rgb565_to_rgb888_for_ncnn(crop_color_image, g_rgb888_buffer);
    // 存放3分类推理输出置信度
    float probs[MODEL_OUTPUT_CLASS_NUM];
    // 执行底层纯推理，输出每一类置信分数
    int ret = run_ncnn_inference_pure(g_rgb888_buffer, CROP_IMAGE_WIDTH, CROP_IMAGE_HEIGHT, probs);
    // 推理执行失败，直接退出不统计投票
    if(ret != 0)
    {
        printf("❌ 推理失败！\n");
        return;
    }

    // ========== 3. 遍历置信度数组，找出当前帧置信度最高类别 ==========
    float max_v = 0.0f;  // 当前帧最大置信度
    int max_i = 0;       // 当前帧置信最高类别下标
    for(int i = 0; i < MODEL_OUTPUT_CLASS_NUM; i++)
    {
        if(probs[i] > max_v)
        {
            max_v = probs[i];
            max_i = i;
        }
    }

    // ========== 4. 统计推理总帧数 + 有效帧投票计数 ==========
    // 进入本函数代表红色在模型识别区间内，所有推理帧全部计入总推理帧数
    target_infer_cnt++;

    // 条件判断：将当前帧检测出的最大置信度与有效识别阈值对比
    // max_v：本帧全部检测框中置信度最高的数值
    // TARGET_CONF_THRESH：工程预设最低可信置信阈值（宏定义，如0.5、0.6）
    if(max_v >= TARGET_CONF_THRESH)
    {
        // -------------------------- 分支1：当前帧判定为有效识别帧 --------------------------
        // 逻辑：置信满足要求，说明当前画面目标清晰、识别可靠，参与多帧投票滤波
        // target_vote[max_i]：类别投票数组，max_i为最高置信目标对应的类别下标
        // 对应类别票数+1，连续多帧识别同一目标时票数持续累加，用于防抖判决
        target_vote[max_i]++;

        printf("[有效帧 累计总帧:%d] 识别类别:%s 置信度:%.4f \n", target_infer_cnt, class_labels[max_i], max_v);
    }
    else
    {
        // 无效帧不投票，仅作调试打印（已注释）
    }
}

// ====================== RGB565原图缩放+灰度转换函数 ======================
/**
 * @brief 原始RGB565转为压缩灰度图，使用OpenCV双线性插值缩放
 * @param src_rgb565 摄像头原始图像指针
 * @param gray_image 输出压缩灰度图缓存
 * @param src_width 原图宽 UVC_WIDTH
 * @param src_height 原图高 UVC_HEIGHT
 * @param dst_width 输出灰度宽 GRAY_IMAGE_WIDTH
 * @param dst_height 输出灰度高 GRAY_IMAGE_HEIGHT
 */
void resize_and_gray_convert(uint16* src_rgb565, uint8* gray_image,
                              int src_width, int src_height,
                              int dst_width, int dst_height)
{
    // 创建OpenCV BGR矩阵，存放原图解析后的8位彩色
    cv::Mat src_bgr(src_height, src_width, CV_8UC3);
    for (int y = 0; y < src_height; y++)
    {
        for (int x = 0; x < src_width; x++)
        {
            uint16_t rgb565 = src_rgb565[y * src_width + x];
            // 拆分5/6/5位RGB分量
            uint8_t r5 = (rgb565 >> 11) & 0x1F;
            uint8_t g6 = (rgb565 >> 5)  & 0x3F;
            uint8_t b5 = rgb565 & 0x1F;
            // 5/6位扩展至0~255 8位
            uint8_t r8 = (r5 << 3) | (r5 >> 2);
            uint8_t g8 = (g6 << 2) | (g6 >> 4);
            uint8_t b8 = (b5 << 3) | (b5 >> 2);
            // OpenCV存储顺序BGR
            src_bgr.at<cv::Vec3b>(y, x) = cv::Vec3b(b8, g8, r8);
        }
    }
    // 双线性插值缩放至目标尺寸
    cv::Mat resized_bgr;
    cv::resize(src_bgr, resized_bgr, cv::Size(dst_width, dst_height), 0, 0, cv::INTER_LINEAR);
    // BGR转单通道灰度图
    cv::Mat gray_mat;
    cv::cvtColor(resized_bgr, gray_mat, cv::COLOR_BGR2GRAY);
    // 内存连续直接整块拷贝，否则逐行拷贝防止内存断层
    if (gray_mat.isContinuous())
        memcpy(gray_image, gray_mat.data, dst_width * dst_height);
    else
    {
        for (int y = 0; y < dst_height; y++)
            memcpy(gray_image + y * dst_width, gray_mat.ptr(y), dst_width);
    }
}


// ====================== RGB565直接生成红色二值掩码 ======================
// 功能：跳过BGR中间步骤，直接从RGB565计算HSV并输出红色二值图
// 优势：减少一次全图遍历，降低嵌入式CPU占用，阈值与OpenCV标准完全兼容
void rgb565_to_red_mask(const uint16_t* src_rgb565, int img_w, int img_h,
                        int roi_x1, int roi_y1, int roi_x2, int roi_y2,
                        cv::Mat& mask)
{
    int roi_w = roi_x2 - roi_x1;                     // 计算ROI宽度像素
    int roi_h = roi_y2 - roi_y1;                     // 计算ROI高度像素
    mask.create(roi_h, roi_w, CV_8UC1);              // 创建对应尺寸单通道二值图

    // 逐行遍历ROI区域
    for (int y = 0; y < roi_h; y++)
    {
        uchar* mask_row = mask.ptr<uchar>(y);        // 获取掩码当前行首指针
        int src_y = roi_y1 + y;                      // 计算对应原图行号
        const uint16_t* src_row = src_rgb565 + src_y * img_w + roi_x1; // 原图ROI起始行指针

        // 逐像素遍历当前行
        for (int x = 0; x < roi_w; x++)
        {
            uint16_t pixel = src_row[x];             // 读取RGB565像素值
            // 提取5位R、6位G、5位B分量
            uint8_t r5 = (pixel >> 11) & 0x1F;       // R分量：0~31
            uint8_t g6 = (pixel >> 5)  & 0x3F;       // G分量：0~63
            uint8_t b5 = pixel & 0x1F;               // B分量：0~31

            // 分量映射到0~255量程，与OpenCV 8位色深标准对齐
            uint8_t r = (r5 << 3) | (r5 >> 2);       // R: 5位扩展为8位
            uint8_t g = (g6 << 2) | (g6 >> 4);       // G: 6位扩展为8位
            uint8_t b = (b5 << 3) | (b5 >> 2);       // B: 5位扩展为8位

            // 计算RGB最大值、最小值、分量差值
            uint8_t max_val = std::max({r, g, b});   // 三分量最大值
            uint8_t min_val = std::min({r, g, b});   // 三分量最小值
            uint8_t delta = max_val - min_val;       // 最大最小分量差值

            // 饱和度S = delta / max_val * 255，最大值为0时饱和度为0
            uint8_t s = (max_val == 0) ? 0 : (delta * 255) / max_val;
            uint8_t v = max_val;                     // 明度V = 三分量最大值

            bool is_red = false;                     // 红色判定结果标志
            if (s >= S_LOW && v >= V_LOW)            // 先过滤低饱和度、低明度像素
            {
                // 计算色相H（0~360度，最终映射到OpenCV的0~180量程）
                int h_deg;
                if (delta == 0)                      // 灰度像素，色相默认为0
                {
                    h_deg = 0;
                }
                else if (max_val == r)               // 最大值为R，色相在红色/品红区间
                {
                    h_deg = 60 * (g - b) / delta;    // 0~60度（红→黄）或300~360度（品红→红）
                    if (h_deg < 0) h_deg += 360;     // 负角度转正为0~360
                }
                else if (max_val == g)               // 最大值为G，色相在绿色区间
                {
                    h_deg = 120 + 60 * (b - r) / delta; // 60~180度
                }
                else                                 // 最大值为B，色相在蓝色区间
                {
                    h_deg = 240 + 60 * (r - g) / delta; // 180~300度
                }

                // OpenCV中H范围为0~180，故将0~360度除以2
                int h_cv = h_deg / 2;
                // 判断是否落在红色双区间：0~10 或 155~180
                if ((h_cv >= H_LOW1 && h_cv <= H_HIGH1) || 
                    (h_cv >= H_LOW2 && h_cv <= H_HIGH2))
                {
                    is_red = true;
                }
            }

            mask_row[x] = is_red ? 255 : 0;          // 红色像素赋值255，背景赋值0
        }
    }
}



// ====================== 红色基座查找函数（直接输入RGB565，新增红色像素计数输出） ======================
// 功能：ROI内红色二值化、轮廓筛选、粘连分离，提取基座顶边左右基准点
// 特点：仅做图像识别与几何计算，无任何裁剪、变换逻辑
// 新增 out_red_count：返回开运算后掩码中非零像素总数（ROI区域红色像素数）
bool find_red_base(
    const uint16_t* src_rgb565,  // 输入RGB565原图指针
    int img_w,                   // 原图总宽度
    int img_h,                   // 原图总高度
    int roi_x_start,             // ROI水平起始列
    int roi_x_end,               // ROI水平结束列
    int roi_y_start,             // ROI垂直起始行
    int roi_y_end,               // ROI垂直结束行
    cv::Point2f& out_base_TL,    // 输出：基座顶边左端点（原图坐标系）
    cv::Point2f& out_base_TR,    // 输出：基座顶边右端点（原图坐标系）
    int* out_red_count           // 输出：红色像素总数（掩码非零像素计数），可为nullptr
)
{
    // 1. 约束ROI边界合法性，防止数组越界访问
    roi_x_start = std::max(0, std::min(roi_x_start, img_w - 1)); // X起始约束在0~倒数第二列
    roi_x_end   = std::max(roi_x_start + 1, std::min(roi_x_end, img_w)); // X结束保证至少1列宽度
    roi_y_start = std::max(0, std::min(roi_y_start, img_h - 1)); // Y起始约束在0~倒数第二行
    roi_y_end   = std::max(roi_y_start + 1, std::min(roi_y_end, img_h)); // Y结束保证至少1行高度

    cv::Mat mask; // 红色二值掩码图
    // 2. 直接从RGB565生成红色掩码（核心优化：跳过BGR中间转换）
    rgb565_to_red_mask(src_rgb565, img_w, img_h,
                       roi_x_start, roi_y_start, roi_x_end, roi_y_end,
                       mask);

    // 形态学处理：仅开运算去噪，关闭闭运算避免基座与上方目标粘连
    cv::Mat kernel = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3)); // 创建3×3矩形结构元
    cv::morphologyEx(mask, mask, cv::MORPH_OPEN, kernel); // 开运算：先腐蚀后膨胀，消除微小噪点

    // ---- 新增：统计红色像素总数（开运算后） ----
    if (out_red_count != nullptr)
    {
        *out_red_count = cv::countNonZero(mask);
    }

    // 3. 查找所有外层红色轮廓
    std::vector<std::vector<cv::Point>> contours; // 容器：存储所有轮廓的像素点集合
    cv::findContours(mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE); // 仅提取最外层轮廓，压缩点集节省内存

    if (contours.empty()) return false;        // 无任何红色轮廓，基座查找直接失败

    // 4. 遍历轮廓，筛选横向长条基座，同时记录最大面积作为兜底
    int base_idx = -1;                         // 合格基座轮廓索引，初始-1代表未找到
    float max_bottom_y = -1;                   // 候选基座的最大底边Y，筛选画面最下方的有效基座
    double max_area = 0;                       // 遍历过程中最大轮廓面积，宽高比不达标时兜底使用
    int max_area_idx = -1;                     // 最大面积轮廓对应的数组下标

    for (size_t i = 0; i < contours.size(); i++)
    {
        double area = cv::contourArea(contours[i]); // 计算当前轮廓包围的像素面积
        if (area < MIN_AREA) continue;               // 面积小于阈值判定为噪点，直接跳过

        // 更新全局最大面积轮廓信息
        if (area > max_area)
        {
            max_area = area;                    // 刷新最大面积数值
            max_area_idx = static_cast<int>(i); // 刷新最大面积轮廓下标
        }

        cv::Rect br = cv::boundingRect(contours[i]); // 获取轮廓竖直外接矩形，用于宽高比判断
        if (br.height < 1) continue;           // 矩形高度为0，无效轮廓直接跳过
        float wh_ratio = static_cast<float>(br.width) / br.height; // 计算宽高比，区分长条基座与方形图案

        if (wh_ratio < WH_RATIO_THRESH) continue;         // 宽高比不足阈值，不是横向细长条，跳过不作为基座候选

        // ROI局部Y坐标换算为原图完整Y坐标（叠加ROI顶部偏移）
        float bottom_y = br.y + br.height + roi_y_start;
        if (bottom_y > max_bottom_y)
        {
            max_bottom_y = bottom_y;            // 更新画面最下方基座的底边Y值
            base_idx = static_cast<int>(i);     // 更新基座轮廓索引为当前合格长条轮廓
        }
    }

    // 未找到符合宽高比的长条基座，启用最大面积轮廓兜底识别
    if (base_idx == -1)
    {
        if (max_area_idx == -1 || max_area < FALLBACK_AREA) return false; // 兜底轮廓面积过小，判定无有效目标
        base_idx = max_area_idx;              // 将最大面积轮廓作为基座轮廓使用
    }

    // 5. 粘连分离逻辑：基座与上方目标粘连时，只截取底部真实底座部分
    std::vector<cv::Point> base_contour = contours[base_idx]; // 取出选中基座对应的全部轮廓点
    cv::Rect bound_box = cv::boundingRect(base_contour);       // 获取基座轮廓整体外接竖直矩形
    float estimated_base_height = bound_box.width * BASE_W_SCALE;     // 按宽高比反推标准底座理论高度
    std::vector<cv::Point> pure_base_pts;                     // 存储剥离上方粘连物体后的纯底座点集合

    // 判断是否发生粘连：实际轮廓高度远超理论底座高度
    if (bound_box.height > estimated_base_height * STICK_SCALE)
    {
        int max_y = -1;                      // 记录轮廓内部最低点Y坐标（轮廓最底部）
        for (const auto& pt : base_contour) // 遍历基座全部轮廓点
        {
            if (pt.y > max_y) max_y = pt.y;   // 持续更新轮廓最低点Y值
        }
        int cut_h = static_cast<int>(estimated_base_height * STICK_SCALE); // 从底部向上截取的像素高度
        for (const auto& pt : base_contour) // 再次遍历基座轮廓点，筛选底部有效底座点
        {
            if (pt.y > max_y - cut_h)         // 仅保留底部cut_h高度范围内的点，剔除上方粘连部分
            {
                pure_base_pts.push_back(pt);  // 符合条件的底座点存入集合
            }
        }
    }
    else
    {
        pure_base_pts = base_contour;         // 无粘连，全部轮廓点直接作为底座点使用
    }

    // 6. 计算基座最小旋转外接矩形，获取倾斜角度
    cv::RotatedRect base_rect;              // 存储基座旋转矩形，用于获取倾斜角度与四边坐标
    if (pure_base_pts.size() >= 4)          // 分离后的纯底座点数量充足，使用分离点计算旋转矩形
    {
        base_rect = cv::minAreaRect(pure_base_pts);
    }
    else                                    // 底座点过少，极端兜底：使用原始粘连轮廓计算旋转矩形
    {
        base_rect = cv::minAreaRect(base_contour);
    }

    cv::Point2f pts[4];                    // 存储旋转矩形四个角点（当前为ROI局部坐标）
    base_rect.points(pts);                 // 提取旋转矩形四点坐标存入数组

    // 将ROI局部坐标映射回原图完整坐标系
    for (int i = 0; i < 4; i++)
    {
        pts[i].x += roi_x_start;            // 叠加ROI起始列偏移，X转换为原图像素坐标
        pts[i].y += roi_y_start;            // 叠加ROI起始行偏移，Y转换为原图像素坐标
    }

    // 7. 区分旋转矩形两条长边，提取紧贴目标的基座顶部边缘
    float dist01 = cv::norm(pts[0] - pts[1]); // 计算0、1两点之间欧式距离
    float dist12 = cv::norm(pts[1] - pts[2]); // 计算1、2两点之间欧式距离
    cv::Point2f long_edge1_p1, long_edge1_p2, long_edge2_p1, long_edge2_p2; // 存储两条长边的四个端点

    if (dist01 > dist12)                   // 0-1边长度更大，为第一条长边
    {
        long_edge1_p1 = pts[0]; long_edge1_p2 = pts[1];
        long_edge2_p1 = pts[2]; long_edge2_p2 = pts[3];
    }
    else                                   // 1-2边长度更大，为第一条长边
    {
        long_edge1_p1 = pts[1]; long_edge1_p2 = pts[2];
        long_edge2_p1 = pts[3]; long_edge2_p2 = pts[0];
    }

    // 两条长边中点Y均值更小的一条，是基座顶部边缘（靠近上方目标）
    float avg_y1 = (long_edge1_p1.y + long_edge1_p2.y) / 2.0f; // 第一条长边中点Y坐标
    float avg_y2 = (long_edge2_p1.y + long_edge2_p2.y) / 2.0f; // 第二条长边中点Y坐标
    cv::Point2f top_p1, top_p2;            // 基座顶边两个端点
    if (avg_y1 < avg_y2)                   // 第一条长边整体位置更高（Y更小），判定为顶边
    {
        top_p1 = long_edge1_p1; top_p2 = long_edge1_p2;
    }
    else                                   // 第二条长边整体位置更高，判定为顶边
    {
        top_p1 = long_edge2_p1; top_p2 = long_edge2_p2;
    }

    // 区分顶边左端点、右端点并赋值输出
    if (top_p1.x < top_p2.x)               // p1X坐标更小，为顶边左端点
    {
        out_base_TL = top_p1;
        out_base_TR = top_p2;
    }
    else                                   // p2X坐标更小，为顶边左端点
    {
        out_base_TL = top_p2;
        out_base_TR = top_p1;
    }

    return true; // 基座识别完成，成功返回
}


// ====================== 目标矫正裁剪函数 ======================
// 功能：纯向量几何+仿射变换，基于基座顶边推算目标区域，输出转正的正方形图像
// 特点：无任何阈值分割、轮廓查找逻辑，仅做几何计算与像素重映射
cv::Mat crop_target_from_base(
    const cv::Mat& src,          // 输入BGR原图，const只读
    int output_size,             // 输出矫正后正方形图像边长
    cv::Point2f base_TL,         // 基座顶边左端点（原图坐标）
    cv::Point2f base_TR,         // 基座顶边右端点（原图坐标）
    int &out_x1, int &out_y1,    // 输出：目标旋转包围盒左上角坐标
    int &out_x2, int &out_y2,    // 输出：目标旋转包围盒右下角坐标
    cv::Point2f out_corners[4]   // 输出：目标四点旋转坐标，顺序TL、TR、BR、BL
)
{
    int h = src.rows;                          // 获取原图高度像素
    int w = src.cols;                          // 获取原图宽度像素

    // 1. 校验基座宽度合法性，过滤极小无效基座
    float base_width = cv::norm(base_TR - base_TL); // 计算基座顶边实际像素长度
    if (base_width < 10) return src.clone();   // 基座宽度不足10像素判定无效，返回原图副本

    // 2. 计算正交单位向量，用于向上推算目标区域
    cv::Point2f dir_w = (base_TR - base_TL) / base_width; // 沿基座顶边向右的单位向量
    cv::Point2f dir_up(dir_w.y, -dir_w.x);     // 垂直基座顶边向上的正交单位向量

    // 基座顶边整体向上偏移，隔开红色底座，避免裁剪混入基座红色
    base_TL += dir_up * UP_OFFSET_PX;            // 顶边左端点向上偏移
    base_TR += dir_up * UP_OFFSET_PX;            // 顶边右端点向上偏移

    // 3. 远近自适应缩放比例计算，远距离放大、近距离缩小
    float min_width = MIN_BASE_W;                   // 基座宽度下限，小于该值统一按远距离计算
    float max_width = MAX_BASE_W;                   // 基座宽度上限，大于该值统一按近距离计算
    float current_width = std::max(min_width, std::min(base_width, max_width)); // 基座宽度钳位到区间
    float far_padding  = FAR_PAD;                 // 远距离目标缩放系数，预留边缘余量
    float near_padding = NEAR_PAD;                 // 近距离目标缩放系数，减少多余背景
    // 线性插值计算当前距离对应的目标缩放比例
    float padding_ratio = far_padding + (current_width - min_width) * (near_padding - far_padding) / (max_width - min_width);
    float target_size = base_width * padding_ratio; // 计算最终目标正方形边长

    // 4. 向量运算求解目标正方形四个角点（原图坐标系）
    cv::Point2f bottom_center = (base_TL + base_TR) * 0.5f; // 目标正方形底边中心点
    cv::Point2f target_center = bottom_center + dir_up * (target_size * 0.5f); // 目标正方形几何中心

    cv::Point2f P_BL = target_center - dir_up * (target_size * 0.5f) - dir_w * (target_size * 0.5f); // 目标左下角
    cv::Point2f P_BR = target_center - dir_up * (target_size * 0.5f) + dir_w * (target_size * 0.5f); // 目标右下角
    cv::Point2f P_TL = target_center + dir_up * (target_size * 0.5f) - dir_w * (target_size * 0.5f); // 目标左上角
    cv::Point2f P_TR = target_center + dir_up * (target_size * 0.5f) + dir_w * (target_size * 0.5f); // 目标右上角

    // 5. 仿射变换求解，将倾斜目标转正为标准正方形
    cv::Point2f src_pts[3] = { P_TL, P_TR, P_BL }; // 原图目标三点：左上、右上、左下
    cv::Point2f dst_pts[3] = {
        cv::Point2f(0, 0),                  // 矫正后图像对应左上坐标
        cv::Point2f(output_size, 0),        // 矫正后图像对应右上坐标
        cv::Point2f(0, output_size)         // 矫正后图像对应左下坐标
    };
    cv::Mat affine_matrix = cv::getAffineTransform(src_pts, dst_pts); // 求解仿射变换矩阵
    cv::Mat output_img;                    // 存储矫正完成后的正方形输出图像
    cv::warpAffine(src, output_img, affine_matrix, cv::Size(output_size, output_size),
                   cv::INTER_LINEAR, cv::BORDER_REPLICATE); // 执行仿射变换，线性插值，边缘复制填充

    // 6. 计算目标整体包围盒，约束坐标不超出图像边界
    float min_x = std::min({P_TL.x, P_TR.x, P_BL.x, P_BR.x}); // 目标四点最小X，包围盒左边界
    float max_x = std::max({P_TL.x, P_TR.x, P_BL.x, P_BR.x}); // 目标四点最大X，包围盒右边界
    float min_y = std::min({P_TL.y, P_TR.y, P_BL.y, P_BR.y}); // 目标四点最小Y，包围盒上边界
    float max_y = std::max({P_TL.y, P_TR.y, P_BL.y, P_BR.y}); // 目标四点最大Y，包围盒下边界

    out_x1 = std::max(0, std::min(static_cast<int>(min_x), w - 2)); // 约束左边界合法范围
    out_y1 = std::max(0, std::min(static_cast<int>(min_y), h - 2)); // 约束上边界合法范围
    out_x2 = std::max(0, std::min(static_cast<int>(max_x), w));     // 约束右边界合法范围
    out_y2 = std::max(0, std::min(static_cast<int>(max_y), h));     // 约束下边界合法范围

    // 回传目标四点旋转坐标，绘图顺序 TL → TR → BR → BL
    out_corners[0] = P_TL;                 // 目标左上角
    out_corners[1] = P_TR;                 // 目标右上角
    out_corners[2] = P_BR;                 // 目标右下角
    out_corners[3] = P_BL;                 // 目标左下角

    return output_img;                     // 返回扶正裁剪完成的目标图像
}


// ====================== BGR Mat转RGB565工具函数 ======================
// 功能：将OpenCV BGR格式图像转为项目通用的RGB565 uint16数组
// 注意：输入Mat尺寸必须与输出缓冲区尺寸严格一致
void mat_bgr_to_rgb565(const cv::Mat& src_bgr, uint16_t* dst_rgb565)
{
    int w = src_bgr.cols;                   // 获取图像宽度像素
    int h = src_bgr.rows;                   // 获取图像高度像素
    for (int y = 0; y < h; y++)             // 逐行遍历图像
    {
        for (int x = 0; x < w; x++)         // 逐像素遍历当前行
        {
            cv::Vec3b pixel = src_bgr.at<cv::Vec3b>(y, x); // 读取BGR三通道像素值
            uint8_t b = pixel[0];           // 提取蓝色分量
            uint8_t g = pixel[1];           // 提取绿色分量
            uint8_t r = pixel[2];           // 提取红色分量
            // 8位分量压缩为5/6/5位，按RGB顺序组合为16位RGB565
            uint16_t rgb565 = ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3);
            dst_rgb565[y * w + x] = rgb565; // 写入输出缓冲区对应位置
        }
    }
}


/**
 * @brief 判断红色目标是否为赛道旁的红砖（新算法，含另一边界全程稳定检查）
 * @param red_cx_320 红色中心 X（320×240 原图坐标）
 * @param red_cy_320 红色中心 Y（320×240 原图坐标）
 * @return true=红砖，false=非红砖或条件不满足
 * @note  依赖全局变量：
 *        - g_car_angle：当前赛道角度（度），由巡线算法提供（需在 Image.hpp 中声明 extern）
 *        - mid_line_list, left_line_list, right_line_list：巡线边界数组
 *        - g_red_pixel_count：当前帧红色像素总数
 */
static bool is_red_brick(int red_cx_320, int red_cy_320)
{
    printf("[is_red_brick] 入口: (%d,%d)\n", red_cx_320, red_cy_320);

    // 条件0：直道判定
    if (fabs(fit_angle) >= RED_BRICK_ANGLE_THRESH)
    {
        // printf("  ❌ 赛道角 %.2f >= %.1f，非直道\n", fabs(fit_angle), RED_BRICK_ANGLE_THRESH);
        return false;
    }

    // 条件1：行区间
    if (red_cy_320 < RED_BRICK_JUDGE_ROW_START || red_cy_320 > RED_BRICK_JUDGE_ROW_END)
    {
        // printf("  ❌ 行 %d 不在判定区间 [%d,%d]\n", red_cy_320, RED_BRICK_JUDGE_ROW_START, RED_BRICK_JUDGE_ROW_END);
        return false;
    }

    int gray_cx = red_cx_320 / 2;
    int gray_cy = red_cy_320 / 2;
    // printf("  灰度坐标: (%d,%d)\n", gray_cx, gray_cy);

    // 条件2：面积
    if (g_red_pixel_count <= RED_BRICK_AREA_THRESH)
    {
        //printf("  ❌ 红色面积 %d <= %d\n", g_red_pixel_count, RED_BRICK_AREA_THRESH);
        return false;
    }

    // 条件3：中线距离
    int dist = abs(gray_cx - mid_line_list[gray_cy]);
    // printf("  中线距离: %d (阈值 %d)\n", dist, RED_BRICK_DIST_THRESH);
    if (dist <= RED_BRICK_DIST_THRESH)
    {
        //printf("  ❌ 中线距离不足，靠近中线\n");
        return false;
    }

    // 条件4：边界突变特征
    int y_bottom = gray_cy + RED_BRICK_SCAN_HALF_H;
    int y_top    = gray_cy - 5;
    if (y_bottom >= GRAY_IMAGE_HEIGHT) y_bottom = GRAY_IMAGE_HEIGHT - 1;
    if (y_top < search_cutoff_row)      y_top    = search_cutoff_row;
    if (y_top >= y_bottom)
    {
        //printf("  ❌ 扫描区间无效 y_top=%d y_bottom=%d\n", y_top, y_bottom);
        return false;
    }
    //printf("  边界扫描区间: [%d, %d]\n", y_top, y_bottom);

    // 辅助 lambda（保持不变）
    auto boundary_has_brick_pattern = [&](const uint8_t* bound_array) -> bool {
        enum State { SEEK_STABLE, IN_JUMP, SEEK_STABLE2 };
        State state = SEEK_STABLE;
        int stable_count = 0;
        int jump_count = 0;
        int stable2_count = 0;

        for (int y = y_bottom; y > y_top; --y) {
            int diff = abs(bound_array[y] - bound_array[y-1]);
            switch (state) {
                case SEEK_STABLE:
                    if (diff <= RED_BRICK_STABLE_BEFORE_THRESH) {
                        stable_count++;
                        if (stable_count >= RED_BRICK_STABLE_MIN_LEN) {
                            state = IN_JUMP;
                            jump_count = 0;
                        }
                    } else {
                        stable_count = 0;
                    }
                    break;
                case IN_JUMP:
                    if (diff > RED_BRICK_JUMP_THRESH) {
                        jump_count++;
                        if (jump_count > RED_BRICK_JUMP_MAX_LEN) {
                            state = SEEK_STABLE;
                            stable_count = 0;
                        }
                    } else {
                        if (jump_count > 0) {
                            state = SEEK_STABLE2;
                            stable2_count = 0;
                            if (diff <= RED_BRICK_STABLE_AFTER_THRESH) stable2_count++;
                        } else {
                            state = SEEK_STABLE;
                            stable_count = 0;
                        }
                    }
                    break;
                case SEEK_STABLE2:
                    if (diff <= RED_BRICK_STABLE_AFTER_THRESH) {
                        stable2_count++;
                        if (stable2_count >= RED_BRICK_STABLE_AFTER_MIN_LEN) {
                            return true;
                        }
                    } else {
                        state = SEEK_STABLE;
                        stable_count = 0;
                    }
                    break;
            }
        }
        return false;
    };

    auto boundary_is_fully_stable = [&](const uint8_t* bound_array, int threshold) -> bool {
        for (int y = y_bottom; y > y_top; --y) {
            if (abs(bound_array[y] - bound_array[y-1]) > threshold) {
                return false;
            }
        }
        return true;
    };

    // 检测左边界/右边界
    bool left_pattern = boundary_has_brick_pattern(left_line_list);
    bool right_stable = left_pattern ? boundary_is_fully_stable(right_line_list, RED_BRICK_OTHER_STABLE_THRESH) : false;
    bool right_pattern = boundary_has_brick_pattern(right_line_list);
    bool left_stable = right_pattern ? boundary_is_fully_stable(left_line_list, RED_BRICK_OTHER_STABLE_THRESH) : false;

    // printf("  左边界砖块模式: %s  右边界稳定: %s\n",
    //        left_pattern ? "有" : "无", right_stable ? "是" : "否");
    // printf("  右边界砖块模式: %s  左边界稳定: %s\n",
    //        right_pattern ? "有" : "无", left_stable ? "是" : "否");

    if ((left_pattern && right_stable) || (right_pattern && left_stable))
    {
        //printf("  ✅ 红砖特征匹配成功\n");
        return true;
    }

    //printf("  ❌ 红砖特征不匹配\n");
    return false;
}


/**
 * @brief 两段式红色区域检索（阶段1新增红色像素计数更新）
 * 规则：
 * 1. 阶段0(初始搜索)：Y仅搜索上半区，像素级快速遍历，无红不向下拓展
 * 2. 阶段1(识别搜索)：检出红色后切换，Y拓展至推理下边界，调用基座查找函数精准定位
 * 3. 无红色 / 识别完成 → 重置为阶段0，重新初始搜索
 * @param img RGB565原图指针
 * @param w 图像宽度
 * @param h 图像高度
 * @param cx 输出红色/基座中心X
 * @param cy 输出红色/基座中心Y
 */
void find_red_object_center(uint16* img, int w, int h, int* cx, int* cy)
{
    // 横向固定搜索区间：画面1/5 ~ 4/5，两阶段共用
    const int search_x_start = SEARCH_RED_START_X;
    const int search_x_end   = SEARCH_RED_END_X;

    // 搜索垂直区域（分阶段控制）
    int search_y_start = 0;
    int search_y_end = 0;

    // ====================== 阶段0：初始快速搜索 ======================
    if(search_stage == 0)
    {
        search_y_start = SEARCH_RED_TOP_Y;    // 垂直起始：红色搜索上边界
        search_y_end = SEARCH_RED_BOTTOM_Y;   // 垂直结束：红色搜索下边界

        int sum_x = 0;      // 红色像素X坐标累加和
        int count = 0;      // 有效红色像素总数量
        int min_y = h;      // 红色区域最上方行
        int max_y = 0;      // 红色区域最下方行

        // 垂直逐行遍历当前阶段限定Y区间
        for (int y = search_y_start; y <= search_y_end; y++)
        {
            // 水平遍历中间X检索区间
            for (int x = search_x_start; x <= search_x_end; x++)
            {
                uint16_t pixel = img[y * w + x]; // 读取当前像素RGB565值
                // 拆分RGB565三色分量
                uint8_t R = (pixel >> 11) & 0x1F;
                uint8_t G = (pixel >> 5)  & 0x3F;
                uint8_t B = pixel & 0x1F;
                // 红色判定阈值：红色分量高，绿蓝分量低
                if (R > 14 && G < 16 && B < 16)
                {
                    sum_x += x;                  // 累加X坐标
                    count++;                     // 红色像素计数+1
                    // 更新红色区域上下边界
                    if (y < min_y) min_y = y;
                    if (y > max_y) max_y = y;
                    // 初始阶段检测到任意红色点，下一帧切换为识别搜索阶段1
                    if(search_stage == 0)
                    {
                        first_red_start_y = y;   // 记录首次检出红色的行号
                        search_stage = 1;        // 切换到阶段1精准识别
                    }
                }
            }
        }

        // 红色像素不足40判定无有效红色目标
        if (count < 40)
        {
            *cx = 0;                             // 中心X清零
            *cy = 0;                             // 中心Y清零
            red_detected_flag = false;           // 全局红色标志置假
            g_base_found = false;                // 基座查找标志置假
            search_stage = 0;                    // 重置搜索阶段
            first_red_start_y = 0;               // 清空首次检出行号
            g_red_pixel_count = 0;               // 清零
        }
        else
        {
            // 阶段0仅输出粗略中心，阶段1再精准计算
            *cx = sum_x / count;                 // 计算X方向几何中心
            *cy = (min_y + max_y) / 2;           // 计算Y方向几何中心

            // ========== 阶段0 截止行过滤（目标过近则忽略） ==========
            // 坐标系转换：原图 320×240 → 灰度图 160×120
            int cy_scaled = *cy / 2;
            if (cy_scaled < search_cutoff_row + 3)
            {
                // 清空输出坐标，告知外部无有效红色
                *cx = 0;
                *cy = 0;

                // 重置所有红色检测相关全局状态
                red_detected_flag = false;
                g_base_found = false;
                search_stage = 0;                // 强制保持阶段0
                first_red_start_y = 0;
                g_red_pixel_count = 0;

                return;                          // 直接返回，不设置 red_detected_flag
            }

            red_detected_flag = true;            // 全局红色标志置真

            // 将当前帧红色像素数存入全局变量，供红砖判定函数使用
            g_red_pixel_count = count;

            // ========== 打印红色像素统计信息 ==========
            printf("[阶段0] 红色像素数: %d, 中心(%d,%d)\n", count, *cx, *cy);
        }
    }
    // ====================== 阶段1：精准基座搜索 ======================
    else
    {
        search_y_start = SEARCH_RED_TOP_Y;    // 垂直起始：红色搜索上边界
        search_y_end = MODEL_INFER_BOTTOM_Y;  // 垂直结束：推理区域下边界

        // 直接调用RGB565版本的基座查找，同时获取红色像素计数
        cv::Point2f base_TL, base_TR;
        int red_count_stage1 = 0; // 用于接收阶段1红色像素数
        bool find_ok = find_red_base(
            img, w, h,                        // RGB565原图指针、宽、高
            search_x_start, search_x_end,     // ROI水平范围
            search_y_start, search_y_end,     // ROI垂直范围
            base_TL, base_TR,                 // 输出基座顶边端点
            &red_count_stage1                 // 输出红色像素总数
        );

        if (!find_ok)
        {
            // 基座查找失败，判定无有效目标，重置回阶段0
            *cx = 0;
            *cy = 0;
            red_detected_flag = false;
            g_base_found = false;
            search_stage = 0;
            first_red_start_y = 0;
            g_red_pixel_count = 0;
            return;
        }

        // 查找成功，更新全局基准点
        g_base_TL = base_TL;
        g_base_TR = base_TR;
        g_base_found = true;
        red_detected_flag = true;

        // 更新全局红色像素计数（使用阶段1的掩码统计值）
        g_red_pixel_count = red_count_stage1;

        // 计算基座顶边中点作为中心坐标，兼容原有中心逻辑
        *cx = static_cast<int>((base_TL.x + base_TR.x) / 2.0f);
        *cy = static_cast<int>((base_TL.y + base_TR.y) / 2.0f);
        
        // 打印基座定位信息、红色像素数与推理区间状态
        bool in_infer_area = (*cy >= MODEL_INFER_TOP_Y && *cy <= MODEL_INFER_BOTTOM_Y);
        printf(in_infer_area ? "✅在模型识别区间内\n" : "❌超出模型识别区间\n");
        printf("[阶段1] 红色像素数: %d, 基座中心(%d,%d)\n", red_count_stage1, *cx, *cy);
    }

    bool is_outside_boundary = false;   // 默认不在边界外
    if (red_detected_flag)
    {
        // 将红色中心坐标缩放到灰度图坐标系（160×120）
        int gray_cx = *cx / 2;
        int gray_cy = *cy / 2;

        // 仅当当前行在边界有效范围内（>= search_cutoff_row）且边界有效时进行判断
        if (gray_cy >= (int)search_cutoff_row && gray_cy < GRAY_IMAGE_HEIGHT)
        {
            int left_bound  = left_line_list[gray_cy];
            int right_bound = right_line_list[gray_cy];
            if (left_bound < right_bound)   // 边界有效
            {
                // 红色中心列 < 左边界 或 > 右边界 → 位于赛道外侧
                if (gray_cx < left_bound || gray_cx > right_bound)
                    is_outside_boundary = true;
            }
        }
    }

    // ---- 如果不在边界外，直接清除红砖标志，不再做任何后续判定 ----
    if (!is_outside_boundary)
    {
        red_brick_detected = false;
       // printf("[红砖] 红色中心在赛道内，非红砖\n");
        return;
    }

    // ========== 以下：红色中心在赛道外侧，进行红砖判定 ==========
    if (!red_detected_flag)
    {
        red_brick_detected = false;
        return;
    }

    // 记录上一帧红砖状态，用于上升沿打印
    static bool last_red_brick_detected = false;
    bool prev_state = red_brick_detected;   // 暂时保存，后面会更新

    // 获取灰度坐标用于打印
    int gray_cx_print = *cx / 2;
    int gray_cy_print = *cy / 2;

    // printf("[红砖判定] 中心(%d,%d) 灰度(%d,%d) 赛道角=%.2f 面积=%d\n",
    //        *cx, *cy, gray_cx_print, gray_cy_print, fabs(fit_angle), g_red_pixel_count);

    // ---------- 远距离（红色中心行 < 83） ----------
    if (*cy < RED_BRICK_FAR_ROW_END)
    {
        // printf("  距离段: 远距离 (Y<%d)  阈值面积>%d  ",
        //        RED_BRICK_FAR_ROW_END, RED_BRICK_FAR_AREA_THRESH);
        if (g_red_pixel_count > RED_BRICK_FAR_AREA_THRESH)
        {
            red_brick_detected = true;
            // printf("✅ 通过\n");
        }
        else
        {
            red_brick_detected = false;
            // printf("❌ 未通过\n");
        }
    }
    // ---------- 中距离（83 ≤ 红色中心行 < 115） ----------
    else if (*cy >= RED_BRICK_MID_ROW_START && *cy < RED_BRICK_MID_ROW_END)
    {
        // printf("  距离段: 中距离 (%d≤Y<%d)  阈值面积>%d  ",
        //        RED_BRICK_MID_ROW_START, RED_BRICK_MID_ROW_END, RED_BRICK_AREA_THRESH);
        if (g_red_pixel_count > RED_BRICK_AREA_THRESH)
        {
            red_brick_detected = true;
           // printf("✅ 通过\n");
        }
        else
        {
            red_brick_detected = false;
            // printf("❌ 未通过\n");
        }
    }
    // ---------- 近距离（115 ≤ 红色中心行 ≤ 140） ----------
    else if (*cy >= RED_BRICK_JUDGE_ROW_START && *cy <= RED_BRICK_JUDGE_ROW_END)
    {
        // printf("  距离段: 近距离 (%d≤Y≤%d)，调用 is_red_brick 精细判定\n",
        //        RED_BRICK_JUDGE_ROW_START, RED_BRICK_JUDGE_ROW_END);
        red_brick_detected = is_red_brick(*cx, *cy);
        // printf("  is_red_brick 返回: %s\n", red_brick_detected ? "真(红砖)" : "假(非红砖)");
    }
    else
    {
        // printf("  距离段: 超出所有判定区间，非红砖\n");
        red_brick_detected = false;
    }

    // 上升沿汇总打印
    if (!last_red_brick_detected && red_brick_detected)
    {
        printf("\n========== 🧱 红砖判定通过！ ==========\n");
        printf("  原图中心: (%d, %d)\n", *cx, *cy);
        printf("  灰度坐标: (%d, %d)\n", *cx/2, *cy/2);
        printf("  赛道角度: %.2f° (阈值 <%.1f)\n", fabs(fit_angle), RED_BRICK_ANGLE_THRESH);
        printf("  红色面积: %d\n", g_red_pixel_count);
        if (*cy >= RED_BRICK_JUDGE_ROW_START && *cy <= RED_BRICK_JUDGE_ROW_END)
        {
            int gray_cy = *cy / 2;
            printf("  中线距离: %d (阈值 %d)\n",
                   abs(gray_cx_print - mid_line_list[gray_cy]), RED_BRICK_DIST_THRESH);
        }
        printf("=========================================\n\n");
    }

    last_red_brick_detected = red_brick_detected;

}

// ====================== RGB565图像中心裁剪函数 ======================
/**
 * @brief 以(cx,cy)为中心点裁剪固定尺寸RGB565图像，自动边界防越界
 * @param src 原始大图指针
 * @param dst 裁剪后图像缓存
 * @param cx 裁剪中心X
 * @param cy 裁剪中心Y
 * @param crop_w 裁剪宽度
 * @param crop_h 裁剪高度
 */
void crop_color_rgb565(uint16* src, uint16* dst, int cx, int cy, int crop_w, int crop_h)
{
    int src_w = UVC_WIDTH;
    int src_h = UVC_HEIGHT;
    // 计算裁剪框左上角坐标
    int x_start = cx - (crop_w / 2);
    int y_start = cy - (crop_h / 2);
    // 边界保护，防止裁剪框超出原图范围
    if (x_start < 0) x_start = 0;
    if (y_start < 0) y_start = 0;
    if (x_start + crop_w > src_w) x_start = src_w - crop_w;
    if (y_start + crop_h > src_h) y_start = src_h - crop_h;

    // 逐像素拷贝裁剪区域RGB565数据
    for (int y = 0; y < crop_h; y++)
    {
        for (int x = 0; x < crop_w; x++)
        {
            int src_x = x_start + x;
            int src_y = y_start + y;
            dst[y * crop_w + x] = src[src_y * src_w + src_x];
        }
    }
}

// ====================== RGB565图像绘制矩形框（上位机可视化标记） ======================
/**
 * @brief 在原图绘制矩形边框，标记红色目标裁剪区域
 * @param img RGB565图像缓存
 * @param w 图像宽
 * @param h 图像高
 * @param x 矩形左上角X
 * @param y 矩形左上角Y
 * @param bw 矩形宽度
 * @param bh 矩形高度
 * @param color RGB565颜色值 0x07E0纯红色
 */
void draw_rect_rgb565(uint16* img, int w, int h, int x, int y, int bw, int bh, uint16_t color)
{
    int x2 = x + bw - 1;
    int y2 = y + bh - 1;
    // 坐标边界限制，防止越界访问内存
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x2 >= w) x2 = w - 1;
    if (y2 >= h) y2 = h - 1;

    // 绘制上下两条横线
    for (int px = x; px <= x2; px++)
    {
        img[y * w + px] = color;
        img[y2 * w + px] = color;
    }
    // 绘制左右两条竖线
    for (int py = y; py <= y2; py++)
    {
        img[py * w + x] = color;
        img[py * w + x2] = color;
    }
}

// ====================== 高精度系统时间戳 ======================
/**
 * @brief 获取系统单调时钟微秒时间戳，用于帧耗时统计
 * @return 当前系统微秒数 uint32
 */
uint32_t get_system_time_us(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint32_t)(ts.tv_sec * 1000000 + ts.tv_nsec / 1000);
}

/**
 * @brief 转换微秒时间戳为毫秒
 */
uint32_t get_system_time_ms(void)
{
    return get_system_time_us() / 1000;
}

// ====================== 重置图像耗时统计结构体 ======================
void reset_image_time_stat(void)
{
    memset(&image_time_stat, 0, sizeof(ImageTimeStat));
    g_total_elapsed_us = 0;
}

// ====================== 项目主业务入口函数 ======================
/**
 * @brief 系统主业务函数，包含TCP初始化、摄像头启动、NCNN加载、图像循环采集、红色识别、推理、巡线、图像上传全流程
 * 
 * 核心识别流程：
 * 1. 分阶段检索红色色块，仅推理区间内才执行裁剪+NCNN推理
 * 2. 置信度≥0.90计入有效投票，有效帧达6帧强制停止推理
 * 3. 目标离开识别区时，有效帧≥3判定完成，1~2判定误触并清空统计
 * 4. 识别完成后上锁启动绕行，绕行结束前不会触发新识别
 */
void tcp_client_uvc_rgb_demo(void)
{
    // 边界配置分支循环变量定义
#if(1 == INCLUDE_BOUNDARY_TYPE || 2 == INCLUDE_BOUNDARY_TYPE || 4 == INCLUDE_BOUNDARY_TYPE)
    int32 i = 0;
#elif(3 == INCLUDE_BOUNDARY_TYPE)
    int32 i = 0;
    int32 j = 0;
#endif

    // ========== 步骤1：TCP客户端初始化，连接电脑逐飞助手 ==========
    if(tcp_client_dev.init(SERVER_IP, PORT) == 0)
        printf("tcp_client ok\r\n");
    else
    {
        printf("tcp_client error\r\n");
        return;
    }
    // 初始化逐飞助手通信接口，注册TCP收发回调
    seekfree_assistant_interface_init(tcp_send_wrap, tcp_read_wrap);

    // ========== 步骤2：根据边界类型预生成巡线边界坐标 ==========
#if(0 == INCLUDE_BOUNDARY_TYPE)
    // 类型0：仅图像，无边界曲线
    seekfree_assistant_camera_information_config(SEEKFREE_ASSISTANT_SCC8660, image_copy[0], UVC_WIDTH, UVC_HEIGHT);
#elif(1 == INCLUDE_BOUNDARY_TYPE)
    // 类型1：每行一组X轴边界，生成渐变三条中线
    for(i = 0; i < UVC_HEIGHT; i++)
    {
        x1_boundary[i] = 50 - (50 - 20) * i / UVC_HEIGHT;
        x2_boundary[i] = UVC_WIDTH / 2;
        x3_boundary[i] = 70 + (148 - 70) * i / UVC_HEIGHT;
    }
    seekfree_assistant_camera_information_config(SEEKFREE_ASSISTANT_MT9V03X, image_copy[0], UVC_WIDTH, UVC_HEIGHT);
    seekfree_assistant_camera_boundary_config(X_BOUNDARY, UVC_HEIGHT, x1_boundary, x2_boundary, x3_boundary, NULL, NULL ,NULL);
#elif(2 == INCLUDE_BOUNDARY_TYPE)
    // 类型2：每列一组Y轴边界
    for(i = 0; i < UVC_WIDTH; i++)
    {
        y1_boundary[i] = 50 - (50 - 20) * i / UVC_HEIGHT;
        y2_boundary[i] = UVC_WIDTH / 2;
        y3_boundary[i] = 78 + (78 - 58) * i / UVC_HEIGHT;
    }
    seekfree_assistant_camera_information_config(SEEKFREE_ASSISTANT_MT9V03X, image_copy[0], UVC_WIDTH, UVC_HEIGHT);
    seekfree_assistant_camera_boundary_config(Y_BOUNDARY, UVC_WIDTH, NULL, NULL ,NULL, y1_boundary, y2_boundary, y3_boundary);
#elif(3 == INCLUDE_BOUNDARY_TYPE)
    // 类型3：完整XY坐标边界，支持弯道回弯可视化
    j = 0;
    // 直道段边界
    for(i = UVC_HEIGHT - 1; i >= UVC_HEIGHT / 2; i--)
    {
        xy_x1_boundary[j] = 34; xy_y1_boundary[j] = i;
        xy_x2_boundary[j] = 47; xy_y2_boundary[j] = i;
        xy_x3_boundary[j] = 60; xy_y3_boundary[j] = i;
        j++;
    }
    // 直道转弯道过渡段
    for(i = UVC_HEIGHT / 2 - 1; i >= 0; i--)
    {
        xy_x1_boundary[j] = 34 + (UVC_HEIGHT / 2 - i) * (UVC_WIDTH / 2 - 34) / (UVC_HEIGHT / 2);
        xy_y1_boundary[j] = i;
        xy_x2_boundary[j] = 47 + (UVC_HEIGHT / 2 - i) * (UVC_WIDTH / 2 - 47) / (UVC_HEIGHT / 2);
        xy_y2_boundary[j] = 15 + i * 3 / 4;
        xy_x3_boundary[j] = 60 + (UVC_HEIGHT / 2 - i) * (UVC_WIDTH / 2 - 60) / (UVC_HEIGHT / 2);
        xy_y3_boundary[j] = 30 + i / 2;
        j++;
    }
    // 回弯段边界
    for(i = 0; i < UVC_HEIGHT / 2; i++)
    {
        xy_x1_boundary[j] = UVC_WIDTH / 2 + i * (138 - UVC_WIDTH / 2) / (UVC_HEIGHT / 2);
        xy_y1_boundary[j] = i;
        xy_x2_boundary[j] = UVC_WIDTH / 2 + i * (133 - UVC_WIDTH / 2) / (UVC_HEIGHT / 2);
        xy_y2_boundary[j] = 15 + i * 3 / 4;
        xy_x3_boundary[j] = UVC_WIDTH / 2 + i * (128 - UVC_WIDTH / 2) / (UVC_HEIGHT / 2);
        xy_y3_boundary[j] = 30 + i / 2;
        j++;
    }
    seekfree_assistant_camera_information_config(SEEKFREE_ASSISTANT_MT9V03X, image_copy[0], UVC_WIDTH, UVC_HEIGHT);
    seekfree_assistant_camera_boundary_config(XY_BOUNDARY, BOUNDARY_NUM, xy_x1_boundary, xy_x2_boundary, xy_x3_boundary, xy_y1_boundary, xy_y2_boundary, xy_y3_boundary);
#elif(4 == INCLUDE_BOUNDARY_TYPE)
    // 类型4：仅传输边界，不发送图像，节省带宽
    for(i = 0; i < UVC_HEIGHT; i++)
    {
        x1_boundary[i] = 70 - (70 - 20) * i / UVC_HEIGHT;
        x2_boundary[i] = UVC_WIDTH / 2;
        x3_boundary[i] = 80 + (159 - 80) * i / UVC_HEIGHT;
    }
    seekfree_assistant_camera_information_config(SEEKFREE_ASSISTANT_MT9V03X, NULL, UVC_WIDTH, UVC_HEIGHT);
    seekfree_assistant_camera_boundary_config(X_BOUNDARY, UVC_HEIGHT, x1_boundary, x2_boundary, x3_boundary, NULL, NULL ,NULL);
#endif

    // ========== 步骤3：UVC免驱摄像头初始化 ==========
    if(uvc_dev.init(UVC_PATH) < 0)
    {
        printf("❌ 摄像头初始化失败！\r\n");
        return;
    }
    printf("✅ 摄像头初始化成功\r\n");

    // ========== 步骤4：加载NCNN分类模型 ==========
    printf("[NCNN] 正在加载模型...\r\n");
    if(chibei_Init() == 0)
    {
        printf("✅ NCNN模型加载成功\r\n");
        printf("   输入尺寸:%dx%d    类别数:%d\r\n", NCNN_INPUT_WIDTH, NCNN_INPUT_HEIGHT, MODEL_OUTPUT_CLASS_NUM);
        printf("   置信度阈值:%.2f   起始阈值:%d   结束阈值:%d\r\n", 
            TARGET_CONF_THRESH, VOTE_START_THRESHOLD, VOTE_END_THRESHOLD);
        printf("   推理区域: Y=%d~%d\n", MODEL_INFER_TOP_Y, MODEL_INFER_BOTTOM_Y);
    }
    else
    {
        printf("❌ NCNN模型加载失败！\r\n");
        printf("   请确保SD卡根目录存在 tiny_classifier_fp32.ncnn.param / .bin\n");
    }
    printf("\r\n========== 系统启动完成 ==========\r\n");

    // ========== 主循环：无限循环采集图像、处理、巡线、上传 ==========
    while (true)
    {
        // 静态帧计数器：函数内static只初始化一次，数值跨帧保留
        static int send_frame_cnt = 0;
        send_frame_cnt++; // 每次进循环先自增

        // ===================== 总耗时起始点 =====================
        uint32_t t1 = get_system_time_us(); // 单帧计时起点

        // ===================== 斑马线定时退出 =====================
        zebra_timer_check(); // 斑马线减速计时逻辑

        // 阻塞等待摄像头新一帧图像采集完成
        if(uvc_dev.wait_image_refresh() < 0)
        {
            printf("❌ 摄像头采集异常，程序退出！\r\n");
            return;
        }
        
        // 获取摄像头采集到的RGB565格式图像数据的首地址指针
        rgb_image = uvc_dev.get_rgb_image_ptr();
        image_time_stat.capture_us = get_system_time_us() - t1; // 记录采集耗时

        // ========== RGB565高低字节交换，适配上位机彩色显示 ==========
        uint32_t t_byte_swap = get_system_time_us();
        // 摄像头采集的RGB565高低位顺序与上位机解析要求不一致，必须交换后才能正常显示彩色
        for(uint32_t i = 0; i < UVC_WIDTH * UVC_HEIGHT; i++)
        {
            ((uint16_t *)image_copy[0])[i] = (((uint16_t *)rgb_image)[i] & 0xFF) << 8 |
                                               (((uint16_t *)rgb_image)[i] & 0xFF00) >> 8;
        }
        uint32_t time_byte_swap = get_system_time_us() - t_byte_swap;

        // ========== 红色目标检测、裁剪、NCNN推理处理流程 ==========
        uint32_t t_process = get_system_time_us();
        // 变量全部提前定义，杜绝goto跨初始化编译错误
        int red_cx, red_cy;       // 红色中心点坐标
        bool curr_red;            // 当前帧是否检测到红色
        bool in_infer_area;       // 红色是否在推理区间内
        bool out_infer_area;      // 红色是否离开推理区间
        int valid_total;          // 当前累计有效帧总数
        int box_x, box_y;         // 裁剪框左上角坐标
        uint32_t time_process;    // 处理耗时
        uint8_t infer_result = 0; // 识别状态结果：0无结果 1识别完成 2识别误触 3全无效帧


        // ---------- 第一帧跳过红色检测 ----------
        static bool first_frame_skip = true;
        if (first_frame_skip)
        {
            first_frame_skip = false;

            goto vision_process;
        }

        // ============== 模式1：无识别模式 / 环岛模式 → 跳过红色识别 ==============
        if (!IS_RECOG_ENABLE() || track_state != NORMAL_TRACK)
        {
            // 红色检测标志全部复位
            red_detected_flag = false;
            last_red_detected = false;
            g_red_pixel_count = 0;          // 红色像素计数清零

            // 搜索阶段复位（关键！避免出环岛后延续之前的阶段1状态）
            search_stage = 0;
            first_red_start_y = 0;

            // 基座查找结果清除
            g_base_found = false;

            // 绕行标志强制复位（防止残留绕行状态卡住巡线）
            is_avoid_finish = true;
            target_avoid_running = false;

            // // 可选：打印当前跳过原因（调试用）
            // if (track_state != NORMAL_TRACK)
            //     printf("⛔ 环岛模式，跳过红色搜索\n");
            // else
            //     printf("🔹 识别模式关闭，跳过红色搜索\n");

            goto vision_process; // 直接跳转到视觉巡线部分
        }


        // ---- 红砖避障状态：禁止识别，直接巡线 ----
        if (red_brick_active)
        {
            // 计算当前总行驶距离（左右轮平均，单位cm）
            float current_dist = (motor_LE.total_distance + motor_RE.total_distance) * 0.5f;
            // 判断是否已经驶过红砖距离阈值
            if (current_dist - red_brick_start_distance >= RED_BRICK_AVOID_DIST_CM)
            {
                // 达到阈值，退出红砖避障状态，恢复识别功能
                red_brick_active = false;
                red_brick_detected = false;
                // 同时重置红色搜索状态，为下一轮正常识别做准备
                search_stage = 0;
                first_red_start_y = 0;
                printf("🟢 已驶离红砖区域，重新开启目标识别\n");
            }
            else
            {
                // 仍在红砖避障中，清空红色相关标志，直接进入巡线
                red_detected_flag = false;
                last_red_detected = false;
                // 强制结束任何可能存在的绕行（红砖优先级最高）
                is_avoid_finish = true;
                target_avoid_running = false;
                time_process = get_system_time_us() - t_process;
                image_time_stat.process_us = time_process;
                goto vision_process;
            }
        }

        // ---- 红砖状态激活判断 ----
        // 仅在普通模式、未绕行、且当前帧检测到红砖时激活避障状态
        if (!red_brick_active && is_avoid_finish && red_brick_detected)
        {
            red_brick_active = true;
            // 记录进入时的总行驶距离（左右轮平均值）
            red_brick_start_distance = (motor_LE.total_distance + motor_RE.total_distance) * 0.5f;
            
            // 强制结束任何可能的绕行（安全兜底）
            is_avoid_finish = true;
            target_avoid_running = false;
           
            // 清空本轮识别统计
            target_infer_cnt = 0;
            target_infer_done = false;
            memset(target_vote, 0, sizeof(target_vote));
            target_final_class = -1;
            infer_frame_speed = infer_frame_distance = infer_total_distance = infer_total_speed = 0.0f;
            search_stage = 0;
            first_red_start_y = 0;
            printf("🔴 检测到红砖，进入避障状态，暂停识别 %d cm\n", (int)RED_BRICK_AVOID_DIST_CM);
            
            // 直接跳转到巡线，不再进行后续识别流程
            time_process = get_system_time_us() - t_process;
            image_time_stat.process_us = time_process;
            goto vision_process;
        }



        // ============== 绕行未完成，跳过全部红色检测与识别流程 ==============
        if (!is_avoid_finish)
        {
            red_detected_flag = false;
            last_red_detected = false; // 绕行期间无有效红色检测，重置上一帧状态
            search_stage = 0;
            first_red_start_y = 0;
            time_process = get_system_time_us() - t_process;
            image_time_stat.process_us = time_process;
            goto vision_process;
        }

        // ============== 绕行已结束，开始红色检测与识别 ==============
        // 检索画面红色标记，输出中心坐标（原图 320×240 坐标系）
        find_red_object_center(rgb_image, UVC_WIDTH, UVC_HEIGHT, &red_cx, &red_cy);

    
        // 当前帧是否存在有效红色目标（坐标非零即视为存在，后续会进一步过滤）
        curr_red = (red_cx != 0 && red_cy != 0);

        /**
         * 新一轮识别重置触发条件：
         * 1. 上一轮绕行完全结束
         * 2. 上一帧画面无红色目标
         * 3. 当前帧新检测到红色目标
         * 三者同时满足，清空所有识别统计，开启全新一轮目标识别
         */
        if (is_avoid_finish && !last_red_detected && curr_red)
        {
            // 清空识别统计变量
            target_infer_cnt = 0;
            target_infer_done = false;
            memset(target_vote, 0, sizeof(target_vote));
            target_final_class = -1;
            // 清空速度距离统计
            infer_frame_speed = infer_frame_distance = infer_total_distance = infer_total_speed = 0.0f;
            printf("\n 绕行完成，检测到新目标，开始识别\n");
        }

        // 计算当前累计有效帧总数
        valid_total = target_vote[0] + target_vote[1] + target_vote[2];
        // 判断红色中心点是否落在有效推理区间
        in_infer_area = (red_cy >= MODEL_INFER_TOP_Y && red_cy <= MODEL_INFER_BOTTOM_Y);

        /**
         * 推理触发条件（全部满足才执行）：
         * 1. 当前帧存在红色目标
         * 2. 红色中心点在推理区间内
         * 3. 本轮识别未完成（未上锁）
         * 4. NCNN模型已初始化
         * 5. 有效帧未达到结束阈值上限
         * 6. 基座查找成功
         */
        if(curr_red && in_infer_area && !target_infer_done && ncnn_initialized 
            && valid_total < VOTE_END_THRESHOLD && g_base_found)
        {
            //printf("🎯 触发矫正裁剪推理: 基座Y=%d | 当前有效帧:%d/%d\n", red_cy, valid_total, VOTE_END_THRESHOLD);
           
            // 步骤1：全图RGB565转BGR格式Mat（仅推理触发时执行，低频开销）
            cv::Mat src_bgr(UVC_HEIGHT, UVC_WIDTH, CV_8UC3);
            for (int y = 0; y < UVC_HEIGHT; y++)
            {
                for (int x = 0; x < UVC_WIDTH; x++)
                {
                    uint16_t rgb565 = rgb_image[y * UVC_WIDTH + x];
                    uint8_t r5 = (rgb565 >> 11) & 0x1F;
                    uint8_t g6 = (rgb565 >> 5)  & 0x3F;
                    uint8_t b5 = rgb565 & 0x1F;
                    uint8_t r8 = (r5 << 3) | (r5 >> 2);
                    uint8_t g8 = (g6 << 2) | (g6 >> 4);
                    uint8_t b8 = (b5 << 3) | (b5 >> 2);
                    src_bgr.at<cv::Vec3b>(y, x) = cv::Vec3b(b8, g8, r8);
                }
            }

            // 步骤2：调用矫正裁剪函数，生成转正的正方形目标图
            int box_x1, box_y1, box_x2, box_y2;
            cv::Point2f corners[4];
            cv::Mat corrected_img = crop_target_from_base(
                src_bgr, CROP_IMAGE_WIDTH,
                g_base_TL, g_base_TR,
                box_x1, box_y1, box_x2, box_y2,
                corners
            );

            // 步骤3：矫正后的BGR图转为RGB565，写入原裁剪缓冲区，兼容后续NCNN流程
            mat_bgr_to_rgb565(corrected_img, crop_color_image[0]);
            
            // 步骤4：执行NCNN模型推理（含车速统计、置信度过滤、投票计数）
            run_model_inference();
            
            // 彩色发送模式下，在上位机图像上绘制目标外接矩形可视化
            if (send_image_mode == 0)
            {
                draw_rect_rgb565((uint16*)image_copy[0], UVC_WIDTH, UVC_HEIGHT,
                    box_x1, box_y1, box_x2 - box_x1, box_y2 - box_y1, 0x07E0);
            }
        }

        
        // 红色在推理区但模型未加载，打印警告
        if(curr_red && in_infer_area && !ncnn_initialized)
            printf("⚠️ 检测到红色，但NCNN模型未初始化！\n");


            // 更新上一帧红色状态，用于下一帧判断新目标
        last_red_detected = curr_red;
        // 判断红色是否离开推理区间
        out_infer_area = (red_cy < MODEL_INFER_TOP_Y) || (red_cy > MODEL_INFER_BOTTOM_Y);
        // 更新最新有效帧总数
        valid_total = target_vote[0] + target_vote[1] + target_vote[2];

        // ====================== 第一步：集中判定识别状态 ======================
        // 0=无结果 1=识别完成 2=识别误触 3=全无效帧
        infer_result = 0 ; // 重置状态
        if (!target_infer_done && target_infer_cnt > 0)
        {
            // 情况1：有效帧达到上限，强制判定完成
            if (valid_total >= VOTE_END_THRESHOLD)
                infer_result = 1;
            // 情况2：红色消失/离开识别区，分情况判定
            else if (!curr_red || out_infer_area)
            {
                if (valid_total >= VOTE_START_THRESHOLD)
                    infer_result = 1;  // 有效帧达标，正常完成
                else if (valid_total >= 1)
                    infer_result = 2;  // 有效帧不足，判定误触
                else
                    infer_result = 3;  // 全无有效帧
            }
        }

        // ====================== 第二步：统一执行结果处理 ======================
        if (infer_result == 1) // 识别完成：统计类别+上锁+启动绕行+打印
        {
            // 筛选票数最高的类别作为最终结果
            int max_count = 0;
            target_final_class = 0;
            for(int i = 0; i < MODEL_OUTPUT_CLASS_NUM; i++)
            {
                if(target_vote[i] > max_count)
                {
                    max_count = target_vote[i];
                    target_final_class = i;
                }
            }


            // ========== 保存历史记录 ==========
            if (round_history_count < MAX_ROUND_HISTORY)
            {
                round_history[round_history_count] = target_final_class;
                round_history_count++;
            }

            // ==================== 推理轮数达标自动停车 ====================
            #if STOP_AFTER_INFERENCE_ROUNDS > 0  // 宏大于 0 时才编译，0 则完全忽略
                if (round_history_count >= STOP_AFTER_INFERENCE_ROUNDS)
                {
                    // 打印退出提示
                    printf("\n🏁 程序安全退出！\n");
                    // 统一停车（关电机、停电调、清空 PID）
                    Diff_Steer_Stop();
                    // 终止整个程序（不再执行后续任何代码）
                    exit(0);
                }
            #endif

            // 全局上锁：停止推理，启动绕行
            target_infer_done = true;
            is_avoid_finish = false;
            target_avoid_running = true;
            target_avoid_distance = 0.0f;
            target_avoid_class = target_final_class;

            // 根据类别映射绕行策略：0物资右绕/1载具直行/2武器左绕
            if(target_final_class == 2)      avoid_obstacle_mode = 2;
            else if(target_final_class == 0) avoid_obstacle_mode = 0;
            else                             avoid_obstacle_mode = 1;
            // ========== 完整识别汇总日志 ==========
            printf("\n=====================================\n");
            printf("  ✅ 目标识别完成，启动绕行模式！\n");
            printf("  累计推理总帧数：%d\n", target_infer_cnt);
            printf("  有效识别总帧数：%d（置信≥%.2f）\n", valid_total, TARGET_CONF_THRESH);
            printf("  -----------------------------------\n");
            printf("  各类别有效票数统计：\n");
            printf("    📦 物资(materials)：%d 票\n", target_vote[0]);
            printf("    🚗 载具(traffic)：  %d 票\n", target_vote[1]);
            printf("    🔫 武器(weapon)：   %d 票\n", target_vote[2]);
            printf("  -----------------------------------\n");
            printf("  最终识别结果：%s\n", class_labels[target_final_class]);
            printf("  绕行执行模式：%d（0右绕/1直行/2左绕）\n", avoid_obstacle_mode);
            printf("=====================================\n");

            // 重置搜索阶段
            search_stage = 0;
            first_red_start_y = 0;
        }
        else if (infer_result == 2 || infer_result == 3) // 误触/全无效：统一清空统计
        {
            // 清空所有识别与统计变量
            target_infer_cnt = 0;
            target_infer_done = false;
            memset(target_vote, 0, sizeof(target_vote));
            target_final_class = -1;
            infer_frame_speed = infer_frame_distance = infer_total_distance = infer_total_speed = 0.0f;
            
            // 打印对应提示
            printf(infer_result == 2 ? "\n⚠️ 识别误触，有效帧%d，清空统计\n" : "\nℹ️ 无有效识别帧，清空统计\n", valid_total);
            
            // 重置搜索阶段
            search_stage = 0;
            first_red_start_y = 0;
        }

        // 当前帧无红色，重置搜索阶段
        if (!curr_red)
        {
            search_stage = 0;
            first_red_start_y = 0;
        }

        // 记录处理总耗时
        time_process = get_system_time_us() - t_process;
        image_time_stat.process_us = time_process;


        // ====================== 视觉巡线入口 ======================
        vision_process:
        
        // RGB565原图缩放为灰度图，作为巡线算法输入
        uint32_t t_gray = get_system_time_us();
        resize_and_gray_convert(rgb_image, gray_image[0], UVC_WIDTH, UVC_HEIGHT, GRAY_IMAGE_WIDTH, GRAY_IMAGE_HEIGHT);
        uint32_t time_to_gray = get_system_time_us() - t_gray;

        // 执行巡线核心算法：二值化、边界提取、中线拟合、转向计算
        uint32_t t_vision = get_system_time_us();
        vision_track_main((const uint8_t*)gray_image[0]);
        uint32_t time_vision = get_system_time_us() - t_vision;

        // ====================== TCP图像上传至逐飞助手 ======================
        uint32_t t3 = get_system_time_us();
        // 仅满足：发送模式不为关闭 且 当前帧计数%3==0 才执行图像发送
        if (send_image_mode != 3 && (send_frame_cnt % SEND_IMAGE_FRAME_INTERVAL  == 0))
        {
            // 根据当前发送模式配置上传参数
            switch(send_image_mode)
            {
                case 0: // 彩色原图模式
                    seekfree_assistant_camera_information_config(SEEKFREE_ASSISTANT_SCC8660, (uint8 *)image_copy, UVC_WIDTH, UVC_HEIGHT);
                    seekfree_assistant_camera_boundary_config(NO_BOUNDARY, 0, NULL, NULL, NULL, NULL, NULL, NULL);
                    break;
                case 1: // 压缩灰度图模式
                    seekfree_assistant_camera_information_config(SEEKFREE_ASSISTANT_MT9V03X, (uint8 *)gray_image, GRAY_IMAGE_WIDTH, GRAY_IMAGE_HEIGHT);
                    seekfree_assistant_camera_boundary_config(NO_BOUNDARY, 0, NULL, NULL, NULL, NULL, NULL, NULL);
                    break;
                case 2: // 二值图模式（需取消binary_image注释）
                    seekfree_assistant_camera_information_config(SEEKFREE_ASSISTANT_MT9V03X, (uint8 *)binary_image, GRAY_IMAGE_WIDTH, GRAY_IMAGE_HEIGHT);
                    draw_track_lines();
                    break;
                case 3: // 关闭图像上传
                    break;
                default:
                    break;
            }
            // 执行一次图像发送
            seekfree_assistant_camera_send();
        }    
            
            // 记录上传耗时与单帧总耗时
            image_time_stat.send_us = get_system_time_us() - t3;
            image_time_stat.total_us = get_system_time_us() - t1;


        // ===================== 斑马线触发：打印历史识别轮次 =====================
        static bool zebra_printed = false;
        if (is_zebra_detected && !zebra_printed)
        {
            zebra_printed = true;
            printf("\n===== 🚦 斑马线触发：历史识别轮次 =====\n");
            if (round_history_count == 0)
            {
                printf("  尚无任何完成的识别轮次\n");
            }
            else
            {
                for (int i = 0; i < round_history_count; i++)
                {
                    int cls = round_history[i];
                    if (cls >= 0 && cls < MODEL_OUTPUT_CLASS_NUM)
                        printf("  第%2d轮: %s\n", i+1, class_labels[cls]);
                    else
                        printf("  第%2d轮: 未知类别(%d)\n", i+1, cls);
                }
            }
            printf("  总计已完成识别轮数: %d\n", round_history_count);
            printf("================================================\n\n");
        }
        if (!is_zebra_detected)
        {
            zebra_printed = false;
        }


        // ====================== 按键扫描 ======================
        key_scan_all();

        // 累计程序运行总时长
        g_total_elapsed_us += image_time_stat.total_us;

        // 帧间延时，控制循环帧率，避免CPU占用过高
        system_delay_ms(2);
    }
}
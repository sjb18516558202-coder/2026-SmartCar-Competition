/*********************************************************************************************************************
* LS2K0300 Opensourec Library 即（LS2K0300 开源库）是一个基于官方 SDK 接口的第三方开源库
* Copyright (c) 2022 SEEKFREE 逐飞科技
*
* 文件功能实现：TCP示波器通信 + 独立PID调速调试循环
********************************************************************************************************************/
#include "tcp_client_oscilloscope_demo.hpp"

// 全局TCP客户端实例，全局作用域，所有函数可直接访问
zf_driver_tcp_client osc_tcp_client;

/**
 * @brief TCP发送包装函数，适配逐飞助手函数指针要求
 * @param buf 待发送数据缓冲区
 * @param len 数据长度
 * @return 实际发送字节数
 */
uint32 osc_tcp_send_wrap(const uint8 *buf, uint32 len)
{
    // 调用TCP类内置发送接口上传协议数据
    return osc_tcp_client.send_data(buf, len);
}

/**
 * @brief TCP接收包装函数，适配逐飞助手函数指针要求
 * @param buf 接收缓存
 * @param len 缓存最大长度
 * @return 实际读取字节数
 */
uint32 osc_tcp_read_wrap(uint8 *buf, uint32 len)
{
    // 调用TCP类内置读取接口接收上位机下发指令
    return osc_tcp_client.read_data(buf, len);
}

/**
 * @brief TCP示波器初始化：建立与电脑逐飞助手TCP Server连接
 * @return 0成功 / 1连接失败
 */
uint8 TcpOsc_Init(void)
{
    // 调用底层TCP初始化，传入IP与端口建立客户端连接
    int ret = osc_tcp_client.init(SERVER_IP, PORT);
    // 判断连接返回值，非0代表TCP握手失败
    if(ret != 0)
    {
        printf("[TCP示波器] TCP连接失败 IP:%s PORT:%d\r\n", SERVER_IP, PORT);
        return 1;
    }
    printf("[TCP示波器] TCP连接成功，上传左右轮PWM波形\r\n");

    // 将自定义TCP收发函数注册给逐飞助手协议层
    // 后续示波器发送、上位机指令解析都会走这套TCP接口
    seekfree_assistant_interface_init(osc_tcp_send_wrap, osc_tcp_read_wrap);
    return 0;
}

/**
 * @brief 读取左右轮输出PWM，封装成示波器协议并TCP上传
 */
void TcpOsc_SendPwmData(void)
{
    // 通道0赋值：当前帧左轮最终输出PWM（含PID、平滑、死区补偿后）
    seekfree_assistant_oscilloscope_data.data[CH_LEFT_PWM]  = diff_steer.left_pwm;
    // 通道1赋值：当前帧右轮最终输出PWM
    seekfree_assistant_oscilloscope_data.data[CH_RIGHT_PWM] = diff_steer.right_pwm;
    // 设置有效通道数量，告知上位机仅2路波形
    seekfree_assistant_oscilloscope_data.channel_num = CH_TOTAL;
    // 逐飞助手协议封装数据，通过TCP发送至上位机示波器界面
    seekfree_assistant_oscilloscope_send(&seekfree_assistant_oscilloscope_data);
    // 解析上位机下发的调参指令，支持在线修改PID、速度参数
    seekfree_assistant_data_analysis();
}


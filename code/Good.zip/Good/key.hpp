#ifndef __KEY_HPP
#define __KEY_HPP

#include "zf_common_headfile.hpp"

// ==================================================
// 按键硬件GPIO引脚定义
// 说明：映射开发板物理按键对应的SDK引脚宏，统一管理硬件连接
// ==================================================
#define KEY_1_PATH        ZF_GPIO_KEY_1   // KEY1 确认按键：GPA5 P80 S6
#define KEY_2_PATH        ZF_GPIO_KEY_2   // KEY2 功能选择位2：GPA4 P79 S5
#define KEY_3_PATH        ZF_GPIO_KEY_3   // KEY3 功能选择位3：GPA4 P78 S4
#define KEY_4_PATH        ZF_GPIO_KEY_4   // KEY4 功能选择位4：GPA4 P77 S3

// 按键GPIO对象外部声明，供其他文件调用
extern zf_driver_gpio  key_1;
extern zf_driver_gpio  key_2;
extern zf_driver_gpio  key_3;
extern zf_driver_gpio  key_4;

// ==================================================
// 功能状态变量（独立赋值模式，0=关闭 / 1=开启）
// 说明：替代原来的位掩码，每个功能单独用一个uint8变量存储状态
//      初始默认全部为0（关闭），按键触发时通过赋值翻转 0↔1
// ==================================================
extern uint8 esc_run_en;     // 电调运行总使能，对应按键组合 001
extern uint8 recog_en;       // 视觉识别/裁剪/推理使能，对应按键组合 010
extern uint8 car_run_en;     // 小车自动循迹启动，对应按键组合 100


extern bool car_wait_esc;    // true  → 倒计时被阻塞，直到电调进入 ESC_RUNNING 状态
                             // false → 倒计时立即开始，不依赖电调状态


// ==================================================
// 按键逻辑缓存结构体
// 说明：保存按键的逻辑状态，和硬件实时电平做区分
//      KEY2/3/4 用于选择功能组合，点按翻转逻辑值
// ==================================================
typedef struct
{
    uint8 key1_level;   // KEY1 实时硬件电平，1=未按下，0=按下
    uint8 key2_level;   // KEY2 逻辑缓存状态，0=未选中，1=选中
    uint8 key3_level;   // KEY3 逻辑缓存状态，0=未选中，1=选中
    uint8 key4_level;   // KEY4 逻辑缓存状态，0=未选中，1=选中
} KeyState_t;
extern KeyState_t key_cache;  // 全局按键缓存对象

// ==================================================
// 对外函数声明
// ==================================================
/**
 * @brief 按键硬件初始化
 * @note  GPIO驱动类构造函数已自动完成IO初始化，本函数预留扩展接口
 */
void key_init(void);

/**
 * @brief 全按键统一扫描入口，需在主循环周期调用
 * @desc  完成硬件电平读取、边沿检测、软件消抖、逻辑翻转、长按计时
 */
void key_scan_all(void);

/**
 * @brief KEY1确认按键核心处理逻辑
 * @param curr_key1 当前KEY1硬件电平
 * @desc  抬起时判定长短按：短按执行功能切换，长按清空全部功能并停机
 */
void key_handle_confirm(uint8 curr_key1);

/**
 * @brief KEY2逻辑状态翻转 0 <-> 1
 */
void key_toggle_2(void);

/**
 * @brief KEY3逻辑状态翻转 0 <-> 1
 */
void key_toggle_3(void);

/**
 * @brief KEY4逻辑状态翻转 0 <-> 1
 */
void key_toggle_4(void);

/**
 * @brief 清空KEY2/3/4逻辑缓存，恢复默认0
 * @note  每次确认执行功能后自动调用，避免状态残留
 */
void key_clear_func_keys(void);

/**
 * @brief 调试打印：所有按键实时电平与逻辑缓存状态
 */
void key_print_state(void);

/**
 * @brief 调试打印：当前已启用的全部功能状态
 */
void key_print_func_status(void);

// ==================================================
// 功能快速判断宏（业务层直接调用）
// 说明：宏本质是编译期文本替换，只做状态读取判断，不能赋值
//      业务代码写 if(IS_ESC_RUNNING()) 即可，可读性更强
// ==================================================
#define IS_ESC_RUNNING()    (esc_run_en == 1)   // 电调是否开启
#define IS_RECOG_ENABLE()   (recog_en == 1)     // 视觉识别是否开启
#define IS_CAR_RUNNING()    (car_run_en == 1)   // 小车是否启动

#endif
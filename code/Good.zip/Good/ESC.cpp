/* ================================================================
 * 包含头文件
 * ================================================================ */
#include "ESC.hpp"

/* ================================================================
 * 静态变量（仅本文件可见）
 * ================================================================ */

/**
 * @brief PWM设备实例
 * @note  使用 zf_driver_pwm 类封装底层PWM硬件操作，
 *        构造函数传入通道号，自动完成初始化。
 */
static zf_driver_pwm esc_pwm(ESC_PWM_CHANNEL);

/**
 * @brief 电调当前状态机状态
 * @note  使用 static 限定，确保只有本文件的函数能够修改，
 *        防止外部随意篡改导致状态混乱。
 */
static ESC_StateTypeDef esc_state = ESC_STOP;

/**
 * @brief 状态计时时间戳（单位：毫秒）
 * @note  用于延时等待和计时，每次进入需要计时的状态时，
 *        会记录当前系统时间（get_system_time_ms()）到该变量。
 */
static uint32_t esc_tick = 0;

/**
 * @brief 当前实际输出的PWM占空比
 * @note  用于记录和调试，与硬件输出保持同步。
 */
static uint16_t esc_current_duty = ESC_DUTY_STOP;

/**
 * @brief 步进加速过程中的当前占空比数值
 * @note  从0开始，每次调用ESC_Task增加 ESC_STEP_INCREMENT，
 *        直到达到 ESC_DUTY_TARGET 后转入运行状态。
 */
static uint16_t ramp_duty = 0;

/* ================================================================
 * 函数实现
 * ================================================================ */

/**
 * @brief 电调初始化
 * @note 上电时执行一次，将PWM输出设为停机占空比，
 *       状态设为停机，并重置加速计数器。
 */
void ESC_Init(void)
{
    /* 设置PWM为停机占空比（500），确保上电时电机不转 */
    esc_pwm.set_duty(ESC_DUTY_STOP);
    
    /* 同步当前占空比记录 */
    esc_current_duty = ESC_DUTY_STOP;
    
    /* 状态机初始化为停机状态 */
    esc_state = ESC_STOP;
    
    /* 清零加速占空比，防止残留数值 */
    ramp_duty = 0;
    
    /* 串口输出调试信息，确认初始化完成 */
    printf("[ESC] 电调初始化完成，默认停机\r\n");
}

/**
 * @brief 电调启停切换函数（按键触发）
 * @note  功能逻辑：
 *        - 若当前为停机状态 → 触发启动流程（进入等待延时）
 *        - 若当前为非停机状态（延时/加速/运行）→ 立即强制停止
 * @warning 启动过程中若再次按动按键，会立即停止，符合安全预期。
 */
void ESC_Toggle(void)
{
    if (esc_state == ESC_STOP)
    {
        /* ---------- 当前是停机状态，执行启动流程 ---------- */
        /* 切换到“等待延时”状态，电机仍保持停机 */
        esc_state = ESC_WAIT_DELAY;
        
        /* 记录当前系统时间，用于计算1秒延时是否到达 */
        esc_tick = get_system_time_ms();
        
        /* 重置加速占空比，确保每次启动都从0开始 */
        ramp_duty = 0;
        
        printf("[ESC] 开始1秒启动延时\r\n");
    }
    else
    {
        /* ---------- 当前正在运行或处于启动流程中，执行停止 ---------- */
        /* 状态强制设为停机 */
        esc_state = ESC_STOP;
        
        /* 立即输出停机占空比，让电机停转 */
        esc_pwm.set_duty(ESC_DUTY_STOP);
        esc_current_duty = ESC_DUTY_STOP;
        
        /* 清零加速计数，为下次启动做准备 */
        ramp_duty = 0;
        
        printf("[ESC] 电调已停止\r\n");
    }
}

/**
 * @brief 获取当前电调状态
 * @return 当前状态枚举值
 */
ESC_StateTypeDef ESC_GetState(void)
{
    return esc_state;
}

/**
 * @brief 电调主状态机任务函数
 * @param steer_angle_deg  传入的角度偏差（单位：度）
 * @note  本版本在正常运行状态下完全忽略此参数，只输出固定转速。
 *        保留参数仅为兼容原有接口，不影响功能。
 * 
 * @note  该函数必须在主循环中以固定周期（如1ms或10ms）被调用，
 *        因为步进加速的速率依赖于调用频率。
 *        例如：若每1ms调用一次，则每步增加10，达到目标需 (700/10)=70步，
 *        即约70ms完成加速。
 */
void ESC_Task(void)
{
    /* 根据当前状态执行不同逻辑 */
    switch (esc_state)
    {
        /* ==================================================
         * 状态 0：ESC_STOP（停机）
         * 行为：持续输出停机占空比（500），电机不转。
         * 用途：上电初始、按键停止、异常保护。
         * ================================================== */
        case ESC_STOP:
            esc_pwm.set_duty(ESC_DUTY_STOP);
            esc_current_duty = ESC_DUTY_STOP;
            break;

        /* ==================================================
         * 状态 1：ESC_WAIT_DELAY（等待启动延时）
         * 行为：保持停机输出，同时计时是否达到 ESC_START_DELAY_MS（1秒）。
         * 用途：避免按键按下瞬间立即启动，给操作者反应时间，同时保护电调。
         * 转换：时间到 → 自动转入 ESC_RAMPING（步进加速）状态。
         * ================================================== */
        case ESC_WAIT_DELAY:
            /* 延时期间始终输出停机占空比 */
            esc_pwm.set_duty(ESC_DUTY_STOP);
            
            /* 判断从进入本状态开始是否已满1秒 */
            if (get_system_time_ms() - esc_tick >= ESC_START_DELAY_MS)
            {
                /* 延时结束，切换到加速状态 */
                esc_state = ESC_RAMPING;
                
                /* 可选：重新记录时间戳（本版本加速阶段不使用时间，仅作占位）*/
                esc_tick = get_system_time_ms();
                
                /* 重置加速占空比（从0开始） */
                ramp_duty = 0;
                
                printf("[ESC] 延时结束，进入步进加速\r\n");
            }
            break;

        /* ==================================================
         * 状态 2：ESC_RAMPING（步进加速阶段）
         * 行为：每次调用本函数，将 ramp_duty 增加 ESC_STEP_INCREMENT（10），
         *       并输出到PWM，直到 ramp_duty ≥ ESC_DUTY_TARGET（700）。
         * 转换：达到或超过目标值 → 钳位为 EXACT 目标值，转入 ESC_RUNNING。
         * 注意：加速快慢由主循环调用频率决定，与步长共同决定。
         * ================================================== */
        case ESC_RAMPING:
            /* 步进增加占空比 */
            ramp_duty += ESC_STEP_INCREMENT;
            
            /* 判断是否达到或超过目标值 */
            if (ramp_duty >= ESC_DUTY_TARGET)
            {
                /* 钳位到精确的目标值，避免超调 */
                ramp_duty = ESC_DUTY_TARGET;
                
                /* 切换到正常运行状态 */
                esc_state = ESC_RUNNING;
                
                beep_single_ring(200);
                printf("[ESC] 加速完成，占空比 = %d，进入固定转速模式\r\n", ramp_duty);
            }
            
            /* 将当前加速占空比输出到PWM硬件 */
            esc_pwm.set_duty(ramp_duty);
            esc_current_duty = ramp_duty;
            break;

        /* ==================================================
         * 状态 3：ESC_RUNNING（正常运行）
         * 行为：固定输出 ESC_DUTY_TARGET（700），保持不变。
         * 用途：小车匀速前进，不受角度干扰（即不自动调速）。
         * ================================================== */
        case ESC_RUNNING:
            /* 持续输出目标占空比 */
            esc_pwm.set_duty(ESC_DUTY_TARGET);
            esc_current_duty = ESC_DUTY_TARGET;
            break;

        /* ==================================================
         * 默认分支（异常保护）
         * 如果状态机因意外跳转到未知值，强制回到停机状态。
         * ================================================== */
        default:
            esc_state = ESC_STOP;
            esc_pwm.set_duty(ESC_DUTY_STOP);
            esc_current_duty = ESC_DUTY_STOP;
            break;
    }
}

/**
 * @brief 强制停机函数（最高优先级）
 * @note  任何时候调用本函数，都会立即停止电调输出，
 *        并重置状态机到停机状态，无论当前处于何种状态。
 *        常用于紧急刹车、故障保护、长按复位等场景。
 */
void ESC_Stop(void)
{
    /* 强制状态机切换到停机 */
    esc_state = ESC_STOP;
    
    /* 立即输出停机占空比 */
    esc_pwm.set_duty(ESC_DUTY_STOP);
    esc_current_duty = ESC_DUTY_STOP;
    
    /* 清零加速计数，为下次启动准备 */
    ramp_duty = 0;
    
    printf("[ESC] 电调已强制停止\r\n");
}
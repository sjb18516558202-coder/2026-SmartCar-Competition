#include "CustomFunction.hpp"

//自定义函数

// 求绝对值
int Abs(int value)
{
    return (value >= 0) ? value : -value;
}

long Abs_long(long value)
{
    return (value >= 0) ? value : -value;
}

float Abs_float(float value)
{
    return (value >= 0) ? value : -value;
}


// 限幅函数
float Limit_float(float min, float value, float max)
{
    if(value < min)
    {
        return min;
    }
    else if(value > max)
    {
        return max;
    }
    else
    {
        return value;
    }
}
float Limit_int(int min, int value, int max)
{
    if(value < min)
    {
        return min;
    }
    else if(value > max)
    {
        return max;
    }
    else
    {
        return value;
    }
}

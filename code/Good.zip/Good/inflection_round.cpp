/******************************************************************************************
 * @file           inflection_round.cpp
 * @brief          视觉环岛检测模块 实现文件
 * @details        100%严格实现【环岛1.2手写规则】
 *                 核心功能：中拐点检测、5条件进环判定、状态机、边界补线/拉线
 * @rule           环岛1.2规则：一次判定成功，永久锁状态，单向流转
 ******************************************************************************************/
#include "inflection_round.hpp"
#include <string.h>    // 内存操作函数：memset(清空数据)
#include <stdio.h>     // 打印函数：调试日志输出
#include "inflection_detect.hpp"  // 边界/拐点数据依赖

/******************************************************************************************
 * @brief 日志打印宏封装（根据开关自动开启/关闭）
 ******************************************************************************************/
#if ROUND_LOG_ENABLE
  #define ROUND_LOG(format, ...)      printf("[ROUND-LOG] " format "\r\n", ##__VA_ARGS__)
  #define ROUND_DEBUG(format, ...)    printf("[ROUND-DEBUG] " format "\r\n", ##__VA_ARGS__)
  #define ROUND_WARN(format, ...)     printf("[ROUND-WARN] " format "\r\n", ##__VA_ARGS__)
#else
  // 关闭日志：所有打印宏替换为空，不占用运行资源
  #define ROUND_LOG(...)
  #define ROUND_DEBUG(...)
  #define ROUND_WARN(...)
#endif

/******************************************************************************************
 * @brief 全局静态变量（仅本文件可见，保护数据安全）
 ******************************************************************************************/
TrackState_E track_state = NORMAL_TRACK;     // 初始状态：普通赛道
RoundStage_E round_stage = ROUND_STAGE_DIRECT;// 初始阶段：直道进环
RoundMidPoint_t round_mid = {0};             // 初始中拐点：无效(全0)
static uint8_t mutation_row = 0;            // 弯道突变点行号：初始0(无效)

/******************************************************************************************
 * @brief 函数前置声明（先声明，后定义，解决函数调用顺序问题）
 ******************************************************************************************/
// 计算中拐点搜索范围（严格按环岛1.2规则）
static void calc_mid_search_range(uint8_t main_upper, uint8_t main_lower, uint8_t *out_start, uint8_t *out_end);
// 寻找环岛中拐点（核心函数）
static void find_round_mid(uint8_t *main_line, uint8_t start, uint8_t end, uint8_t upper, uint8_t lower, bool is_right_round);

/******************************************************************************************
 * @brief  连续丢线检测函数（环岛1.2规则-条件四）
 * @param  line:     待检测边界数组(左/右边界)
 * @param  start:    检测起始行
 * @param  end:      检测结束行
 * @param  lost_val: 丢线值：左丢线=0，右丢线=159
 * @param  cnt:      要求连续丢线的行数
 * @return bool:     true=满足条件；false=不满足
 * @note   逐行扫描，达到连续丢线行数立即返回，提升效率
 ******************************************************************************************/
static bool is_continuous_lost(uint8_t *line, uint8_t start, uint8_t end, uint8_t lost_val, uint8_t cnt)
{
    ROUND_DEBUG("开始连续丢线检测：区间[%d-%d]，目标连续%d行", start, end, cnt);
    // 非法判断：起始行 >= 结束行，直接返回不满足
    if(start >= end) return false;
    uint8_t cnt_cur = 0;  // 当前连续丢线计数器

    // 逐行遍历检测区间
    for(uint8_t r=start; r<=end; r++)
    {
        // 当前行是丢线点 → 计数器+1
        if(line[r] == lost_val) cnt_cur++;
        // 当前行是有效边界点 → 计数器清零（连续中断）
        else cnt_cur = 0;

        // 连续丢线达到要求 → 立即返回成功
        if(cnt_cur >= cnt) {
            ROUND_DEBUG("连续丢线检测成功！满足连续%d行", cnt);
            return true;
        }
    }
    // 遍历完成，未达到连续丢线要求
    ROUND_WARN("连续丢线检测失败！未达到连续%d行", cnt);
    return false;
}

/******************************************************************************************
 * @brief  边界稳定性检测函数（环岛1.2规则-条件五）
 * @param  line:   待检测边界数组
 * @param  start:  检测起始行
 * @param  end:    检测结束行
 * @return bool:   true=稳定；false=跳变
 * @note   相邻两行边界差值超过阈值，判定为不稳定（跳变）
 ******************************************************************************************/
static bool is_segment_stable(uint8_t *line, uint8_t start, uint8_t end)
{
    ROUND_DEBUG("开始边界稳定性检测：区间[%d-%d]", start, end);
    // 非法判断：区间无效，默认稳定
    if(start >= end) return true;
    // 遍历相邻行，检测差值
    for(uint8_t r=start; r<end; r++)
    {
        // 相邻行边界差值超过稳定阈值 → 不稳定
        if(abs((int)line[r]-line[r+1]) > STABLE_DIFF_THRESH)
        {
            ROUND_WARN("边界稳定性检测失败：行%d边界跳变", r);
            return false;
        }
    }
    ROUND_DEBUG("边界稳定性检测成功：区间[%d-%d]平稳", start, end);
    return true;
}

/******************************************************************************************
 * @brief  【准备进入环岛】5条件判定函数
 * @rule   条件一：单边界(仅下拐点 或 上下拐点都有)，另一边界无拐点
 * @rule   逐级判断，不满足立即退出；判定成功锁定状态，不再检测
 * @rule   判定成功 → 强制进入直道进环岛状态
 * @note   无goto语句，符合嵌入式/智能车编码规范
 ******************************************************************************************/
static void check_round_ready(void)
{
    ROUND_LOG("===== 【准备进入环岛】5条件逐级检测 =====");

    // 规则：判定成功后不需要再次判定 → 非普通赛道直接退出
    if (track_state != NORMAL_TRACK)
    {
        ROUND_DEBUG("已完成环岛判定，跳过检测");
        return;
    }

    // 获取左右边界的上、下拐点
    uint8_t lu = inflect_final_row[INFLECT_LEFT_UPPER];   // 左 上拐点
    uint8_t ll = inflect_final_row[INFLECT_LEFT_LOWER];    // 左 下拐点
    uint8_t ru = inflect_final_row[INFLECT_RIGHT_UPPER];  // 右 上拐点
    uint8_t rl = inflect_final_row[INFLECT_RIGHT_LOWER];  // 右 下拐点
    ROUND_DEBUG("拐点信息：左上=%d | 左下=%d | 右上=%d | 右下=%d", lu, ll, ru, rl);

    // 条件二：计算最低行(119)到搜索截止行的行数
    int dist = 119 - search_cutoff_row;
    ROUND_DEBUG("底部有效距离：%d行", dist);

// ========================== 左环岛判定（拆分情况1+情况2）==========================
    // 左环岛 情况1：左边界有下拐点，右边界无任何拐点
    if( (ll != 0) && (ru == 0 && rl == 0) )
    {
        ROUND_LOG("左环岛：进入判定情况1（存在下拐点）");
        // 条件二：搜索截止行距离 ≥ 阈值(80行)
        if(dist >= ROUND_CUTOFF_DIST)
        {
            ROUND_LOG("左环岛：条件二 满足");
            // 计算中拐点搜索范围 + 寻找左环岛中拐点
            uint8_t start_left, end_left;
            calc_mid_search_range(lu, ll, &start_left, &end_left);
            find_round_mid(left_line_list, start_left, end_left, lu, ll, false);

            // 条件三：找到有效中拐点 + 中下拐点行差 ≥ 设定值
            int row_diff_left = ll - round_mid.row;
            if(round_mid.valid && row_diff_left >= ROUND_INFLECT_ROW_DIFF)
            {
                ROUND_LOG("左环岛：条件三 满足");
                // 条件四：中下拐点之间连续指定行数丢线（左边界丢线=0）
                if(is_continuous_lost(left_line_list, round_mid.row, ll, 0, ROUND_LOST_LINE_COUNT))
                {
                    ROUND_LOG("左环岛：条件四 满足");
                    // 条件五：另一边界(右边界) 行段稳定
                    if(is_segment_stable(right_line_list, round_mid.row, ll))
                    {
                        ROUND_LOG("左环岛：条件五 满足");
                        track_state = LEFT_ROUND;
                        round_stage = ROUND_STAGE_DIRECT;
                        ROUND_LOG("========== 左环岛判定成功 → 进入直道进环岛 ==========");
                        return;
                    }
                    else
                    {
                        ROUND_WARN("左环岛：条件五不满足(右边界不稳定)，退出判定");
                    }
                }
                else
                {
                    ROUND_WARN("左环岛：条件四不满足(无连续丢线)，退出判定");
                }
            }
            else
            {
                ROUND_WARN("左环岛：条件三不满足(无中拐点/行差不足)，退出判定");
            }
        }
        else
        {
            ROUND_WARN("左环岛：条件二不满足(距离不足)，退出判定");
        }
    }
    // 左环岛 情况2：左边界只有上拐点、无下拐点，右边界无任何拐点
    else if( (lu != 0 && ll == 0) && (ru == 0 && rl == 0) )
    {
        ROUND_LOG("左环岛：进入判定情况2（仅存在上拐点）");
        // 情况2额外限制：上拐点行号小于限定值才有效
        if(lu >= ROUND_CASE2_UPPER_LIMIT)
        {
            ROUND_WARN("左环岛情况2：上拐点行号超限，判定无效");
        }
        // 条件二距离判定
        else if(dist >= ROUND_CUTOFF_DIST)
        {
            ROUND_LOG("左环岛：条件二 满足");
            uint8_t start_left, end_left;
            calc_mid_search_range(lu, ll, &start_left, &end_left);
            find_round_mid(left_line_list, start_left, end_left, lu, ll, false);

            // 条件三：上拐点与中拐点行差值达标
            int row_diff_left_up =  round_mid.row - lu;
            if(round_mid.valid && row_diff_left_up >= ROUND_CASE2_UP_MID_DIFF)
            {
                ROUND_LOG("左环岛：情况2条件三 满足");
                // 条件四：上拐点~中拐点区间连续丢线
                if(is_continuous_lost(left_line_list, round_mid.row, 119, 0, ROUND_CASE2_LOST_ROW_CNT))
                {
                    ROUND_LOG("左环岛：情况2条件四 满足");
                    // 条件五：对应区间右边界稳定
                    if(is_segment_stable(right_line_list, round_mid.row, lu))
                    {
                        ROUND_LOG("左环岛：情况2条件五 满足");
                        track_state = LEFT_ROUND;
                        round_stage = ROUND_STAGE_DIRECT;
                        ROUND_LOG("========== 左环岛情况2判定成功 → 进入直道进环岛 ==========");
                        return;
                    }
                    else
                    {
                        ROUND_WARN("左环岛：条件五不满足(右边界不稳定)，退出判定");
                    }
                }
                else
                {
                    ROUND_WARN("左环岛：条件四不满足(无连续丢线)，退出判定");
                }
            }
            else
            {
                ROUND_WARN("左环岛：条件三不满足(无中拐点/行差不足)，退出判定");
            }
        }
        else
        {
            ROUND_WARN("左环岛：条件二不满足(距离不足)，退出判定");
        }
    }

// ========================== 右环岛判定（拆分情况1+情况2）==========================
    // 右环岛 情况1：右边界有下拐点，左边界无任何拐点
    if( (rl != 0) && (lu == 0 && ll == 0) )
    {
        ROUND_LOG("右环岛：进入判定情况1（存在下拐点）");
        if(dist >= ROUND_CUTOFF_DIST)
        {
            ROUND_LOG("右环岛：条件二 满足");
            uint8_t start_right, end_right;
            calc_mid_search_range(ru, rl, &start_right, &end_right);
            find_round_mid(right_line_list, start_right, end_right, ru, rl, true);

            int row_diff_right = rl - round_mid.row;
            if(round_mid.valid && row_diff_right >= ROUND_INFLECT_ROW_DIFF)
            {
                ROUND_LOG("右环岛：条件三 满足");
                if(is_continuous_lost(right_line_list, round_mid.row, rl, 159, ROUND_LOST_LINE_COUNT))
                {
                    ROUND_LOG("右环岛：条件四 满足");
                    if(is_segment_stable(left_line_list, round_mid.row, rl))
                    {
                        ROUND_LOG("右环岛：条件五 满足");
                        track_state = RIGHT_ROUND;
                        round_stage = ROUND_STAGE_DIRECT;
                        ROUND_LOG("========== 右环岛判定成功 → 进入直道进环岛 ==========");
                        return;
                    }
                    else
                    {
                        ROUND_WARN("右环岛：条件五不满足(左边界不稳定)，退出判定");
                    }
                }
                else
                {
                    ROUND_WARN("右环岛：条件四不满足(无连续丢线)，退出判定");
                }
            }
            else
            {
                ROUND_WARN("右环岛：条件三不满足(无中拐点/行差不足)，退出判定");
            }
        }
        else
        {
            ROUND_WARN("右环岛：条件二不满足(距离不足)，退出判定");
        }
    }
    // 右环岛 情况2：右边界只有上拐点、无下拐点，左边界无任何拐点
    else if( (ru != 0 && rl == 0) && (lu == 0 && ll == 0) )
    {
        ROUND_LOG("右环岛：进入判定情况2（仅存在上拐点）");
        // 情况2上拐点行号限制
        if(ru >= ROUND_CASE2_UPPER_LIMIT)
        {
            ROUND_WARN("右环岛情况2：上拐点行号超限，判定无效");
        }
        else if(dist >= ROUND_CUTOFF_DIST)
        {
            ROUND_LOG("右环岛：条件二 满足");
            uint8_t start_right, end_right;
            calc_mid_search_range(ru, rl, &start_right, &end_right);
            find_round_mid(right_line_list, start_right, end_right, ru, rl, true);

            // 情况2上拐点-中拐点行差判定
            int row_diff_right_up = round_mid.row - ru;
            if(round_mid.valid && row_diff_right_up >= ROUND_CASE2_UP_MID_DIFF)
            {
                ROUND_LOG("右环岛：情况2条件三 满足");
                // 上拐点至中拐点区间丢线判定
                if(is_continuous_lost(right_line_list, round_mid.row, 119, 159, ROUND_CASE2_LOST_ROW_CNT))
                {
                    ROUND_LOG("右环岛：情况2条件四 满足");
                    // 对应区间左边界稳定判定
                    if(is_segment_stable(left_line_list, round_mid.row, ru))
                    {
                        ROUND_LOG("右环岛：情况2条件五 满足");
                        track_state = RIGHT_ROUND;
                        round_stage = ROUND_STAGE_DIRECT;
                        ROUND_LOG("========== 右环岛情况2判定成功 → 进入直道进环岛 ==========");
                        return;
                    }
                    else
                    {
                        ROUND_WARN("右环岛：条件五不满足(左边界不稳定)，退出判定");
                    }
                }
                else
                {
                    ROUND_WARN("右环岛：条件四不满足(无连续丢线)，退出判定");
                }
            }
            else
            {
                ROUND_WARN("右环岛：条件三不满足(无中拐点/行差不足)，退出判定");
            }
        }
        else
        {
            ROUND_WARN("右环岛：条件二不满足(距离不足)，退出判定");
        }
    }

    // 左右环岛均不满足条件
    ROUND_DEBUG("未检测到符合条件的环岛，保持普通赛道");
}

/******************************************************************************************
 * @brief  计算中拐点搜索范围（环岛1.2规则-严格实现）
 * @param  main_upper: 主边界上拐点
 * @param  main_lower: 主边界下拐点
 * @param  out_start:  输出：搜索下限制（起始行）
 * @param  out_end:    输出：搜索上限制（结束行）
 * @rule   下限制：有有效下拐点=下拐点上一行；否则=119
 * @rule   上限制：有有效上拐点=上拐点下一行；否则=40
 * @rule   搜索范围向内缩进，下限制+5，上限制-5（N=5）
 ******************************************************************************************/


static void calc_mid_search_range(uint8_t main_upper, uint8_t main_lower, uint8_t *out_start, uint8_t *out_end)
{
    uint8_t temp_start, temp_end;

    // ===================== 计算原始搜索下限制 =====================
    if (main_lower != 0)
        // 下拐点行 < 60 → 无效，用119；否则用 下拐点-1（上一行）
        temp_start = (main_lower < INFLECTION_LOWER_VALID) ? MID_LOWER_DEFAULT : (main_lower - 1);
    else
        temp_start = MID_LOWER_DEFAULT; // 无下拐点 → 固定119行

    // ===================== 计算原始搜索上限制 =====================
    if (main_upper != 0)
        // 上拐点行 < 40 → 无效，用40；否则用 上拐点+1（下一行）
        temp_end = (main_upper < MID_UPPER_DEFAULT) ? MID_UPPER_DEFAULT : (main_upper + 1);
    else
        temp_end = MID_UPPER_DEFAULT; // 无上拐点 → 固定40行

    // ===================== 范围缩进：下限制+N，上限制-N =====================
    *out_start = temp_start - MID_SEARCH_OFFSET;
    *out_end   = temp_end + MID_SEARCH_OFFSET;

    // 安全保护：防止行号越界（start < end 才合法）
    if (*out_start >= 120) *out_start = 119;
    if (*out_end   <= 0)   *out_end   = 1;
    if (*out_start <= *out_end) {
        *out_start = temp_start;
        *out_end   = temp_end;
    }

    ROUND_DEBUG("原始范围：[%d-%d]，缩进N=%d → 最终中拐点搜索范围：[%d-%d]",
               temp_start, temp_end, MID_SEARCH_OFFSET, *out_start, *out_end);
}

/******************************************************************************************
 * @brief  寻找环岛中拐点（环岛1.2规则-核心基准点，新增相邻行平滑约束）
 * @param  main_line:      主边界数组
 * @param  start:          搜索起始行(下限制，数值大，靠近底部119)
 * @param  end:            搜索结束行(上限制，数值小，靠近图像上方)
 * @param  upper:          上拐点（禁止作为中拐点）
 * @param  lower:          下拐点（禁止作为中拐点）
 * @param  is_right_round: true=右环岛(找X最小)；false=左环岛(找X最大)
 * @rule1  遍历顺序：从下向上 r = start → end
 * @rule2  过滤：跳过等于上拐点/下拐点的行
 * @rule3  平滑约束：当前行与上一行、下一行边界差值 ≤ MID_POINT_NEIGHBOR_DIFF
 * @rule4  右环岛取区间内满足平滑的最小X；左环岛取满足平滑的最大X
 ******************************************************************************************/
static void find_round_mid(uint8_t *main_line, uint8_t start, uint8_t end, uint8_t upper, uint8_t lower, bool is_right_round)
{
    ROUND_DEBUG("开始搜索环岛中拐点：区间[%d-%d]，相邻波动阈值=%d", start, end, MID_POINT_NEIGHBOR_DIFF);
    memset(&round_mid, 0, sizeof(round_mid)); // 清空上一帧中拐点数据

    // 初始化极值缓存
    int best_x = is_right_round ? 160 : -1;
    uint8_t best_r = 0;

    // 从下向上遍历（行号由大到小，底部119往图像上方）
    for (int r = start; r >= (int)end; r--)
    {
        // 规则：中拐点不能是上下拐点本身，直接跳过
        if (r == upper || r == lower)
            continue;

        // 边界保护：防止r-1 / r+1越界（图像行0~119）
        int r_up   = r - 1;
        int r_down = r + 1;
        if (r_up < 0 || r_down > 119)
            continue;

        uint8_t curr_x  = main_line[r];
        uint8_t up_x     = main_line[r_up];
        uint8_t down_x   = main_line[r_down];

        // 相邻两行波动校验：上下相邻差值均不能超过阈值
        int diff_up   = abs((int)curr_x - up_x);
        int diff_down = abs((int)curr_x - down_x);
        if (diff_up > MID_POINT_NEIGHBOR_DIFF || diff_down > MID_POINT_NEIGHBOR_DIFF)
        {
            // 相邻跳变过大，不参与中拐点筛选
            continue;
        }

        // 满足平滑条件，参与极值筛选
        if (is_right_round)
        {
            // 右环岛：保留更小X
            if (curr_x < best_x)
            {
                best_x = curr_x;
                best_r = (uint8_t)r;
            }
        }
        else
        {
            // 左环岛：保留更大X
            if (curr_x > best_x)
            {
                best_x = curr_x;
                best_r = (uint8_t)r;
            }
        }
    }

    // 存在符合所有约束的中拐点
    if (best_r != 0)
    {
        round_mid.valid = 1;
        round_mid.row   = best_r;
        round_mid.x     = best_x;
        ROUND_DEBUG("找到有效平滑中拐点：行=%d X=%d", round_mid.row, round_mid.x);
    }
    else
    {
        ROUND_WARN("未找到满足相邻平滑约束的环岛中拐点");
    }
}

/******************************************************************************************
 * @brief  直道进环：主边界补线函数（环岛1.2规则）
 * @param  main_line:  主边界数组
 * @param  sub_line:   副边界数组
 * @param  main_lower: 主边界下拐点
 * @rule   有下拐点：两点法补线；无下拐点：镜像法补线(x=-ky+B)
 ******************************************************************************************/
static void fill_round_main_edge(uint8_t *main_line, uint8_t *sub_line, uint8_t main_lower)
{
    // 中拐点无效 → 不补线
    if (!round_mid.valid) {
        ROUND_WARN("主边界补线失败：中拐点无效");
        return;
    }
    ROUND_DEBUG("开始执行主边界补线");

    // ===================== 情况1：有下拐点 → 两点法补线 =====================
    if (main_lower != 0)
    {
        ROUND_DEBUG("主边界补线：两点法（中拐点→下拐点）");
        // 两点拟合直线：中拐点(x,y) + 下拐点(x,y)
        FitResult_t fit = two_point_fit(round_mid.x, round_mid.row, main_line[main_lower], main_lower);
        // 从中拐点行补线到下拐点行
        for (int r = round_mid.row; r <= main_lower; r++)
        {
            int x = (int)round(fit.k * r + fit.b);
            // 限制X在0~159，防止越界
            main_line[r] = (x<0) ? 0 : (x>159) ? 159 : x;
        }
    }
    // ===================== 情况2：无下拐点 → 镜像法补线 =====================
    else
    {
        ROUND_DEBUG("主边界补线：镜像法（无下拐点）");
        // 拟合副边界直线，获取斜率k
        FitResult_t sub_fit = two_point_fit(sub_line[round_mid.row], round_mid.row, sub_line[119], 119);
        // 镜像公式：x = -k*y + B → 计算截距B
        float B = round_mid.x + sub_fit.k * round_mid.row;
        // 从中拐点行补线到图像最底行
        for (int r = round_mid.row; r <= 119; r++)
        {
            int x = (int)round(-sub_fit.k * r + B);
            main_line[r] = (x<0) ? 0 : (x>159) ? 159 : x;
        }
    }
    ROUND_DEBUG("主边界补线完成");
}

/******************************************************************************************
 * @brief  直道进环：副边界拉线函数（环岛1.2规则）
 * @param  sub_line:    副边界数组
 * @param  main_upper:  主边界上拐点
 * @rule   有中拐点：上拐点+中拐点对应行拉线；无中拐点：上拐点+最底行拉线
 ******************************************************************************************/
static void draw_round_sub_edge(uint8_t *sub_line, uint8_t main_upper)
{
    // 无上拐点 → 不拉线
    if (main_upper == 0) {
        ROUND_WARN("副边界拉线失败：无上拐点");
        return;
    }
    ROUND_DEBUG("开始执行副边界拉线");

    // 上部拉线点：主边界上拐点坐标
    uint8_t y1 = main_upper;
    uint8_t x1 = (track_state == RIGHT_ROUND) ? right_line_list[y1] : left_line_list[y1];
    uint8_t y2, x2;

    // 下部拉线点：有中拐点用中拐点行，无中拐点用119行
    if (round_mid.valid) { y2 = round_mid.row; x2 = sub_line[y2]; }
    else { y2 = 119; x2 = sub_line[y2]; }

    // 两点拟合直线并拉线
    FitResult_t fit = two_point_fit(x1, y1, x2, y2);
    for (int y = y1; y <= y2; y++)
    {
        int val = (int)round(fit.k * y + fit.b);
        sub_line[y] = (val<0) ? 0 : (val>159) ? 159 : val;
    }
    ROUND_DEBUG("副边界拉线完成");
}

/******************************************************************************************
 * @brief  弯道进环：寻找突变点函数（环岛1.2规则）
 * @param  sub_line: 副边界数组
 * @return uint8_t:  1=找到；0=未找到
 * @rule   从下向上找：i行有效，i+1行丢线 → i行=突变点
 ******************************************************************************************/
static uint8_t find_round_mutation(uint8_t *sub_line)
{
    ROUND_DEBUG("开始搜索弯道突变点");
    mutation_row = 0;  // 重置突变点
    // 丢线值：右环岛=左边界丢线(0)；左环岛=右边界丢线(159)
    uint8_t lost_val = (track_state == RIGHT_ROUND) ? 0 : 159;

    // 从倒数第二行向上搜索
    for (int i = 118; i >= 0; i--)
    {
        bool curr_valid = (sub_line[i] != lost_val);   // 当前行有效
        bool next_lost  = (sub_line[i+1] == lost_val); // 下一行丢线
        // 满足规则 → 找到突变点
        if (curr_valid && next_lost)
        {
            mutation_row = i;
            ROUND_LOG("找到弯道突变点：行=%d", mutation_row);
            return 1;
        }
    }
    ROUND_WARN("未找到弯道突变点");
    return 0;
}

/******************************************************************************************
 * @brief  弯道进环：副边界拉线函数（环岛1.2规则）
 * @param  sub_line: 副边界数组
 * @rule   突变点 + 副边界最底点 → 两点法拉线
 ******************************************************************************************/
static void draw_curve_sub_edge(uint8_t *sub_line)
{
    // 无突变点 → 不拉线
    if (!mutation_row) {
        ROUND_WARN("弯道补线失败：无突变点");
        return;
    }
    ROUND_DEBUG("开始执行弯道副边界补线");

    // 两点拟合直线：突变点 + 最底行点
    FitResult_t fit = two_point_fit(sub_line[mutation_row], mutation_row, sub_line[119], 119);
    // 从突变点补线到最底行
    for (int r = mutation_row; r <= 119; r++)
    {
        int val = (int)round(fit.k * r + fit.b);
        sub_line[r] = (val<0) ? 0 : (val>159) ? 159 : val;
    }
    ROUND_DEBUG("弯道副边界补线完成");
}

/******************************************************************************************
 * @brief  环岛状态机总函数（环岛1.2规则-状态流转核心）
 * @rule   直道进环 → 弯道进环 → 完全进环 → 弯道出环岛 → 直道出环岛 → 退出环岛（单向不可逆）
 ******************************************************************************************/
static void round_process(void)
{
    ROUND_LOG("===== 启动环岛状态机处理 =====");
    // 根据环岛方向，自动分配主/副边界、拐点
    uint8_t *main_line = (track_state == RIGHT_ROUND) ? right_line_list : left_line_list;
    uint8_t *sub_line  = (track_state == RIGHT_ROUND) ? left_line_list  : right_line_list;
    uint8_t upper = (track_state == RIGHT_ROUND) ? inflect_final_row[INFLECT_RIGHT_UPPER] : inflect_final_row[INFLECT_LEFT_UPPER];
    uint8_t lower = (track_state == RIGHT_ROUND) ? inflect_final_row[INFLECT_RIGHT_LOWER] : inflect_final_row[INFLECT_LEFT_LOWER];
    // 新增：副边界下拐点（出环触发条件）
    uint8_t sub_lower = (track_state == RIGHT_ROUND) ? inflect_final_row[INFLECT_LEFT_LOWER] : inflect_final_row[INFLECT_RIGHT_LOWER];
    ROUND_DEBUG("当前状态：主上拐点=%d，主下拐点=%d，副下拐点=%d", upper, lower, sub_lower);

    // ===================== 阶段1：直道进环 =====================
    if (round_stage == ROUND_STAGE_DIRECT)
    {
        ROUND_LOG("当前阶段：直道进环");
        // 切换条件：主边界上拐点消失
        if (upper == 0)
        {
            bool switch_flag = false;
            // 有中拐点：判断X阈值
            if(round_mid.valid)
            {
                if((track_state==RIGHT_ROUND && round_mid.x>ROUND_MID_RIGHT_X_LIMIT) ||
                   (track_state==LEFT_ROUND  && round_mid.x<ROUND_MID_LEFT_X_LIMIT))
                    switch_flag = true;
            }
            // 无中拐点：直接切换
            else switch_flag = true;

            // 满足条件 → 切换到弯道进环，不再执行直道逻辑
            if(switch_flag)
            {
                round_stage = ROUND_STAGE_CURVE;
                ROUND_LOG("========== 切换至【弯道进环】阶段 ==========");
                return;
            }
        }

        // 直道进环标准流程
        uint8_t st, ed;
        calc_mid_search_range(upper, lower, &st, &ed);
        bool is_right_round = (track_state == RIGHT_ROUND);
        find_round_mid(main_line, st, ed, upper, lower, is_right_round);
        fill_round_main_edge(main_line, sub_line, lower);
        draw_round_sub_edge(sub_line, upper);
    }

    // ===================== 阶段2：弯道进环 =====================
    if (round_stage == ROUND_STAGE_CURVE)
    {
        ROUND_LOG("当前阶段：弯道进环");
        // 找到突变点 → 执行拉线
        if (find_round_mutation(sub_line))
        {
            draw_curve_sub_edge(sub_line);
        }
        // 未找到突变点 → 检测双边界稳定 → 进入完全进环状态
        else
        {
            // if (is_segment_stable(left_line_list, 0, 119) && is_segment_stable(right_line_list, 0, 119))
                round_stage = ROUND_STAGE_INSIDE; // 标记完全进环
                ROUND_LOG("========== 切换至【完全进环】阶段 ==========");
            
        }
    }

    // ===================== 阶段3：完全进环（新增）=====================
    if (round_stage == ROUND_STAGE_INSIDE)
    {
        ROUND_LOG("当前阶段：完全进环");
        // 环岛1.2规则：出现副边下拐点 → 进入弯道出环岛状态
        if (sub_lower != 0)
        {
            round_stage = ROUND_STAGE_EXIT_CURVE;
            ROUND_LOG("========== 检测到副边下拐点 → 切换至【弯道出环岛】阶段 ==========");
        }
    }

    // ===================== 阶段4：弯道出环岛 =====================
   if (round_stage == ROUND_STAGE_EXIT_CURVE)
    {
        ROUND_LOG("当前阶段：弯道出环岛");
        uint8_t cut_y = search_cutoff_row;
        uint8_t cut_x_raw = sub_line[cut_y];
        uint8_t line_up_x, line_up_y;

        // 1. 根据环岛方向生成拉线上端点(连接上点)
        if(track_state == RIGHT_ROUND)
        {
            // 右环岛：副边截止行X>80用原始点；小于80强制X=80
            if(cut_x_raw > ROUND_EXIT_X_LIMIT)
            {
                line_up_x = cut_x_raw;
            }
            else
            {
                line_up_x = ROUND_EXIT_X_LIMIT;
            }
            line_up_y = cut_y;
            ROUND_DEBUG("右环岛出环上端点：X=%d Y=%d，原始截止X=%d", line_up_x, line_up_y, cut_x_raw);
        }
        else // LEFT_ROUND 左环岛
        {
            // 左环岛：副边截止行X<80用原始点；大于80强制X=80
            if(cut_x_raw < ROUND_EXIT_X_LIMIT)
            {
                line_up_x = cut_x_raw;
            }
            else
            {
                line_up_x = ROUND_EXIT_X_LIMIT;
            }
            line_up_y = cut_y;
            ROUND_DEBUG("左环岛出环上端点：X=%d Y=%d，原始截止X=%d", line_up_x, line_up_y, cut_x_raw);
        }

        FitResult_t sub_fit;
        uint8_t line_down_x, line_down_y;
        // 2. 区分有无副边下拐点，选择下端点
        if (sub_lower != 0)
        {
            // 有副边下拐点：下端点=副边下拐点
            line_down_y = sub_lower;
            line_down_x = sub_line[sub_lower];
            sub_fit = two_point_fit(line_up_x, line_up_y, line_down_x, line_down_y);
            ROUND_DEBUG("弯道出环：副边下拐点+规则上端点 两点拟合");
        }
        else
        {
            // 无副边下拐点：下端点=图像最底行119
            line_down_y = 119;
            line_down_x = sub_line[119];
            sub_fit = two_point_fit(line_up_x, line_up_y, line_down_x, line_down_y);
            ROUND_DEBUG("弯道出环：副边底点+规则上端点 两点拟合");
        }

        // 3. 两点法完整拉线：从下端点到上端点区间填充副边界
        if (sub_fit.valid)
        {
            uint8_t r_start = (line_down_y < line_up_y) ? line_down_y : line_up_y;
            uint8_t r_end   = (line_down_y > line_up_y) ? line_down_y : line_up_y;
            for (int r = r_start; r <= r_end; r++)
            {
                int val = (int)round(sub_fit.k * r + sub_fit.b);
                sub_line[r] = (val<0) ? 0 : (val>159) ? 159 : val;
            }
            ROUND_DEBUG("弯道出环副边界拉线完成，填充区间[%d,%d]", r_start, r_end);
        }
        else
        {
            ROUND_WARN("弯道出环岛两点拟合无效，跳过补线");
        }

        // 4. 状态切换判定：无副下拐点 + 存在主边上拐点 → 切直道出环
        if (sub_lower == 0 && upper != 0)
        {
            round_stage = ROUND_STAGE_EXIT_DIRECT;
            ROUND_LOG("========== 切换至【直道出环岛】阶段 ==========");
        }
    }


    // ===================== 阶段5：直道出环岛 =====================
    if (round_stage == ROUND_STAGE_EXIT_DIRECT)
    {
        ROUND_LOG("当前阶段：直道出环岛");
        // 环岛1.2规则：主边上拐点向上采集5个点，最小二乘法拟合，向下补到最底端
        if (upper != 0)
        {
            FitResult_t main_fit = least_square_fit(upper, 
                (track_state == RIGHT_ROUND) ? LINE_RIGHT : LINE_LEFT, 
                TRAVEL_UP);
            
            // 主边界补线：从上拐点向下补到最底端
            for (int r = upper; r <= 119; r++)
            {
                int val = (int)round(main_fit.k * r + main_fit.b);
                main_line[r] = (val<0) ? 0 : (val>159) ? 159 : val;
            }
            ROUND_DEBUG("直道出环：主边界最小二乘拟合补线完成");
        }

        // 环岛1.2规则：无拐点 → 退出环岛状态，恢复普通赛道
        if (upper == 0 && lower == 0 && sub_lower == 0)
        {
            track_state = NORMAL_TRACK;
            ROUND_LOG("========== 出环完成 → 恢复【普通赛道】 ==========");
        }
    }
}

/******************************************************************************************
 * @brief  环岛模块总入口（外部唯一调用函数）
 * @note   执行流程：条件判定 → 状态机处理 → 状态重置
 ******************************************************************************************/
void inflection_round_main(void)
{
    ROUND_LOG("=============================================");
    ROUND_LOG("           环岛视觉模块 开始运行             ");
    ROUND_LOG("=============================================");
    
    // 1. 执行环岛5条件判定
    check_round_ready();

    // 2. 环岛模式：执行状态机 + 补线 + 重计算中心线
    if (track_state != NORMAL_TRACK)
    {
        ROUND_LOG("进入环岛处理流程");
        uint8_t main_upper_y = (track_state==RIGHT_ROUND) ? inflect_final_row[INFLECT_RIGHT_UPPER] : inflect_final_row[INFLECT_LEFT_UPPER];
        // 更新拐点搜索截止行
        if (main_upper_y != 0) search_cutoff_row = main_upper_y;

        round_process();            // 执行状态机
        // recalculate_mid_line();     // 补线后重计算中心线
        ROUND_DEBUG("环岛处理完成，已重新计算中心线");
    }
    // 3. 普通赛道：重置所有环岛状态
    else
    {
        ROUND_LOG("普通赛道，重置环岛状态");
        round_stage = ROUND_STAGE_DIRECT;    // 重置阶段
        memset(&round_mid, 0, sizeof(round_mid)); // 清空中拐点
        mutation_row = 0;                    // 清空突变点
    }

    ROUND_LOG("=============================================\r\n");
}

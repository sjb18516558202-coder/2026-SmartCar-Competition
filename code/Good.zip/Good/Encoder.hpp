#ifndef _Encoder_hpp
#define _Encoder_hpp

#include "zf_common_headfile.hpp"  // 基础公共头文件（包含标准库、硬件驱动基础等）
#include "Motor.hpp"               // 电机控制相关头文件

// ===================== 编码器设备路径配置 =====================
// 编码器设备路径宏（与设备树节点名称匹配，不可随意修改）
#define ENCODER_L     ENCODER_QUAD_L  // 左编码器设备路径别名（简化代码书写）
#define ENCODER_R     ENCODER_QUAD_R  // 右编码器设备路径别名（简化代码书写）

// 正交编码器设备节点（对应Linux设备文件：/dev/zf_encoder_quad_x）
#define ENCODER_QUAD_L   ZF_ENCODER_QUAD_1  // 左正交编码器节点（硬件绑定，需匹配设备树）
#define ENCODER_QUAD_R   ZF_ENCODER_QUAD_2  // 右正交编码器节点（硬件绑定，需匹配设备树）

// 方向编码器设备节点（需修改设备树编译内核后启用，暂未使用）
#define ENCODER_DIR_L   ZF_ENCODER_DIR_1    // 左方向编码器节点（预留）
#define ENCODER_DIR_R   ZF_ENCODER_DIR_2    // 右方向编码器节点（预留）

// ===================== 硬件参数配置（核心，需按实际硬件修改）=====================
#define WHEEL_DIAMETER        6.4f       // 轮子直径（单位：cm），需用卡尺实测校准
#define WHEEL_CIRCUMFERENCE   (3.1415926f * WHEEL_DIAMETER)  // 轮子周长 = π×直径 ≈20.4203523cm

// 齿轮传动参数（齿轮齿数，需按实际机械结构填写）
#define ENCODER_GEAR_Z        30         // 编码器轴上的齿轮齿数（小齿轮）
#define WHEEL_GEAR_Z          68         // 轮子轴上的齿轮齿数（大齿轮）
#define MOTOR_GEAR_Z          16         // 电机轴上的齿轮齿数（当前里程计算未使用，预留）

// 传动比计算：轮子转1圈时，编码器需要转的圈数 = 轮子齿轮数 / 编码器齿轮数
// 物理意义：齿轮传动中，转数与齿数成反比（大齿轮带小齿轮，小齿轮转数更多）
#define WHEEL_TO_ENCODER_RATIO ((float)WHEEL_GEAR_Z / ENCODER_GEAR_Z)  // 68/30≈2.2667

// 编码器参数配置
#define ENCODER_PULSE_PER_REV  1024*2    // 编码器每圈输出脉冲数（1024线×2倍频，需按实际倍频配置）
#define SAMPLE_PERIOD_MS       10        // 编码器数据采样周期（单位：ms），建议10-20ms
#define SAMPLE_PERIOD_S        ((float)SAMPLE_PERIOD_MS / 1000.0f)  // 采样周期转换为秒：0.01s

// 核心公式：单脉冲对应轮子移动的距离（单位：cm/脉冲）
// 推导逻辑：
// 1. 轮子转1圈，编码器转 WHEEL_TO_ENCODER_RATIO 圈
// 2. 轮子转1圈，编码器输出脉冲数 = ENCODER_PULSE_PER_REV × WHEEL_TO_ENCODER_RATIO
// 3. 1个脉冲对应距离 = 轮子周长 / 编码器总脉冲数
#define PULSE_TO_CM           (WHEEL_CIRCUMFERENCE / (ENCODER_PULSE_PER_REV * WHEEL_TO_ENCODER_RATIO))


// 绕行行驶距离（单位：cm，可自行修改数值）
#define TARGET_NEED_RUN         60.0f
// 绕行已行驶距离
extern float target_avoid_distance;   

// ===================== 数据结构体定义 =====================
// 编码器数据结构体：整合单路电机+编码器的所有数据
typedef struct
{
    // 电机控制参数
    int target_speed;      // 电机目标速度（单位：cm/s），用于速度闭环控制
    int duty;              // 电机PWM占空比（-1000~1000），控制电机转速和方向

    // 编码器实时数据
    int16_t encoder_raw;   // 单次采样的脉冲增量（带符号，正/负代表轮子转动方向）
    float current_speed;   // 轮子当前实时速度（单位：cm/s），经低通滤波后的值

    // 编码器累计数据
    int32_t total_pulse;   // 编码器累计脉冲数（带符号，记录总转动量）
    float total_distance;  // 轮子累计行驶里程（单位：cm），正为前进，负为后退
    float total_run_time;  // 累计运行时间（单位：s），从初始化开始累加采样周期
    float avg_speed;       // 平均速度（单位：cm/s）= 累计里程 / 累计运行时间

} Motor_Encoder;

// ===================== 全局对象声明 =====================
extern zf_driver_encoder encoder_L_obj;  // 左编码器驱动对象（底层硬件操作）
extern zf_driver_encoder encoder_R_obj;  // 右编码器驱动对象（底层硬件操作）
extern Motor_Encoder motor_LE;           // 左电机+编码器数据结构体实例
extern Motor_Encoder motor_RE;           // 右电机+编码器数据结构体实例

// ===================== 函数声明 =====================
void Encoder_Init(void);                 // 编码器初始化：清零初始脉冲、重置累计数据
void Encoder_Update(void);               // 编码器数据更新：读取脉冲、计算速度/里程/平均速度
void Encoder_PrintData(void);            // 编码器数据打印：格式化输出调试信息
void Encoder_ResetTotalData(void);       // 重置累计数据：里程/时间/平均速度清零

extern bool is_avoid_finish;

#endif

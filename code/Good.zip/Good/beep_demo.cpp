#include "beep_demo.hpp"

// 实例化蜂鸣器GPIO驱动，读写模式
zf_driver_gpio  beep(BEEP_PATH, O_RDWR);

void beep_single_ring(uint32 on_ms)
{
    beep.set_level(1);
    system_delay_ms(on_ms);
    beep.set_level(0);
}
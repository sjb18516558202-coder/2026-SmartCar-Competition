/*********************************************************************************************************************
* LS2K0300 Opensourec Library 即（LS2K0300 开源库）是一个基于官方 SDK 接口的第三方开源库
* Copyright (c) 2022 SEEKFREE 逐飞科技
*
* 本文件功能：TCP示波器通信模块头文件
* 功能说明：
* 1. 建立TCP客户端连接电脑逐飞助手TCP服务端
* 2. 封装逐飞助手示波器协议，仅上传左右电机最终输出PWM双通道波形
* 3. 提供独立PID调速调试循环：给定PWM→速度PID闭环计算输出PWM→电机驱动→实时上传波形
********************************************************************************************************************/
#ifndef _TCP_CLIENT_OSCILLOSCOPE_DEMO_HPP_
#define _TCP_CLIENT_OSCILLOSCOPE_DEMO_HPP_

// 逐飞底层通用头文件，包含数据类型、系统延时、基础工具函数
#include "zf_common_headfile.hpp"
// 差速控制结构体、PWM速度转换宏、电机死区补偿宏、速度PID指针定义
#include "DiffSteering.hpp"
// 编码器全局结构体motor_LE/motor_RE、速度采样周期、脉冲距离转换宏
#include "Encoder.hpp"

// ===================== TCP网络配置宏（与官方TCP例程完全统一） =====================
// 电脑WiFi局域网IP地址，需根据本机WiFi修改
#define SERVER_IP    "192.168.3.23"
// TCP通信端口，逐飞助手服务端端口必须与此一致
#define PORT         8086

// ===================== 示波器通道枚举定义 =====================
/**
 * @brief 逐飞助手示波器通道分配
 * 仅使用双通道，专门传输电机输出PWM，减少网络传输负载
 */
enum OSC_CH
{
    CH_LEFT_PWM  = 0,    // 通道0：左轮电机最终输出PWM diff_steer.left_pwm
    CH_RIGHT_PWM = 1,    // 通道1：右轮电机最终输出PWM diff_steer.right_pwm
    CH_TOTAL     = 2     // 有效使用通道总数量，上传时赋值给channel_num
};

// 全局TCP客户端对象，封装TCP连接、发送、接收底层接口
extern zf_driver_tcp_client osc_tcp_client;

/**
 * @brief TCP发送包装函数
 * @param buf 待发送数据缓冲区指针
 * @param len 待发送数据字节长度
 * @return uint32 实际成功发送的字节数
 * @note 逐飞助手协议要求传入普通函数指针，封装类成员send_data做适配
 */
uint32 osc_tcp_send_wrap(const uint8 *buf, uint32 len);

/**
 * @brief TCP接收包装函数
 * @param buf 接收数据存放缓冲区指针
 * @param len 缓冲区最大可接收字节长度
 * @return uint32 实际读取到的数据长度
 * @note 适配逐飞助手回调函数指针，用于解析上位机下发调参指令
 */
uint32 osc_tcp_read_wrap(uint8 *buf, uint32 len);

/**
 * @brief TCP示波器初始化函数
 * @return uint8 0=初始化成功，非0=TCP连接失败
 * @流程：创建TCP连接→绑定逐飞助手通信收发接口
 */
uint8 TcpOsc_Init(void);

/**
 * @brief 填充双通道PWM数据并TCP上传至上位机示波器
 * @note 自动读取全局差速结构体中左右轮最终输出PWM，封装协议发送
 * 同时调用数据解析函数，处理上位机下发的在线调参指令
 */
void TcpOsc_SendPwmData(void);

#endif